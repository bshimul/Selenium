package Week4;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;

public class HomeWork2 {
	
	@Test(invocationCount=2)
	public void creatLead()
	{
		System.out.println("Create Lead");
	}
	@Test(dependsOnMethods="createLead")
	public void editLead()
	{
		System.out.println("Edit Lead");
	}
	@Test(dependsOnMethods= "createLead")
	public void deleteLead()
	{
		System.out.println("Delete Lead");
	
	}
	@Test(timeOut=20000)
	public void mergeLead()
	{ 	
		System.out.println("Merge Lead");
	}
	@Test(enabled=false)
	public void duplicateLead()
	{
		System.out.println("Duplicate Lead");
	}
}