package Week4;

public class RemoveWhitespace {

	public static void main(String[] args)
	{  
		String s="/filename/datsheet.xlsx";
		String a=s.substring(s.indexOf("."));
		System.out.println(a);
	}
}
/*String str="deep is the ocean ";
RemoveWhitespace a=new RemoveWhitespace();
a.removeAllWhiteSpace(str);
// TODO Auto-generated method stub



// TODO Auto-generated method stub
}
public void removeAllWhiteSpace(String str)
{
String[] strArr = str.split(" ");
String sb = new String();
//for(String str1: strArr)
for(int i=0;i<strArr.length;i++)
{
sb=sb+strArr[i];

}
System.out.println("String without Space ="+sb);
}

}
	*/



