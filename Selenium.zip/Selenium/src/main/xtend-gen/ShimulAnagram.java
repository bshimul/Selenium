import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ShimulAnagram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String S="mmary";
		String A="aamry";
		char[] Sch=S.toCharArray();
		char[] Ach=A.toCharArray();
		
		List<Character> Slst = new ArrayList<Character>();
		List<Character> Alst = new ArrayList<Character>();
		
		for(int i=0;i<Sch.length;i++)
			Slst.add(Sch[i]);
		
		for(int i=0;i<Ach.length;i++)
			Alst.add(Ach[i]);
		
		Collections.sort(Alst);
		Collections.sort(Slst);
		
		if(Alst.equals(Slst))
			System.out.println("Anagram");
		
		else
			System.out.println("Not Anagram");
			
	}

}