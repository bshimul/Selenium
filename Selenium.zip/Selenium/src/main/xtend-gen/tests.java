
public interface tests {
	public void sqr();
	public void cir();
}
