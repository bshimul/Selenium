
public interface tset {
	public void cir();
	public void scr();

}
