package Week4;

import org.junit.Test;

import wrappers.WrapperMethods;

public class TC008_MergeContact extends WrapperMethods {

	@Test
	public void mergeContact()  {
		// TODO Auto-generated method stub
		invokeApp("chrome", "http://leaftaps.com/opentaps");
		enterById("username", "DemoSalesManager");
		enterById("password", "crmsfa");
		clickByClassName("decorativeSubmit");
		clickByLink("CRM/SFA");
		clickByLink("Contacts");
		//Merge Contacts
		clickByLink("Merge Contacts");
		clickByXpath("(//img[@alt='Lookup'])[1]");
		switchToLastWindow();
		enterByXpath("//input[@name='id']", "11621");
		clickByXpath("//button[text()='Find Contacts']");
		clickByLinkNoSnap("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a");
		switchToParentWindow();
		//To contact
		clickByXpath("(//img[@alt='Lookup'])[2]");
		switchToLastWindow();
		enterByXpath("//input[@name='id']", "11622");
		clickByXpath("//button[text()='Find Contacts']");
		clickByLinkNoSnap("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a");
		switchToParentWindow();
		//Merge
		clickByLinkNoSnap("Merge");
		acceptAlert();
		clickByXpath("//button[text()='Find Contacts']");
		enterById("//input[@name='id']", "11621");
		clickByXpath("//button[text()='Find Contacts']");
		verifyTextByXpath("//div[text()='No records to display']", "No records to display");
		closeBrowser();
		
			


	}

}
