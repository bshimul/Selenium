package Week4;



import org.testng.annotations.Test;

import leaftaps.Wrapper.LeaftapsWrappers;
import wrappers.WrapperMethods;
public class CreateLead extends LeaftapsWrappers{
	@Test(invocationCount=2)
	public void createLeadMethod() {
		//WrapperMethods wm = new WrapperMethods();
		
		clickByLink("Create Lead");
		enterById("createLeadForm_companyName","Testleaf");
	//	Thread.sleep(2000);
		enterById("createLeadForm_firstName", "Keerthi");
		enterById("createLeadForm_lastName", "M");
		selectVisibileTextById("createLeadForm_dataSourceId","Conference");
	//	Thread.sleep(2000);
		selectVisibileTextById("createLeadForm_marketingCampaignId","Automobile");
		enterById("createLeadForm_primaryPhoneNumber","8344393391");
	//	Thread.sleep(2000);
		enterById("createLeadForm_primaryEmail","keerthi.m1994@gmail.com");
		clickByClassName("smallSubmit");
		verifyTextById("viewLead_firstName_sp","Keerthi");
		//closeBrowser();
		
		//closeBrowser();
	}

}
