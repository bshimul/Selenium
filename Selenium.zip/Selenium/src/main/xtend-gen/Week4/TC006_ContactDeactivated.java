package Week4;
import org.junit.Test;

import wrappers.WrapperMethods;


public class TC006_ContactDeactivated extends WrapperMethods  {
@Test
	public void contactDeactivation() {
		// TODO Auto-generated method stub
		//Launch the Browser
	invokeApp("chrome", "http://leaftaps.com/opentaps");
	enterById("username", "DemoSalesManager");
	enterById("password", "crmsfa");
	clickByClassName("decorativeSubmit");
	clickByLink("CRM/SFA");
	//Click Contact
	clickByLink("Contacts");
	clickByLink("Find Contacts");
	enterByXpath("(//div[@class='x-form-element'])[3]/input", "test2");
	clickByXpath("//button[text()='Find Contacts']");
	String capture = getTextByXpath("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a");
	clickByXpath("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a");
	//Verify Title of the page
	verifyTitle("View Contact | opentaps CRM");
	//Deactivate contact
	clickByLinkNoSnap("Deactivate Contact");
	acceptAlert();
	//verify if the account is activated
	verifyTextContainsByXpath("//span[contains(text(),'This contact was deactivated as of')]", "This contact was deactivated as of");
	clickByLink("Find Contacts");
	enterByXpath("//input[@name='id']",capture);
	clickByXpath("//button[text()='Find Contacts']");
	verifyTextByXpath("//div[text()='No records to display']", "No records to display");
	//close Browser
	closeBrowser();
	
	}

}
