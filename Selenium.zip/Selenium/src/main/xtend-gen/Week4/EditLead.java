package Week4;


import org.testng.annotations.Test;

import leaftaps.Wrapper.LeaftapsWrappers;
import wrappers.WrapperMethods;
//Edit Lead
public class EditLead extends LeaftapsWrappers  {
   @Test(dependsOnMethods={"CreateLead"})
	public void editLeadMethod() throws InterruptedException  {
		// TODO Auto-generated method stub
		
		clickByLink("Leads");
		clickByLink("Find Leads");
		enterByXpath("(//input[@name='firstName'])[3]","keerthi");
		clickByXpath("//button[contains(text(),'Find Leads')]");
		clickByXpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a");
		verifyTitle("View Lead | opentaps CRM");
		clickByLink("Edit");
		enterById("updateLeadForm_companyName","CTS");
		clickByClassName("smallSubmit");
		verifyTextById("viewLead_companyName_sp","CTS");
		// closeBrowser();
		
		
	}

}
