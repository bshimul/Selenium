package week4assignments;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import wrappers.WrapperMethods;

	public class Testcase002 extends Login{
		//editlead
		@Test(dataProvider="FetchData",groups={"sanity"},dependsOnGroups={"smoke"})
		public void testcase002 (String FN,String CN,String title,String LN ){
			// TODO Auto-generated method stub
			
			
			clickByLink("Leads");
			clickByLink("Find Leads");
			//enterByName("firstName" , "Shimul");
			enterByXpath("(//input[@name='firstName'])[3]", FN);
			clickByXpath("//button[contains(text(),'Find Leads')]");
			clickByXpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a");
			verifyTitle(title);
			clickByLink("Edit");
			enterById("updateLeadForm_companyName" , CN);
			clickByClassName("smallSubmit");
			verifyTextContainsById("viewLead_companyName_sp", LN);
			//closeBrowser();
		}
		@DataProvider(name="FetchData")
		public String[][] getData()
		{
			String[][] data= new String[1][4];
			data[0][0]="Keerthi";
			data[0][1] ="CTS";
			data[0][2]="View Lead | opentaps CRM";
			data[0][3]="CTS";
			//data[1][0]="Hema";
			//data[1][1]="IBM";
			//data[1][2]="IBM";
			
			return data;
		}
	
	}



