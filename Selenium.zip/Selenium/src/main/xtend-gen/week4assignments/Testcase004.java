package week4assignments;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


	public class Testcase004 extends Login{
		//merge

		@Test(dataProvider="FetchData",groups={"smoke"})
		public void testcase004(String ID1,String ID2) throws InterruptedException {
			// TODO Auto-generated method stub

			
			clickByLink("Leads");
			clickByLink("Merge Leads");
			clickByXpath("(//img[@alt='Lookup'])[1]");
			switchToLastWindow();
			enterByXpath("//label[contains(text(),'Lead ID:')]/following::input",ID1);
			clickByXpath("//button[contains(text(),'Find Leads')]");
			clickByXpathNoSnap("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a");
			switchToParentWindow();
			clickByXpath("(//img[@alt='Lookup'])[2]");
			switchToLastWindow();
			enterByXpath("//label[contains(text(),'Lead ID:')]/following::input",ID2);
			clickByXpath("//button[contains(text(),'Find Leads')]");
			clickByXpathNoSnap("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a");
			switchToParentWindow();
			clickByLinkNoSnap("Merge");
			acceptAlert();
			clickByLink("Find Leads");
			Thread.sleep(2000);
			enterByXpath("//label[contains(text(),'Lead ID:')]/following::input", ID1);
			clickByXpath("//button[contains(text(),'Find Leads')]");
			verifyTextContainsByXpath("//div[contains(text(),'No records to display')]", "No records to display");
			//closeBrowser();
			
			}
		@DataProvider(name="FetchData")
		public String[][] getData()
		{
			String[][] data= new String[1][2];
			data[0][0]="11237";
		    data[0][1] ="11238";
			//data[1][0]="11251";
			//data[1][1]="11252";
			return data;
		}

	}



