package week4assignments;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;



	public class Testcase005 extends Login {
		//duplicatelead
		@Test(dataProvider="FetchData",groups={"regression"},dependsOnGroups={"sanity"})
		public void testcase005 (String Email){
			// TODO Auto-generated method stub

			clickByLink("Leads");
			clickByLink("Find Leads");
			clickByXpath("//span[contains(text(),'Email')]");
			enterByName("emailAddress",Email);
			clickByXpath("//button[contains(text(),'Find Leads')]");
			String textName = getTextByXpath("//div[@class='x-grid3-cell-inner x-grid3-col-firstName']/a");
			clickByXpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a");
			clickByLink("Duplicate Lead");
			verifyTitle("Duplicate Lead | opentaps CRM");
			clickByClassName("smallSubmit");
			verifyTextById("viewLead_firstName_sp", textName);
			//closeBrowser();
			
			
		}
		@DataProvider(name="FetchData")
		public String[][] getData()
		{
			String[][] data= new String[1][1];
			data[0][0]="keerthi.m1994@gmail.com";
			return data;
		}

	}



