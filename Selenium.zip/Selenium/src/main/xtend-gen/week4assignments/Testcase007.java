package week4assignments;

import org.junit.Test;

public class Testcase007 extends Login {
 //mergecontacts
		@Test
		public void testcase003() {
			// TODO Auto-generated method stub

			clickByLink("Contacts");
			clickByLink("Merge Contacts");
			clickByXpath("//img[@alt='Lookup']");
			switchToLastWindow();
			enterByXpath("//input[@class=' x-form-text x-form-field']", "11578");
			clickByXpath("//button[text()='Find Contacts']");
			clickByXpathNoSnap("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a");
			switchToParentWindow();
			clickByXpath("(//img[@alt='Lookup'])[2]");
			switchToLastWindow();
			enterByXpath("//input[@class=' x-form-text x-form-field']", "11583");
			clickByXpath("//button[text()='Find Contacts']");
			clickByXpathNoSnap("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a");
			switchToParentWindow();
			clickByLinkNoSnap("Merge");
			acceptAlert();
			clickByLink("Find Contacts");
			enterByXpath("//label[text()='Contact Id:']/following::input", "11578");
			clickByXpath("//button[text()='Find Contacts']");
			verifyTextByXpath("//div[text()='No records to display']", "No records to display");
			closeBrowser();
		}
	}



