package week4assignments;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


	public class Testcase001 extends Login{
		@Test(dataProvider ="FetchData",groups={"smoke"})
		public void testcase001(String CN,String FN,String LN,String Emp,String Industry,String PHN,String Email,String FNL ) {
			// TODO Auto-generated method stub

//			invokeApp("chrome", "http://leaftaps.com/opentaps");
	//		enterById("username", "DemoSalesManager");
		//	enterById("password", "crmsfa");
			//clickByClassName("decorativeSubmit");
			//clickByLink("CRM/SFA");
			clickByLink("Create Lead");
			enterById("createLeadForm_companyName", CN);
			enterById("createLeadForm_firstName", FN);
			enterById("createLeadForm_lastName", LN);
			selectVisibileTextById("createLeadForm_dataSourceId", Emp);
			selectVisibileTextById("createLeadForm_marketingCampaignId", Industry);
			enterById("createLeadForm_primaryPhoneNumber", PHN);
			enterById("createLeadForm_primaryEmail",Email);
			clickByClassName("smallSubmit");
			verifyTextContainsById("viewLead_firstName_sp", FNL);
			closeBrowser();
			
		}
		@DataProvider(name="FetchData")
		public String[][] getData()
		{
			String[][] data= new String[3][3];
			data[0][0]="CTS";
			data[0][1] ="Keerthi";
			data[0][2]="M";
			data[1][0]="Employee";
			data[1][2]="Automobile";
			data[1][1]="8344393391";
			data[2][0]="keerthi.m1994@gmail.com";
			data[2][1]="keerthi";
			return data;
		}
	
			
		}

	


