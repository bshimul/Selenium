package week4assignments;
import org.junit.Test;

public class Testcase006 extends Login {
// ContactDeactivated extends Login{
		
		@Test
		public void testcase001() {
			// TODO Auto-generated method stub
		
			clickByLink("Contacts");
			clickByLink("Find Contacts");
			enterByXpath("(//input[@name='firstName'])[3]", "Yoga");
			clickByXpath("//button[text()='Find Contacts']");
			//Thread.sleep(2000);
			String s = getTextByXpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a");
			clickByXpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a");
			
			//String s = getTextByXpath("//div[@class='x-grid-7-cell-inner x-grid3-col-partyId']/a");
			verifyTitle("View Contact | opentaps CRM");
			clickByLinkNoSnap("Deactivate Contact");
			acceptAlert();
			verifyTextContainsByXpath("//span[contains(text(),'This contact was deactivated')]","This contact was deactivated" );
			clickByLink("Find Contacts");
			enterByXpath("//label[text()='Contact Id:']/following::input", s);
			clickByXpath("//button[text()='Find Contacts']");
			verifyTextByXpath("//div[text()='No records to display']", "No records to display");
			closeBrowser();
			
		}

	}



