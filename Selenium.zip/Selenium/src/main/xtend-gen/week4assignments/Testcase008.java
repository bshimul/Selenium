package week4assignments;
import org.junit.Test;
//Editcontact


public class Testcase008 extends Login{
	
@Test
		public void testcase002() {
			// TODO Auto-generated method stub

			
			clickByLink("Contacts");
			clickByLink("Find Contacts");
			enterByXpath("(//label[text()='First name:'])[3]/following::input", "naren");
			clickByXpath("//button[text()='Find Contacts']");
			clickByXpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a");
			verifyTitle("View Contact | opentaps CRM");
			clickByLink("Edit");
			enterById("updateContactForm_firstName", "Shimul");
			selectVisibileTextById("addMarketingCampaignForm_marketingCampaignId", "Car and Driver");
			clickByXpath("//input[@class='smallSubmit']");
			verifyTextContainsById("viewContact_fullName_sp", "Shimul");
			closeBrowser();
			
		}

	}



