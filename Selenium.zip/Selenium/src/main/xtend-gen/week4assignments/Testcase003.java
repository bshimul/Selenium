package week4assignments;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

	//deletelead

	public class Testcase003 extends Login{
		@Test(dataProvider="FetchData",groups={"sanity"},dependsOnGroups={"smoke"})
		public void testcase003 (String PH) {
			// TODO Auto-generated method stub

			
			clickByLink("Leads");
			clickByLink("Find Leads");
			//clickByXpath("//*[@id='ext-gen873']");
			//clickByClassName("x-tab-strip-text ");
			//enterByXpath("(//span[text()='Phone'])" , "03324222466");
			clickByXpath("//span[text()='Phone']");
			enterByName("phoneNumber", PH );
			clickByXpath("//button[contains(text(),'Find Leads')]");
			String capture = getTextByXpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a");
			System.out.println("The captured Lead Id is " + capture);
			clickByXpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a");
			clickByLink("Delete");
			clickByLink("Find Leads");
			enterByName("id", capture);
			clickByXpath("//button[contains(text(),'Find Leads')]");
			verifyTextContainsByXpath("//div[contains(text(),'No records to display')]" , "No records to display");
			//closeBrowser();
		}
		@DataProvider(name="FetchData")
		public String[][] getData()
		{
			String[][] data= new String[1][1];
			data[0][0]="8344393391";
			//data[1][0]="8332991261";
			
			return data;
		}

	}



