package DummyClasses;

import org.testng.annotations.Test;

public class Testcase2 extends Login{
	
		//@Test(groups="sanity",dependsOnGroups="smoke")
		@Test(dependsOnMethods={"DummyClasses.Testcase3.c"})
		public void b()
		{
			System.out.println("Loggedin with username and password testcase2");
		}
		}


