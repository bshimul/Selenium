package DummyClasses;

import java.util.Scanner;

public class AtoZ {

	public static void main(String[] args)   {
		// TODO Auto-generated method stub
		System.out.printf("Enter any character: ");
	    Scanner sc=new Scanner(System.in);
	    String ch=sc.next();
	  int a[]=new int[26];
	   int d[]=new int[26];
for(int i=0;i<26;i++)
	{
	int b=97;
	int c=65;
	a[i]=b;
	d[i]=c;


	b++;
	c++;
	}
 if((Integer.valueOf(ch) >= 97 && Integer.valueOf(ch) <= 122) || Integer.valueOf(ch) >= 65 && Integer.valueOf(ch) <= 90)
 {
	 for(int i=0;i<26;i++)
	 {
	        if(Integer.valueOf(ch)==a[i])
	{
	System.out.println(i);
	}
	else if(Integer.valueOf(ch)==d[i])
	{
	System.out.println(i);
	}
	}
 }


	}
}


