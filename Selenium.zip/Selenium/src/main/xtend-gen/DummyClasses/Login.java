package DummyClasses;	

	import org.testng.annotations.AfterMethod;
	import org.testng.annotations.BeforeGroups;
	import org.testng.annotations.BeforeMethod;
	import org.testng.annotations.Parameters;
	import org.testng.annotations.Test;

	import wrappers.WrapperMethods;

	public class Login extends WrapperMethods {
		@Parameters({"browser" , "url" , "username" , "password"})
		@BeforeMethod (groups = {"common"})
		
		public void logintoleaptaps (){
			invokeApp("chrome", "http://leaftaps.com/opentaps");
			enterById("username", "DemoSalesManager");
			enterById("password", "crmsfa");
			clickByClassName("decorativeSubmit");
			clickByLink("CRM/SFA");
			
		}
		@AfterMethod (groups = {"common"})
		public void closeBrw (){
			closeBrowser();
		}

	}



