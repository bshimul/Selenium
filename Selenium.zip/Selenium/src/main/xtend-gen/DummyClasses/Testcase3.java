package DummyClasses;

import org.testng.annotations.Test;

public class Testcase3 extends Login{
	 
		//@Test(groups="sanity",dependsOnGroups="smoke")
		@Test(dependsOnMethods={"DummyClasses.Testcase1.a"})
		public void c()
		{
			System.out.println("Loggedin with username and password -Testcase3");
		}
		}


