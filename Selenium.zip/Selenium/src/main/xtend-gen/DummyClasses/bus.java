package DummyClasses;

public class bus implements vehi{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	public void rush() {
		// TODO Auto-generated method stub
		
	}
	public void run() {
		// TODO Auto-generated method stub
		
	}

}
