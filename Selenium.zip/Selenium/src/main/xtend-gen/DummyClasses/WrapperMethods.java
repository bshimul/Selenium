package DummyClasses;



	import java.io.File;
	import java.io.IOException;
	import java.util.Set;
	import java.util.concurrent.TimeUnit;

	import org.apache.commons.io.FileUtils;
	import org.openqa.selenium.Dimension;
	import org.openqa.selenium.NoAlertPresentException;
	import org.openqa.selenium.NoSuchElementException;
	import org.openqa.selenium.NoSuchWindowException;
	import org.openqa.selenium.OutputType;
	import org.openqa.selenium.Point;
	import org.openqa.selenium.WebDriverException;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.chrome.ChromeDriver;
	import org.openqa.selenium.firefox.FirefoxDriver;
	import org.openqa.selenium.remote.RemoteWebDriver;
	import org.openqa.selenium.support.ui.Select;

    import wrappers.Wrappers;

		

	public class WrapperMethods implements Wrappers{
		RemoteWebDriver driver;
		int i=1;
		String winHan;
		public void invokeApp(String browser, String url) {
			if(browser.equalsIgnoreCase("chrome")){
				System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
				driver = new ChromeDriver();
			}else if(browser.equalsIgnoreCase("firefox")){
				System.setProperty("webdriver.gecko.driver", "./drivers/geckodriver.exe");
				driver = new FirefoxDriver();
			}
			driver.get(url);
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);		
			driver.manage().window().maximize();
			System.out.println("The browser "+browser+" is launched");
			takeSnap();
		}

		public void enterById(String idValue, String data) {
			try{
				driver.findElementById(idValue).clear();
			driver.findElementById(idValue).sendKeys(data);
			System.out.println("The text field "+idValue+" is entered with value :"+data);
			}
			
			catch (NoSuchElementException e){
				System.err.println("The element "+idValue+" is not found");
				throw new RuntimeException ("enterById failed");
			}
			catch (WebDriverException e){
				System.err.println("Browser does not exist");
				throw new RuntimeException ("enterById failed");
			}catch (Exception e){
				System.err.println("Browser does not exist");
				throw new RuntimeException ("enterById failed");
			}
			
			finally{
			takeSnap();
			}
		}

		public void enterByName(String nameValue, String data) {
			try{
				driver.findElementByName(nameValue).sendKeys(data);
			System.out.println("The text field "+nameValue+" is entered with value :"+data);
			}
			catch (NoSuchElementException e){
				System.err.println("The element "+nameValue+" is not found");
				throw new RuntimeException ("enterByName failed");
			}
			catch (WebDriverException e){
				System.err.println("Browser does not exist");
				throw new RuntimeException ("enterByName failed");
			}
			catch (Exception e){
				System.err.println("Browser does not exist");
				throw new RuntimeException ("enterById failed");
			}
			finally{
			takeSnap();
			}

		}

		public void enterByXpath(String xpathValue, String data) {
			try{
			driver.findElementByXPath(xpathValue).sendKeys(data);
			System.out.println("The text field "+xpathValue+" is entered with value :"+data);
			}
			catch (NoSuchElementException e){
				System.err.println("The element "+xpathValue+" is not found");
				throw new RuntimeException ("enterByXpath failed");
			}
			catch (WebDriverException e){
				System.err.println("Browser does not exist");
				throw new RuntimeException ("enterByXpath failed");
			}
			catch (Exception e){
				System.err.println("Browser does not exist");
				throw new RuntimeException ("enterById failed");
			}
			finally{
			takeSnap();
			}
		}

		public void verifyTitle(String title) {
			try {
				if(driver.getTitle().equals(title))
					System.out.println("The title matches");
				else
					System.out.println("The title does not match");
			} 
			catch (WebDriverException e){
				System.err.println("Browser does not exist");
				throw new RuntimeException ("verifytitle failed");
			}
			catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally{
				takeSnap();
			}

		}

		public void verifyTextById(String id, String text) {
			try{
			String s = driver.findElementById(id).getText();
			if(s.equals(text))
				System.out.println("The text matches");
			else
				System.out.println("The text does not match");
			}
			catch (NoSuchElementException e){
				System.err.println("The element "+id+" is not found");
				throw new RuntimeException ("verifyTxtById failed");
			}
			catch (WebDriverException e){
				System.err.println("Browser does not exist");
				throw new RuntimeException ("verifyTxtById failed");
			}
			catch (Exception e){
				System.err.println("Browser does not exist");
				throw new RuntimeException ("enterById failed");
			}
			finally{
				takeSnap();
			}

		}

		public void verifyTextByXpath(String xpath, String text) {
			try{
			String s = driver.findElementByXPath(xpath).getText();
			if(s.equals(text))
				System.out.println("The text matches");
			else
				System.out.println("The text does not match");
			}
			catch (NoSuchElementException e){
				System.err.println("The element "+xpath+" is not found");
				throw new RuntimeException ("verifyTextByXpath failed");
			}
			catch (WebDriverException e){
				System.err.println("Browser does not exist");
				throw new RuntimeException ("verifyTextByXpath failed");
			}
			catch (Exception e){
				System.err.println("Browser does not exist");
				throw new RuntimeException ("enterById failed");
			}
			finally{
				takeSnap();
			}

		}

		public void verifyTextContainsByXpath(String xpath, String text) {
			try{
			String s = driver.findElementByXPath(xpath).getText();
			if(s.contains(text))
				System.out.println("The text matches");
			else
				System.out.println("The text does not match");
			}
			catch (NoSuchElementException e){
				System.err.println("The element "+xpath+" is not found");
				throw new RuntimeException ("verifyTextConatinsByXpath failed");
			}
			catch (WebDriverException e){
				System.err.println("Browser does not exist");
				throw new RuntimeException ("verifyTextConatainsByXpath failed");
			}
			catch (Exception e){
				System.err.println("Browser does not exist");
				throw new RuntimeException ("enterById failed");
			}
			finally{
				takeSnap();
			}
			
		}

		public void clickById(String id) {
			try{
			driver.findElementById(id).click();
			System.out.println("The button "+id+" is clicked");
			}
			catch (NoSuchElementException e){
				System.out.println("The element "+id+" is not found");
				throw new RuntimeException ("clickById failed");
			}
			catch (WebDriverException e){
				System.out.println("Browser does not exist");
				throw new RuntimeException ("clickById failed");
			}
			finally{
			takeSnap();
			}

		}

		public void clickByClassName(String classVal) {
		try{
		driver.findElementByClassName(classVal).click();
		System.out.println("The button "+classVal+" is clicked");
		}
		catch (NoSuchElementException e){
			System.err.println("The element "+classVal+" is not found");
			throw new RuntimeException ("clickByClassName failed");
		}
		catch (WebDriverException e){
			System.err.println("Browser does not exist");
			throw new RuntimeException ("clickBClassName failed");
		}
		catch (Exception e){
			System.err.println("Browser does not exist");
			throw new RuntimeException ("enterById failed");
		}
		
		finally{
		takeSnap();
		}
		}

		public void clickByName(String name) {
			try{
			driver.findElementByName(name).click();
			System.out.println("The button "+name+" is clicked");
			}
			catch (NoSuchElementException e){
				System.err.println("The element "+name+" is not found");
				throw new RuntimeException ("clickByName failed");
			}
			catch (WebDriverException e){
				System.err.println("Browser does not exist");
				throw new RuntimeException ("clickBClassName failed");
			}
			catch (Exception e){
				System.err.println("Browser does not exist");
				throw new RuntimeException ("enterById failed");
			}
			finally{
			takeSnap();
			}

		}

		public void clickByLink(String name) {
			try{
			driver.findElementByLinkText(name).click();
			System.out.println("The button "+name+" is clicked");
			}
			catch (NoSuchElementException e){
				System.err.println("The element "+name+" is not found");
				throw new RuntimeException ("clickByLink failed");
			}
			catch (WebDriverException e){
				System.err.println("Browser does not exist");
				throw new RuntimeException ("clickBClassLink failed");
			}
			catch (Exception e){
				System.err.println("Browser does not exist");
				throw new RuntimeException ("enterById failed");
			}
			finally{
			takeSnap();
			}
		}

		public void clickByLinkNoSnap(String name) {
			try{
			driver.findElementByLinkText(name).click();
			System.out.println("The button "+name+" is clicked");
			}
			catch (NoSuchElementException e){
				System.err.println("The element "+name+" is not found");
				throw new RuntimeException ("clickByLinkNoSnap failed");
			}
			catch (WebDriverException e){
				System.err.println("Browser does not exist");
				throw new RuntimeException ("clickBClassLinkNoSnap failed");
			}
			catch (Exception e){
				System.err.println("Browser does not exist");
				throw new RuntimeException ("enterById failed");
			}
			finally{
				takeSnap();
			}

		}

		public void clickByXpath(String xpathVal) {
			try{
			driver.findElementByXPath(xpathVal).click();
			System.out.println("The button "+xpathVal+" is clicked");
			}
			catch (NoSuchElementException e){
				System.err.println("The element "+xpathVal+" is not found");
				throw new RuntimeException ("clickByXpath failed");
			}
			catch (WebDriverException e){
				System.err.println("Browser does not exist");
				throw new RuntimeException ("clickBClassXpath failed");
			}
			catch (Exception e){
				System.err.println("Browser does not exist");
				throw new RuntimeException ("enterById failed");
			}
			finally{
			takeSnap();
			}
		}

		public void clickByXpathNoSnap(String xpathVal) {
			try{
			driver.findElementByXPath(xpathVal).click();
			System.out.println("The button "+xpathVal+" is clicked");
			}
			catch (NoSuchElementException e){
				System.err.println("The element "+xpathVal+" is not found");
				throw new RuntimeException ("clickByXpathNoSnap failed");
			}
			catch (WebDriverException e){
				System.err.println("Browser does not exist");
				throw new RuntimeException ("clickBClassXpathNoSnap failed");
			}
			catch (Exception e){
				System.err.println("Browser does not exist");
				throw new RuntimeException ("enterById failed");
			}
			finally{
				takeSnap();
			}

		}

		//getText
		public String getTextById(String idVal) {
			try{
			return driver.findElementById(idVal).getText();
			}
			catch (NoSuchElementException e){
				System.err.println("The element "+idVal+" is not found");
				throw new RuntimeException ("getTextById failed");
			}
			catch (WebDriverException e){
				System.err.println("Browser does not exist");
				throw new RuntimeException ("getTextById failed");
			}
			catch (Exception e){
				System.err.println("Browser does not exist");
				throw new RuntimeException ("enterById failed");
			}
			finally{
				takeSnap();
			}
			
		}

		public String getTextByXpath(String xpathVal) {
			try{
			return driver.findElementByXPath(xpathVal).getText();
			}
			catch (NoSuchElementException e){
				System.err.println("The element "+xpathVal+" is not found");
				throw new RuntimeException ("getTextByXpath failed");
			}
			catch (WebDriverException e){
				System.err.println("Browser does not exist");
				throw new RuntimeException ("getTextByXpath failed");
			}
			catch (Exception e){
				System.err.println("Browser does not exist");
				throw new RuntimeException ("enterById failed");
			}
			finally{
				takeSnap();
			}
		}

		public String getTextByClassName(String classNameVal) {
			try{
			return driver.findElementByClassName(classNameVal).getText();
			}
			catch (NoSuchElementException e){
				System.err.println("The element "+classNameVal+" is not found");
				throw new RuntimeException ("getTextByClassName failed");
			}
			catch (WebDriverException e){
				System.err.println("Browser does not exist");
				throw new RuntimeException ("getTextByClassName failed");
			}
			catch (Exception e){
				System.err.println("Browser does not exist");
				throw new RuntimeException ("enterByClassName failed");
			}
			finally{
				takeSnap();
			}
			
		}
		
		public String getTextByName(String nameVal) {
			try{
			return driver.findElementByName(nameVal).getText();
			}
			catch (NoSuchElementException e){
				System.err.println("The element "+nameVal+" is not found");
				throw new RuntimeException ("getTextByName failed");
			}
			catch (WebDriverException e){
				System.err.println("Browser does not exist");
				throw new RuntimeException ("getTextByName failed");
			}
			catch (Exception e){
				System.err.println("Browser does not exist");
				throw new RuntimeException ("enterByName failed");
			}
			finally{
				takeSnap();
			}
			
		}
		
		public String getTextByLinkText(String linkText) {
			try{
			return driver.findElementByLinkText(linkText).getText();
			}
			catch (NoSuchElementException e){
				System.err.println("The element "+linkText+" is not found");
				throw new RuntimeException ("getTextByLinkText failed");
			}
			catch (WebDriverException e){
				System.err.println("Browser does not exist");
				throw new RuntimeException ("getTextByLinkText failed");
			}
			catch (Exception e){
				System.err.println("Browser does not exist");
				throw new RuntimeException ("enterByLinkText failed");
			}
			finally{
				takeSnap();
			}
			
		}
		
		
		public void selectVisibileTextById(String id, String value) {
			try{
				WebElement source = driver.findElementById(id);
			Select obj = new Select(source);
			obj.selectByVisibleText(value);
			System.out.println("The button "+value+" is clicked");	
			}
			catch (NoSuchElementException e){
				System.err.println("The element "+id+" is not found");
				throw new RuntimeException ("selectTextById failed");
			}
			catch (WebDriverException e){
				System.err.println("Browser does not exist");
				throw new RuntimeException ("selectTextById failed");
			}
			catch (Exception e){
				System.err.println("Browser does not exist");
				throw new RuntimeException ("enterById failed");
			}
			finally{
			takeSnap();
			}
		}
		

		public void selectIndexById(String id, int value) {
			try{
				WebElement src = driver.findElementById(id);
			Select opt = new Select(src);
			//List<WebElement> allOptions = opt.getOptions();
			//int count = allOptions.size();
			opt.selectByIndex(value);
			System.out.println("The index "+value+" is selected");
			}
			catch (NoSuchElementException e){
				System.err.println("The element "+id+" is not found");
				throw new RuntimeException ("selectTextById failed");
			}
			catch (WebDriverException e){
				System.err.println("Browser does not exist");
				throw new RuntimeException ("selectTextById failed");
			}
			catch (Exception e){
				System.err.println("Browser does not exist");
				throw new RuntimeException ("enterById failed");
			}
			
			finally{
			takeSnap();
			}

		}

		public void switchToParentWindow() {
			try{
			Set<String> allWin = driver.getWindowHandles();
			int i=0;
			for (String eachWin : allWin) {
				driver.switchTo().window(eachWin);
				if(i==0)
					break;
			}
			System.out.println("The window is switched to "+driver.getTitle());
			}
			catch(NoSuchWindowException e)
			{
				System.err.println("Window not found");
			}
			finally{
			takeSnap();
			}

		}

		public void switchToLastWindow() {
			//winHan = driver.getWindowHandle();
			try{
			Set<String> allWin = driver.getWindowHandles();
			for (String eachWin : allWin) {
				driver.switchTo().window(eachWin);
			}
			System.out.println("The window is switched to "+driver.getTitle());
			}
			catch(NoSuchWindowException e)
			{
				System.err.println("Window not found");
			}
			finally{
			takeSnap();
			}

		}

		public void acceptAlert() {
			try{
			driver.switchTo().alert().accept();
			System.out.println("The alert is accepted");
			}
			catch (NoAlertPresentException e){
				System.err.println("acceptAlert failed");
			}
		}

		public void dismissAlert() {
			try{
			driver.switchTo().alert().dismiss();
			System.out.println("The alert is dismissed");
			}
			catch (NoAlertPresentException e){
				System.err.println("dismissAlert failed");
			}

		}

		public String getAlertText() {
			try{
			return driver.switchTo().alert().getText();
			}
			catch (NoAlertPresentException e){
				System.err.println("getAlertText failed");
				return null;
			}

		}

		public void takeSnap() {
			File srcFile = driver.getScreenshotAs(OutputType.FILE);
			File destFile = new File("./snaps/snap"+i+".jpg");
			try {
				FileUtils.copyFile(srcFile, destFile);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			i++;
		}

		public void closeBrowser() {
			try{
			driver.close();
			System.out.println("The browser is closed");
			}
			catch (WebDriverException e)
			{
				System.err.println("Browser does not exist");
				throw new RuntimeException ("closeBrowser failed");
			}
			//takeSnap();
		}

		public void closeAllBrowsers() {
			try{
			driver.quit();
			System.out.println("The browser is closed");
			}
			catch (WebDriverException e)
			{
				System.err.println("Browser does not exist");
				throw new RuntimeException ("closeBrowser failed");
			}

		}

		public void verifyTextContainsById(String id, String text) {
			try{
			String s = driver.findElementById(id).getText();
			if(s.contains(text))
				System.out.println("The text matches");
			else
				System.out.println("The text does not match");
			}
			catch (NoSuchElementException e){
				System.err.println("The element "+id+" is not found");
				throw new RuntimeException ("verifyTextContainsById failed");
			}
			catch (WebDriverException e){
				System.err.println("Browser does not exist");
				throw new RuntimeException ("verifyTextContainsById failed");
			}
			catch (Exception e){
				System.err.println("Browser does not exist");
				throw new RuntimeException ("enterById failed");
			}
			finally{
				takeSnap();
				}

			
		}

		public void enterByClassName(String nameValue, String data) {
			// TODO Auto-generated method stub
			try{
			driver.findElementByName(nameValue).sendKeys(data);
			System.out.println("The text field "+nameValue+" is entered with value :"+data);
			}
			catch (NoSuchElementException e){
				System.err.println("The element "+nameValue+" is not found");
				throw new RuntimeException ("enterByClassName failed");
			}
			catch (WebDriverException e){
				System.err.println("Browser does not exist");
				throw new RuntimeException ("enterByClassName failed");
			}
			catch (Exception e){
				System.err.println("Exception");
				throw new RuntimeException ("enterById failed");
			}
			finally{
			takeSnap();
			}
		}
		
		public String getTheTitle(){
			try{
				return driver.getTitle();
			}
			catch (Exception e){
				System.err.println("Exception");
				throw new RuntimeException ("getTitle failed");
			}
		}
		
		public String getTheCurrentURL(){
			try{
				return driver.getCurrentUrl();
			}
			catch (Exception e){
				System.err.println("Exception");
				throw new RuntimeException ("getCurrentURL failed");
			}
		}
		
		public String getThePageSource(){
			try{
				return driver.getPageSource();
			}
			catch (Exception e){
				System.err.println("Exception");
				throw new RuntimeException ("getPageSource failed");
			}
		}
		
		//getAttribute
		public String getAttributeById(String idVal, String attrib){
			try{
				return driver.findElementById(idVal).getAttribute(attrib);
			}
			catch (Exception e){
				System.err.println("Exception");
				throw new RuntimeException ("getAttributeById failed");
			}

			finally{
				takeSnap();
			}
		}
		
		public String getAttributeByName(String nameVal, String attrib){
			try{
				return driver.findElementByName(nameVal).getAttribute(attrib);
			}
			catch (Exception e){
				System.err.println("Exception");
				throw new RuntimeException ("getAttributeByName failed");
			}

			finally{
				takeSnap();
			}
		}
		
		public String getAttributeByClassName(String classNameVal, String attrib){
			try{
				return driver.findElementByClassName(classNameVal).getAttribute(attrib);
			}
			catch (Exception e){
				System.err.println("Exception");
				throw new RuntimeException ("getAttributeByClassName failed");
			}

			finally{
				takeSnap();
			}
		}
		
		public String getAttributeByLinkText(String linkText, String attrib){
			try{
				return driver.findElementByLinkText(linkText).getAttribute(attrib);
			}
			catch (Exception e){
				System.err.println("Exception");
				throw new RuntimeException ("getAttributeByLinkText failed");
			}

			finally{
				takeSnap();
			}
		}
		
		public String getAttributeByXpath(String Xpath, String attrib){
			try{
				return driver.findElementByXPath(Xpath).getAttribute(attrib);
			}
			catch (Exception e){
				System.err.println("Exception");
				throw new RuntimeException ("getAttributeByXpath failed");
			}

			finally{
				takeSnap();
			}
		}
		
		//getCssValue
		public String getCssValueById(String idVal, String css){
			try{
				return driver.findElementById(idVal).getCssValue(css);
			}
			catch (Exception e){
				System.err.println("Exception");
				throw new RuntimeException ("getCssValueById failed");
			}

			finally{
				takeSnap();
			}
		}
		
		public String getCssValueByName(String nameVal, String css){
			try{
				return driver.findElementByName(nameVal).getCssValue(css);
			}
			catch (Exception e){
				System.err.println("Exception");
				throw new RuntimeException ("getCssValueByName failed");
			}
			
			finally{
				takeSnap();
			}

		}
		
		public String getCssValueByClassName(String classNameVal, String css){
			try{
				return driver.findElementByClassName(classNameVal).getCssValue(css);
			}
			catch (Exception e){
				System.err.println("Exception");
				throw new RuntimeException ("getCssValueByClassName failed");
			}

			finally{
				takeSnap();
			}
		}
		
		public String getCssValueByLinkText(String linkText, String css){
			try{
				return driver.findElementByLinkText(linkText).getCssValue(css);
			}
			catch (Exception e){
				System.err.println("Exception");
				throw new RuntimeException ("getCssValueByLinkText failed");
			}

			finally{
				takeSnap();
			}
		}
		
		public String getCssValueByXpath(String Xpath, String css){
			try{
				return driver.findElementByXPath(Xpath).getCssValue(css);
			}
			catch (Exception e){
				System.err.println("Exception");
				throw new RuntimeException ("getCssValueByXpath failed");
			}

			finally{
				takeSnap();
			}
		}

		//getLocation
			public Point getLocationById(String idVal){
				try{
					return driver.findElementById(idVal).getLocation();
				}
				catch (Exception e){
					System.err.println("Exception");
					throw new RuntimeException ("getLocationById failed");
				}

				finally{
					takeSnap();
				}
			}
			
			public Point getLocationByName(String nameVal){
				try{
					return driver.findElementByName(nameVal).getLocation();
				}
				catch (Exception e){
					System.err.println("Exception");
					throw new RuntimeException ("getLocationByName failed");
				}
				
				finally{
					takeSnap();
				}

			}
			
			public Point getLocationByClassName(String classNameVal){
				try{
					return driver.findElementByClassName(classNameVal).getLocation();
				}
				catch (Exception e){
					System.err.println("Exception");
					throw new RuntimeException ("getLocationByClassName failed");
				}

				finally{
					takeSnap();
				}
			}
			
			public Point getLocationByLinkText(String linkText){
				try{
					return driver.findElementByLinkText(linkText).getLocation();
				}
				catch (Exception e){
					System.err.println("Exception");
					throw new RuntimeException ("getLocationByLinkText failed");
				}

				finally{
					takeSnap();
				}
			}
			
			public Point getLocationByXpath(String Xpath){
				try{
					return driver.findElementByXPath(Xpath).getLocation();
				}
				catch (Exception e){
					System.err.println("Exception");
					throw new RuntimeException ("getLocationByXpath failed");
				}

				finally{
					takeSnap();
				}
			}

			//getSize
					public Dimension getSizeById(String idVal){
						try{
							return driver.findElementById(idVal).getSize();
						}
						catch (Exception e){
							System.err.println("Exception");
							throw new RuntimeException ("getSizeById failed");
						}

						finally{
							takeSnap();
						}
					}
					
					public Dimension getSizeByName(String nameVal){
						try{
							return driver.findElementByName(nameVal).getSize();
						}
						catch (Exception e){
							System.err.println("Exception");
							throw new RuntimeException ("getSizeByName failed");
						}
						
						finally{
							takeSnap();
						}

					}
					
					public Dimension getSizeByClassName(String classNameVal){
						try{
							return driver.findElementByClassName(classNameVal).getSize();
						}
						catch (Exception e){
							System.err.println("Exception");
							throw new RuntimeException ("getSizeByClassName failed");
						}

						finally{
							takeSnap();
						}
					}
					
					public Dimension getSizeByLinkText(String linkText){
						try{
							return driver.findElementByLinkText(linkText).getSize();
						}
						catch (Exception e){
							System.err.println("Exception");
							throw new RuntimeException ("getSizeByLinkText failed");
						}

						finally{
							takeSnap();
						}
					}
					
					public Dimension getSizeByXpath(String Xpath){
						try{
							return driver.findElementByXPath(Xpath).getSize();
						}
						catch (Exception e){
							System.err.println("Exception");
							throw new RuntimeException ("getSizeByXpath failed");
						}

						finally{
							takeSnap();
						}
					}

					//getTagName
					public String getTagNameById(String idVal){
						try{
							return driver.findElementById(idVal).getTagName();
						}
						catch (Exception e){
							System.err.println("Exception");
							throw new RuntimeException ("getTagNameById failed");
						}

						finally{
							takeSnap();
						}
					}
					
					public String getTagNameByName(String nameVal){
						try{
							return driver.findElementByName(nameVal).getTagName();
						}
						catch (Exception e){
							System.err.println("Exception");
							throw new RuntimeException ("getTagNameByName failed");
						}
						
						finally{
							takeSnap();
						}

					}
					
					public String getTagNameByClassName(String classNameVal){
						try{
							return driver.findElementByClassName(classNameVal).getTagName();
						}
						catch (Exception e){
							System.err.println("Exception");
							throw new RuntimeException ("getTagNameByClassName failed");
						}

						finally{
							takeSnap();
						}
					}
					
					public String getTagNameByLinkText(String linkText){
						try{
							return driver.findElementByLinkText(linkText).getTagName();
						}
						catch (Exception e){
							System.err.println("Exception");
							throw new RuntimeException ("getTagNameByLinkText failed");
						}

						finally{
							takeSnap();
						}
					}
					
					public String getTagNameByXpath(String Xpath){
						try{
							return driver.findElementByXPath(Xpath).getTagName();
						}
						catch (Exception e){
							System.err.println("Exception");
							throw new RuntimeException ("getCssValueByXpath failed");
						}

						finally{
							takeSnap();
						}
					}


					//isDisplayed
					public boolean isDisplayedById(String idVal){
						try{
							return driver.findElementById(idVal).isDisplayed();
						}
						catch (Exception e){
							System.err.println("Exception");
							throw new RuntimeException ("isDisplayedById failed");
						}

						finally{
							takeSnap();
						}
					}
					
					public boolean isDisplayedByName(String nameVal){
						try{
							return driver.findElementByName(nameVal).isDisplayed();
						}
						catch (Exception e){
							System.err.println("Exception");
							throw new RuntimeException ("isDisplayedByName failed");
						}
						
						finally{
							takeSnap();
						}

					}
					
					public boolean isDisplayedByClassName(String classNameVal){
						try{
							return driver.findElementByClassName(classNameVal).isDisplayed();
						}
						catch (Exception e){
							System.err.println("Exception");
							throw new RuntimeException ("isDisplayedByClassName failed");
						}

						finally{
							takeSnap();
						}
					}
					
					public boolean isDisplayedByLinkText(String linkText){
						try{
							return driver.findElementByLinkText(linkText).isDisplayed();
						}
						catch (Exception e){
							System.err.println("Exception");
							throw new RuntimeException ("isDisplayedByLinkText failed");
						}

						finally{
							takeSnap();
						}
					}
					
					public boolean isDisplayedByXpath(String Xpath){
						try{
							return driver.findElementByXPath(Xpath).isDisplayed();
						}
						catch (Exception e){
							System.err.println("Exception");
							throw new RuntimeException ("isDisplayedByXpath failed");
						}

						finally{
							takeSnap();
						}
					}

					//isEnabled
					public boolean isEnabledById(String idVal){
						try{
							return driver.findElementById(idVal).isEnabled();
						}
						catch (Exception e){
							System.err.println("Exception");
							throw new RuntimeException ("isEnabledById failed");
						}

						finally{
							takeSnap();
						}
					}
					
					public boolean isEnabledByName(String nameVal){
						try{
							return driver.findElementByName(nameVal).isEnabled();
						}
						catch (Exception e){
							System.err.println("Exception");
							throw new RuntimeException ("isDisplayedByName failed");
						}
						
						finally{
							takeSnap();
						}

					}
					
					public boolean isEnabledByClassName(String classNameVal){
						try{
							return driver.findElementByClassName(classNameVal).isEnabled();
						}
						catch (Exception e){
							System.err.println("Exception");
							throw new RuntimeException ("isEnabledByClassName failed");
						}

						finally{
							takeSnap();
						}
					}
					
					public boolean isEnabledByLinkText(String linkText){
						try{
							return driver.findElementByLinkText(linkText).isEnabled();
						}
						catch (Exception e){
							System.err.println("Exception");
							throw new RuntimeException ("isEnabledByLinkText failed");
						}

						finally{
							takeSnap();
						}
					}
					
					public boolean isEnabledByXpath(String Xpath){
						try{
							return driver.findElementByXPath(Xpath).isEnabled();
						}
						catch (Exception e){
							System.err.println("Exception");
							throw new RuntimeException ("isEnabledByXpath failed");
						}

						finally{
							takeSnap();
						}
					}
		
					//isSelected
					public boolean isSelectedById(String idVal){
						try{
							return driver.findElementById(idVal).isSelected();
						}
						catch (Exception e){
							System.err.println("Exception");
							throw new RuntimeException ("isSelectedById failed");
						}

						finally{
							takeSnap();
						}
					}
					
					public boolean isSelectedByName(String nameVal){
						try{
							return driver.findElementByName(nameVal).isSelected();
						}
						catch (Exception e){
							System.err.println("Exception");
							throw new RuntimeException ("isSelectedByName failed");
						}
						
						finally{
							takeSnap();
						}

					}
					
					public boolean isSelectedByClassName(String classNameVal){
						try{
							return driver.findElementByClassName(classNameVal).isSelected();
						}
						catch (Exception e){
							System.err.println("Exception");
							throw new RuntimeException ("isSelectedByClassName failed");
						}

						finally{
							takeSnap();
						}
					}
					
					public boolean isSelectedByLinkText(String linkText){
						try{
							return driver.findElementByLinkText(linkText).isSelected();
						}
						catch (Exception e){
							System.err.println("Exception");
							throw new RuntimeException ("isSelectedEnabledByLinkText failed");
						}

						finally{
							takeSnap();
						}
					}
					
					public boolean isSelectedByXpath(String Xpath){
						try{
							return driver.findElementByXPath(Xpath).isSelected();
						}
						catch (Exception e){
							System.err.println("Exception");
							throw new RuntimeException ("isSelectedByXpath failed");
						}

						finally{
							takeSnap();
						}
					}

	}



