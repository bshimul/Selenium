package DummyClasses;

public interface vehi {
public void run();
public void rush();
}
