package DummyClasses;

import org.testng.annotations.Test;

public class Testcase4 extends Login {
	
		//@Test(groups="Regression",dependsOnGroups="sanity")
		@Test
		public void d()
		{
			System.out.println("Loggedin with username and password-Testcase4");
		}
		}

