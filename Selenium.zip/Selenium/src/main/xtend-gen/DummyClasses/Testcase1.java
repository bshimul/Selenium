package DummyClasses;

import org.testng.annotations.Test;

public class Testcase1 extends Login{
//@Test(groups="smoke")
	@Test
public void a()
{
	System.out.println("Loggedin with username and password");
}
}
 