package DummyClasses;

abstract public class vehicle {
	abstract void run();

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
