package DummyClasses;

public class train extends bus{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
