 abstract class TEstgsr implements tests,tset {
	public void a()
	{
		
	}


	
	

}
