package Interview;

import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Windows5 {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
		ChromeDriver driver=new ChromeDriver();
		driver.get("https://www.flipkart.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS );
		//driver.switchTo().alert().dismiss();
        WebElement electronics=driver.findElementByXPath("//span[text()='Electronics']");
		Actions builder=new Actions(driver);
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS );
		builder.moveToElement(electronics).build().perform();
		Thread.sleep(5000);
		builder.click(driver.findElementByXPath("//span[text()='Mobile Cases']")).build().perform();
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS );
		driver.findElementByLinkText("Flipkart SmartBuy Back Cover for Moto E4 Plus").click();
		driver.findElementByLinkText("Flipkart SmartBuy Back Cover for Motorola Moto E4 Plus").click();
		driver.findElementByLinkText("Flipkart SmartBuy Back Cover for Mi Redmi Note 4").click();
		//driver.findElementByXPath("Noise Back Cover for Mi Redmi Note 4").click();
		Set <String> allwindow=driver.getWindowHandles();
		String mainwindow=driver.getWindowHandle();
		int j=-1;
		for (String eachwin : allwindow) {
			driver.switchTo().window(eachwin);
			j++;
			if(j!=0)
				{
				if(driver.getTitle()!="Flipkart SmartBuy Back Cover for Motorola Moto E4 Plus - Flipkart SmartBuy : Flipkart.com")
						{
					driver.close();
					
			}
			driver.switchTo().window(mainwindow);
				
			
		}		
		}
	}
}


