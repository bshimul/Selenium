package week;

import java.util.List;

		import org.openqa.selenium.WebElement;
		import org.openqa.selenium.chrome.ChromeDriver;
		import org.openqa.selenium.support.ui.Select;

public class test {



			public static void main(String[] args) {
				// TODO Auto-generated method stub
				System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
				// Create class
				ChromeDriver driver = new ChromeDriver();
				// Load URL
				driver.get("http://testleaf.herokuapp.com/pages/Dropdown.html");
				// To max the window
				driver.manage().window().maximize();
				// Select Drop down
				WebElement src = driver.findElementById("dropdown1");
				Select dd1= new Select(src);
				List<WebElement> allOptions=dd1.getOptions();
				int countOpt= allOptions.size();
				dd1.selectByIndex(countOpt-2);
				
			}
		
	}


