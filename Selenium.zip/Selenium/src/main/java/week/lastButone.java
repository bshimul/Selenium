package week;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class lastButone {

	public static void main(String[] args) {
		// TODO Auto-generated method stubs
		System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
		//System.setProperty("webdriver.chrome.driver","./drivers.chromedriver.exe");
		ChromeDriver driver=new ChromeDriver();
		driver.get("http://testleaf.herokuapp.com/pages/Dropdown.html");
		Select sc = new Select(driver.findElementByName("dropdown2"));
		List<WebElement> options=sc.getOptions();
		int count= options.size();
		sc.selectByIndex(count-2);
		
		

	}

}
