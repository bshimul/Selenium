package string;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class FirstlettertoUpperCase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//public static String toTitleCase(String givenString) {
		String S="I am a good gal";
		    String[] arr = S.split(" ");
		    List<String> a=new ArrayList<String>();
		    StringBuffer sb = new StringBuffer();

		    for (int i = 0; i < arr.length; i++) {
		        sb.append(Character.toUpperCase(arr[i].charAt(0)))
		            .append(arr[i].substring(1)).append(" ");
		    }          
		   System.out.println(sb);
		   
		 
			a.add("kee");
			a.add("bee");
			a.add("cee");
			Iterator<String> ite=a.iterator();
			while(ite.hasNext())
			{
				Object element=ite.next();
				if(element.equals("kee"))
					ite.remove();
			}
			
			
			
			
			//System.out.println(S[i]);	
		
		
	}
	}


