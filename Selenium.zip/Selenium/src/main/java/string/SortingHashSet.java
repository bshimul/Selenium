package string;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

public class SortingHashSet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<Integer,String> sort=new HashMap<Integer,String>();
		sort.put(21, "Twenty one");
	    sort.put(41,"Forty One");
	    sort.put(31, "Thirty one");
	 //   Set<Integer> keysSet = new TreeSet<Integer>(sort.keySet());                        
	 //   for(Integer kset : keysSet)
	    			//System.out.println(kset+"="+sort.get(kset));
	    
	    Map<Integer,String> sort1=new TreeMap<Integer,String>();
	    sort1.putAll(sort);
	    for(Entry<Integer,String> number:sort1.entrySet())
	    {
	    	System.out.println(number.getKey()+number.getValue());
	    }
	    	
	    	

	}

}
