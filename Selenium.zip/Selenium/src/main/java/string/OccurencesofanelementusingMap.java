package string;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;

public class OccurencesofanelementusingMap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String S= "INDIA";
		char[] character=S.toCharArray();
		int val;
		Map<Character,Integer> test=new LinkedHashMap<Character, Integer>();
		
			for(int i=0;i<character.length;i++)
			{
			if(test.containsKey(character[i]))
			{
			     val=test.get(character[i]);
			     test.put(character[i],val+1);
			}
			else{
				test.put(character[i],1);
					}
			
			}
			for(Entry<Character,Integer> charac: test.entrySet())
			{
				System.out.println("The character is:"+ charac.getKey()+"The key value is :"+charac.getValue());
			}

	}
}
