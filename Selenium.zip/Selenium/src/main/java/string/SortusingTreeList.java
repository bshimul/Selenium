package string;
import java.util.Set;
import java.util.TreeSet;

public class SortusingTreeList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<String> Company= new TreeSet<String>();
		Company.add("PayPal");
		Company.add("KLA");
		Company.add("IBM");
		Company.add("Amazon");

		System.out.println(Company.size());
		//Collections.sort(Company);
		for (String comp : Company) {
			System.out.println(comp);

	}

	}
}
