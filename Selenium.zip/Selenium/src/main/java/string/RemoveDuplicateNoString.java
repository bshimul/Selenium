package string;

import java.util.Arrays;

public class RemoveDuplicateNoString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]={1,2,3,2,3,4,5,6};
	    Arrays.sort(a);
	    for(int i=1;i<a.length-1;i++)
	    { 
	    	if((i==0) && (a[i]!=a[i+1]))
	    	{
	    		System.out.println(a[i]);
	    	}
	 
	    	if((i==a.length-1)&&(a[i]!=a[i-1]))
	    		{
	    			System.out.println(a[i]);
	    		}
	    	
	    	
	    else
	    	{
	    	if((a[i]!=a[i+1])&&(a[i]!=a[i-1]))
	    	
	    		{
	    			System.out.println(a[i]);
	    		}
	    	}
	    }
	    

	}
}


