package string;

import java.util.Scanner;

public class PerfectNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter the number:");
		Scanner in =new Scanner(System.in);
		int a= in.nextInt();
		int sum=0;
		for(int i=1;i<a;i++)
		{
			if( a%i == 0)
				sum=sum+i;
				
		}
		if(a==sum)
		{
			System.out.println("It is a perfect number");
			
		}
		else
		{
			System.out.println("It is not a perfect number");
		}
		

	}

}
