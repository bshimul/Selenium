package string;

public class ReverseString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String S="Cognizant";
		int N=S.length();
		String rev="";
		for(int i=N-1;i>=0;i--)
		{
			rev=rev+S.charAt(i);
		}
		System.out.println(rev);
	}

}
