package string;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StringRepetitionUsingRegExp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter the Pattern:");
		Scanner sc=new Scanner(System.in);
		Pattern p=Pattern.compile(sc.nextLine());
		System.out.println("Enter the para");
		Matcher match=p.matcher(sc.nextLine());
		int count=0;
		boolean found =false;
		if(match.find())
		{
			//int i=0;
			System.out.println("The Index of"+match.start()+"end index"+match.end());
				//i++;
				count++;
				//System.out.println(match.group());
				System.out.println(found=true);
			//System.out.println(match.matches());
				
				
			}
		//System.out.println(match.groupCount());
		System.out.println(count);

	}
	
	

}
