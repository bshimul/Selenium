package string;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SortusingList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> Company= new ArrayList<String>();
		//reverse
		List<String> rev=new ArrayList<String>();
		Company.add("PayPal");
		Company.add("KLA");
		Company.add("IBM");
		Company.add("Amazon");

		System.out.println(Company.size());
		Collections.sort(Company);
	for (String comp : Company) {
		System.out.println(comp);
		
		for(int i= Company.size()-1;i>=0;i--)
		{
			rev.add(Company.get(i));
			
		}
	for (String comp2 : rev) {
		System.out.println(comp2);
	}
		

	}
		

	}

}
