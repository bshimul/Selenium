package string;

public class Print111to999 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=0;
		for(int i=1;i<=9;i++)
		{
			a=i*100+i*10+i;
			System.out.println(a);
		}

	}

}
