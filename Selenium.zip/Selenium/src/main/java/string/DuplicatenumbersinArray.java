package string;

import java.util.ArrayList;
import java.util.List;

public class DuplicatenumbersinArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]={1,2,3,2,4,1,5,6,3};
		List<Integer> b=new ArrayList<Integer>();
		List<Integer> c=new ArrayList<Integer>();
		for (Integer integer : a) {
			if(!b.contains(integer))
			{
				b.add(integer);
			}
			else
			{
				c.add(integer);
			}
			
			
		}
		System.out.println(b);
		System.out.println(c);
		
		
			
		

	}

}
