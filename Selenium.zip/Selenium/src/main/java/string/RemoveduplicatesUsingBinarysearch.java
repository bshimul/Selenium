package string;

import java.util.Arrays;

public class RemoveduplicatesUsingBinarysearch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a[]={1,2,3,2,4,5,1,6};
//System.out.println(a[0]);
Arrays.sort(a);
System.out.println(a.length);

System.out.print("Removed duplicates:");
for(int i=0;i<a.length-1;i++)
{
if(a[i]!=a[i+1])
{
	System.out.print(" "+a[i]);
}


	
	/*if(a[i]==a[i-1])
	{
		System.out.println("Duplicated number:"+a[i]);
	}*/
//Print only non duplicated number:
	//doubt
/*if(a[0]!=a[i+1])
{
	System.out.println(a[0]);
}
else if(a[a.length-1]!=a[i-1])
{
	System.out.println(a[a.length-1]);
}
else
{
	if((a[i]!=a[i+1])&&(a[i]!=a[i-1]))
	{
		System.out.println(a[i]);
	}
}
	
}*/
	}
	}
}
