package string;

public class CountCharacteinString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String S="Cognizant";
		int count =0;
		for(int i=0;i<S.length();i++)
		{
			if(S.charAt(i)=='n')
			{
			count++;
			}
			
		}
		System.out.println(count);
// replace method	
int oldcount =S.length();
count=0;
String A= S.replace("n","");
int newcount = A.length();
int R= oldcount-newcount;
System.out.println(R);

//split Method
String[] a= S.split("n");
int D= a.length-1;
System.out.println(D);


}
}

// comparison of string use .equals
//to compare two characters use ==

// 2)  second method
// String company="cognizant";
// char[] comp=company.toCharArray();
//foreach(char c:comp)
// {if(c==comp)}
//count++;