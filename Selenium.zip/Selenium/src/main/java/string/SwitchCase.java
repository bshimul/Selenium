package string;

public class SwitchCase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10;
		int[][] x[];
        switch(a++)
        {
        case 10:
             switch(a--){
             default:System.out.print("Exit");
             case 10:
            }
        default:System.out.print(a);
        }
        }
   }




