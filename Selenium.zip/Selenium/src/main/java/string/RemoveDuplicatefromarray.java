package string;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class RemoveDuplicatefromarray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]={1,3,2,1,3,1,5,6};
		List<Integer> st=new ArrayList<Integer>();
		for(int i=0;i<a.length;i++)
        st.add(a[i]);
		
		Set<Integer>S = new LinkedHashSet<Integer>(st);
		
		for(Integer num :S)
			System.out.print(num+" ");
	}

}

