package string;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Removemorethanonewhitespaceandtrailing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		        System.out.println("Enter the String:");
		        Scanner sc=new Scanner(System.in);
		        String str =sc.next();
		        Removemorethanonewhitespaceandtrailing mpr = new Removemorethanonewhitespaceandtrailing();
		        System.out.println(mpr.replaceWithPattern(str, " "));
		    }

		    public String replaceWithPattern(String str,String replace){
		         
		        Pattern ptn = Pattern.compile("\\s+");
		        Matcher mtch = ptn.matcher(str);
		        return mtch.replaceAll(replace);
		    }
		     
		
//char s [] = S.toCharArray();
char newS [] = new char [len];
//System.out.println(S.trim());
int count = 0;
for(int i=0;i<len;i++){
	if(i==0 || i==len-1){
		if(s[i]!=' ')
		newS[count++] = s[i];
	}
		
	else{
		if(s[i]==' '){
			if(s[i-1]!=' ')
				newS[count++] = s[i];
		}
		else
		newS[count++] = s[i];
	}
		
}

for(int i=0;i<count;i++){
System.out.print(newS[i]);
}

}
}