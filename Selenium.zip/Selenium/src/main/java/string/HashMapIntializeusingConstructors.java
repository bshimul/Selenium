package string;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class HashMapIntializeusingConstructors {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<Character,Integer> test=new HashMap<Character, Integer>();
		

	}

}
