package string;

import java.util.LinkedHashSet;
import java.util.Set;

public class DuplicatesRemoval {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String S = "HelloWorld";
		char[] str = S.toCharArray();
		Set<Character> chr = new LinkedHashSet<Character>();
		
		for(int i=0;i<str.length;i++){
//if(!chr.contains(str[i]))  (for list it will be applicable)

				chr.add((str[i]));
		}
		
		for(Character c : chr)
			System.out.print(c);
	}
		

	}

