package week2Day1;

import org.openqa.selenium.chrome.ChromeDriver;

public class LearnAlert {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
ChromeDriver driver=new ChromeDriver();
driver.get("https://www.w3schools.com/js/tryit.asp?filename=tryjs_prompt");
driver.switchTo().frame("iframeResult");
driver.findElementByXPath("/html/body/button").click();
driver.switchTo().alert().sendKeys("hemakeerthi");
Thread.sleep(2000);
driver.switchTo().alert().accept();
String text=driver.findElementById("demo").getText();
//if(text.contains("hemakeerthi"))
if(text.contains("hemakeerthi"))
{
	System.out.println("Successful");
}

	}

}
