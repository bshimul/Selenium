package week2Day1;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class CountFrame {

	public static void main(String[] args) {
		// TODO Auto-generated method stud
		System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
		//http://layout.jquery-dev.com/demos/iframes_many.html
		ChromeDriver driver=new ChromeDriver();
		driver.get("http://layout.jquery-dev.com/demos/iframe_local.html");
		driver.manage().window().maximize();
		List<WebElement> framecount =driver.findElementsByTagName("iframe");
		int parentframe=framecount.size();
		int count=0;
		count=parentframe;
		for(int i=0;i<parentframe;i++)
		{
			driver.switchTo().frame(framecount.get(i));
			List<WebElement> coun=driver.findElementsByTagName("iframe");
			int childframe=coun.size();
			if(childframe!=0)
			count=count+childframe;
			driver.switchTo().parentFrame();
			
		}
		System.out.println(count);
		
	}

}

