package week2Day1;

import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;

public class LearnWindowhandle {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
		ChromeDriver driver=new ChromeDriver();
		driver.get("https://www.irctc.co.in/eticketing/loginHome.jsf");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS );
		driver.findElementByLinkText("Contact Us").click();
		Set <String> allwindow=driver.getWindowHandles();
		int i=allwindow.size();
		System.out.println(i);
		for (String eachwin : allwindow) {
			driver.switchTo().window(eachwin);
			
		}
		Thread.sleep(2000);
		System.out.println(driver.getTitle());
	System.out.println(driver.getCurrentUrl());
driver.quit();
	}
	

}
