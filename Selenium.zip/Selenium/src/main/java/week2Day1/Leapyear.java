package week2Day1;

import java.util.Scanner;

public class Leapyear {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number");
		int year=sc.nextInt();
		
		 boolean isLeapYear = false;
		 
	        if(year % 400 == 0)
	        {
	            isLeapYear = true;
	        }
	        else if (year % 100 == 0)
	        {
	            isLeapYear = false;
	        }
	        else if(year % 4 == 0)
	        {
	            isLeapYear = true;
	        }
	        else
	        {
	            isLeapYear = false;
	        }
	 
	        //Output the test result
	        if(isLeapYear)
	        {
	            System.out.println("Year "+year+" is a Leap Year");
	        }
	        else
	        {
	            System.out.println("Year "+year+" is not a Leap Year");
	        }
	 
	    }
	
	}


