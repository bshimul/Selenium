package week2Day1;

public class arrayList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = {13,15,67,13,99,67,65,87};
		int length= arr.length;
	    // Pick all elements one by one
	    for (int i=0; i<arr.length; i++)
	    {
	        // Check if the picked element is already printed
	        int j;
	        for (j=0; j<i; j++)
	           if (arr[i] == arr[j])
	               break;
	 
	        // If not printed earlier, then print it
	        if (i == j)
	          System.out.println(arr[i]);
	}

	}

}
