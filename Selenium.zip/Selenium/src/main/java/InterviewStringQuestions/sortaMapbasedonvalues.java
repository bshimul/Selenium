package InterviewStringQuestions;


import java.util.ArrayList;
import java.util.Collections;
//import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;
//import java.util.Set;
//import java.util.TreeMap;

import org.apache.commons.collections4.map.HashedMap;
import org.junit.internal.runners.model.EachTestNotifier;

public class sortaMapbasedonvalues {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedHashMap<String,Integer> a=new LinkedHashMap<String, Integer>();
		List<Integer> b=new ArrayList<Integer>();
		a.put("One", 1);
		a.put("Seventeen",17);
		a.put("Twelve",12);
		a.put("Five",5);
		a.put("Two",2);
		a.put("Twenty two",22);
		for (Entry<String,Integer> ch : a.entrySet()) {
			System.out.println(ch.getKey()+" : "+ch.getValue());
			b.add(ch.getValue());
			
			}
		System.out.println(b);
		Collections.sort(b);
		System.out.println(b);
	
	for(Integer each : b){
		for(Entry<String, Integer> z : a.entrySet()){
			if(z.getValue()==each)
			System.out.println(z.getKey()+" : "+z.getValue());
		}
	}
	}
}
	
		


