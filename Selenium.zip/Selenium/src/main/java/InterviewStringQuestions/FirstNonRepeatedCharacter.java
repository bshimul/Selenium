package InterviewStringQuestions;

public class FirstNonRepeatedCharacter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s1="keerthi";
		String s2="keerthi";
		if(s1==s2)
		{
			System.out.println("TRue");
		}
		else
		{
			System.out.println("false");
		}
	}

}
