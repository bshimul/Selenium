package InterviewStringQuestions;

public class NumbertoWord {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n= 232;
		int num[]=new int[10];
		int r=0;
		int p=0;
		
		for(int i=3;i>=0;i--){
			num [i] = n%10;
			n = n/10;
			//System.out.println(num[i]);
		}
		
			
			
		
String [] tens = {" ", "Ten", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy","Eighty","Ninety"};
String[] tens1={" ","Eleven","Twelve","Thirteen","Forteen","fifteen","Sixteen","Seventeen","Eighteen","Nineteen"};
String [] ones = {" ","One","Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine"};
int a=ones.length;
//System.out.println(a);
if((num[2]!=1))
{
	for(int i=1;i<=a;i++)

{
if(num[1]==i)	
{   
	System.out.print(ones[i]+" Hundred And ");
}
if((num[2]==i)&&(num[3]==0) || (num[2]==i))
	
{
	System.out.print(tens[i]);
	
}
/*//if((num[2]==1)&&(num[3]==i))
{
	System.out.println(tens1[i]);
	}*/

 
if((num[3]==i)&&(num[3]!=0))
{
	System.out.println(" "+ones[i]);
}

}
}


/*int n=123;
String s=Integer.toString(n);
int j=0;
    
	int i=1;
	if(s.charAt(0)==i)
		System.out.println(ones[i+1]+"Hundred And");
	else
		i++;*/
}
}	
