package InterviewStringQuestions;

public class Palindromenumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a=121;
		String s=Integer.toString(a);
		StringBuffer b=new StringBuffer(s);
		StringBuffer rev= new StringBuffer();
		/*for(int i=s.length()-1;i>=0;i--)
		{
		rev= rev+s.charAt(i);	
		}
		System.out.println(rev);
*/		
		 rev=b.reverse();

		if(s.equals(rev.toString()))
		
		{
			System.out.println("Palindrome");
		}
		else
		{
			System.out.println("Not Palindrome");
		}
		
       
	}

}
