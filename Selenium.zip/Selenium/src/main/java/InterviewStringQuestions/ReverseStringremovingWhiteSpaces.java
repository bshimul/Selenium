package InterviewStringQuestions;

public class ReverseStringremovingWhiteSpaces {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String S= "I Love India";
		String M=new String();
		S=S.replace(" ","");
		int b=S.length();
		for(int i=S.length()-1;i>=0;i--)
		{
			M=M+S.charAt(i);
		}
		System.out.println(M);
		
}
}
