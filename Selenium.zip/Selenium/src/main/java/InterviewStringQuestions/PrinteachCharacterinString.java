package InterviewStringQuestions;

public class PrinteachCharacterinString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String S="I Love India";
char[] ch=S.toCharArray();
for(int i=0;i<=S.length()-1;i++)
{
	System.out.println(ch[i]);
}
// 2 method
for(int i=0;i<=S.length()-1;i++)
{
	System.out.println(S.charAt(i));
	
}
	}

}
