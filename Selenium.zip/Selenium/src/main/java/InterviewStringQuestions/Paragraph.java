package InterviewStringQuestions;

public class Paragraph {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String a="dress fdtf dress gyg dress gfhvtgy dress hgjbhu dtdugu tfvrt dress gyg";
		String[] arr=a.split(" ");
		int count=0;
		for (String string : arr) {
			if(string.contains("dress"))
			{
				count++;
			}
			
		}
		System.out.println(count);
		/*int b=a.length();
		System.out.println(b);
		//StringBuffer b=new StringBuffer(a);
		String S= a.replace("dress","");
		System.out.println(S);
		int c=S.length();
		System.out.println(S.length());
		int d=b-c;
		//System.out.println(d);
*/		
		

	}

}
