package week1Day1;

import org.openqa.selenium.support.ui.Select;
import java.util.List;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class countrydropdown {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int count =0;
System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
ChromeDriver driver =new ChromeDriver();
driver.get("https://www.irctc.co.in/eticketing/userSignUp.jsf");
Select country =new Select(driver.findElementById("userRegistrationForm:countries"));
List<WebElement> op = country.getOptions();
for (WebElement ele : op) 
{
	//Run the loop when the country name starts with 'E'
	if (ele.getText().startsWith("E"))
	{
		count++;
		while(count==2)
		{
		country.selectByVisibleText(ele.getText());
		break;
		}
	}
		
		
}


	}

}