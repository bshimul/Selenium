package week1Day1;

import java.util.Scanner;

public class fact {

	public static void main(String[] args) {
		// TODO Auto-generated method stub;
		int fact =1,i;
		Scanner scan=new Scanner(System.in);
		System.out.println("please enter the number:");
		// getting input from the user through console
		int n=scan.nextInt();
		for(i=1;i<=n;i++)
		{
		fact=fact*i;
		
		

	}System.out.println("Factorial of"+n+"is:"+fact);
}
}
