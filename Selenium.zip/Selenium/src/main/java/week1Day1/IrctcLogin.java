package week1Day1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class IrctcLogin {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
	
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver ();
		
			
			driver.get("https://www.irctc.co.in/eticketing/userSignUp.jsf");
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
			driver.manage().window().maximize();	
			
		driver.findElementById("userRegistrationForm:userName").sendKeys("kkeertu");
		driver.findElementById("userRegistrationForm:password").sendKeys("Choco6");
		driver.findElementById("userRegistrationForm:confpasword").sendKeys("Choco6");
		WebElement sc = driver.findElementById("userRegistrationForm:securityQ");
		Select obj = new Select (sc);
		obj.selectByVisibleText("What is your pet name?");
		driver.findElementById("userRegistrationForm:securityAnswer").sendKeys("Snowy");
		WebElement lan = driver.findElementById("userRegistrationForm:prelan");
		Select obj1 = new Select (lan);
		obj1.selectByValue("en");
		driver.findElementById("userRegistrationForm:firstName").sendKeys("keerthi");
		driver.findElementById("userRegistrationForm:middleName").sendKeys("M");
		driver.findElementById("userRegistrationForm:lastName").sendKeys("Murugesan");
		driver.findElementById("userRegistrationForm:gender:1").click();
		driver.findElementById("userRegistrationForm:maritalStatus:1").click();
		WebElement DO1 = driver.findElementById("userRegistrationForm:dobDay");
		Select obj3 = new Select (DO1);
		//List<WebElement> options = obj3.getOptions();
		obj3.selectByIndex(6);
		WebElement DO2 = driver.findElementById("userRegistrationForm:dobMonth");
		Select obj4 = new Select (DO2);
		//List<WebElement> options = obj4.getOptions();
		obj4.selectByIndex(4);
		WebElement DO3 = driver.findElementById("userRegistrationForm:dateOfBirth");
		Select obj5 = new Select (DO3);
		obj5.selectByVisibleText("1994");
		WebElement occupation = driver.findElementById("userRegistrationForm:occupation");
		Select obj6 = new Select (occupation);
		obj6.selectByVisibleText("Private");
		driver.findElementById("userRegistrationForm:email").sendKeys("keerthi.m1994@gmail.com");
		driver.findElementById("userRegistrationForm:mobile").sendKeys("8344393391");
		WebElement nationality = driver.findElementById("userRegistrationForm:nationalityId");
		Select obj7 = new Select (nationality);
		obj7.selectByVisibleText("India");
		
		
		Thread.sleep(2000);
		driver.findElementById("userRegistrationForm:address").sendKeys("114");
		driver.findElementById("userRegistrationForm:street").sendKeys("NirmalH block");

		WebElement country = driver.findElementById("userRegistrationForm:countries");
		Select obj8 = new Select (country);
		obj8.selectByVisibleText("India");
		driver.findElementById("userRegistrationForm:pincode").sendKeys("625003");
		driver.findElementById("userRegistrationForm:statesName").sendKeys("TAMIL NADU");
		driver.findElementById("userRegistrationForm:statesName").click();
		Thread.sleep(2000);
		WebElement city = driver.findElementById("userRegistrationForm:cityName");
		Select obj9 = new Select (city);
		obj9.selectByVisibleText("Madurai");
		Thread.sleep(2000);
		WebElement postOffice = driver.findElementById("userRegistrationForm:postofficeName");
		Select obj10 = new Select (postOffice);
		obj10.selectByValue("Test Post");
		Thread.sleep(2000);
		driver.findElementById("userRegistrationForm:landline").sendKeys("04522374791");
		driver.findElementById("userRegistrationForm:resAndOff:0").click();

		//close browser
		//driver.close();
		
	}

}