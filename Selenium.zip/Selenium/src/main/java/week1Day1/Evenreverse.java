package week1Day1;

public class Evenreverse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i =200,even=0;
     
   do
   {
    	even=i%2;
       if(even==0)
       {
    	   System.out.println(i);
       }
       i--;
	}while(i>=100);
     

}
}

