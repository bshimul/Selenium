package week1Day1;

import java.util.ArrayList;
import java.util.List;

public class Substring {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String S="ABBCCDALLJM";
char[] sarr=S.toCharArray();
List<String> A=new ArrayList<String>();
int i,j,k;
i=j=0;
String prnt;
int len=S.length();
for(k=1;k<len;k++)
{
if(S.charAt(k)==S.charAt(k-1))
{
	A.add(S.substring(i,j+1));
	i=k;
	j++;
}
else
	j++;

}
A.add(S.substring(i));
int max=A.get(0).length();
prnt=str.get(0);
for()
}