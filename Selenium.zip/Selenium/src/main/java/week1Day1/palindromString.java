package week1Day1;

import java.util.Scanner;

public class palindromString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter the string:");
		Scanner sc=new Scanner(System.in);
		String p="";
		String check=sc.nextLine();
		int length=check.length();
		for(int i=length-1;i>=0;i--)
		{
			p=p+check.charAt(i);
		}
		if(p.equals(check))
		{
			System.out.println("String is a Palindrome");
		}
		else
		{
			System.out.println("String is not a Palindrome");
		}
}

}
