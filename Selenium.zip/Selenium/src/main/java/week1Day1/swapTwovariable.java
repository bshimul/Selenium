package week1Day1;

import java.util.Scanner;

public class swapTwovariable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the first number:");
		int n= sc.nextInt();
		System.out.println("Enter the second number");
		int m=sc.nextInt();
		System.out.println("Swapping of two variables without using additionalvariable");
		n=n+m;
		m=n-m;
		n=n-m;
		System.out.println("n="+n);
		System.out.println("m="+m);

	}

}
