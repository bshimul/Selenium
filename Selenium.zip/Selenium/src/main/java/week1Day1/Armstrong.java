package week1Day1;
import java.util.Scanner;

public class Armstrong {

	int x;
		int findArmstrong(int n,int a)

		{

		if(n!=0)

		{

			x=n%10;

			a=a+(x*x*x);

			n/=10 ;

			return findArmstrong(n,a);

		}
return a;

		}


public static void main(String[] arg)
{
Armstrong A=new Armstrong();
int arm;
System.out.println("Armstrong numbers between 1 to 1000");
for(int num=1;num<500;num++)
{
arm=A.findArmstrong(num,0);
if(arm==num)
System.out.println(num);
}
}
}

	

	
