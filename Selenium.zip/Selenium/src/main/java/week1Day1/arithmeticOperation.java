/**
 * 
 */
package week1Day1;

import java.util.Scanner;

public class arithmeticOperation {


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc =new Scanner(System.in) ;
		System.out.println("Enter the first number:");
		int n= sc.nextInt();
		System.out.println("Enter the second number");
		int m=sc.nextInt();
		System.out.println("Enter the Arithmetic Operation from the Below options : 1.Add" + "\n" + "2.Substract"+ "\n"+"3.Multiply"+"\n"+"4.Divide");
		String l=sc.next();
		if(l.equals("Add"))
		{
			int c=n+m;
		System.out.println("Addition of two numbers:"+c);
		}
		if(l.equals("Subtract"))
		{
			if(n>m)
			{
				int s =n-m;
				System.out.println("Subtraction of two numbers:"+s);
			}
			else
			{
				int q=m-n;
				System.out.println("Subtraction of two numbers:"+q);
			}
			}
		if(l.equals("Multiply"))
		{
			int o =n*m;
			System.out.println("Multiplication of two numbers:"+o);
		}
			if(l.equals("Divide"))
			{
				int r=n/m;
				System.out.println("Division of two numbers:"+r);
			
			}
				
			if(!l.equals("Add")&&!l.equals("Subtract")&&!l.equals("Multiply")&&!l.equals("Divide"))
			{
			System.out.println("Enter the valid options from 1 to 4");
			}		}
			
	}


