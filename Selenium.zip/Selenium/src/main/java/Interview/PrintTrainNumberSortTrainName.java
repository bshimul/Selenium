package Interview;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class PrintTrainNumberSortTrainName {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver ();
		
			//Load URL
			driver.get("https://erail.in/");
			//Implicit wait
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
			//Maximize
		   driver.manage().window().maximize();	
		   driver.findElementByXPath("//input[@id='buttonFromTo']").click();
		   WebElement table=driver.findElementByXPath("//table[@class='DataTable TrainList']");
	       List<WebElement> rowcount=table.findElements(By.tagName("tr"));
	       List<WebElement> col =driver.findElementsByXPath("//table[@class='DataTable TrainList']/tbody/tr[1]/td");
	       int a=col.size();
	       int b=rowcount.size();
	       
	       List<String> secColList= new ArrayList<String>();
	     
	       for(int i=1;i<=b;i++)
	       {
	    	 
	    	   String firstxpath="//table[@class='DataTable TrainList']/tbody/tr["+i+"]/td[2]";
	 	       //driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS) ;
	 	       String text= driver.findElement(By.xpath(firstxpath)).getText();
	 	      secColList.add(text);
	 	      System.out.println(text);
	 	      if(text.equals("DEHRADUN EXP"))
	 	    	  break;
	 	      
	         
	       }
	       System.out.println(secColList.size());
	       List <String> desc = new ArrayList<String>();
			desc.addAll(secColList);
			Collections.sort(desc);
			System.out.println(desc);
			
			if(desc==secColList)
				System.out.println("True");
			else
				System.out.println("False");
	       
		   
		   
		   

	}

}
