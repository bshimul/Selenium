package Interview;

import java.awt.Desktop.Action;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class ClearTripDropdown {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver ();
		driver.get("https://www.cleartrip.com/");
		driver.manage().window().maximize();
		driver.findElementByXPath("//input[@data-responsemodifier='responseModifierFlight']").sendKeys("kol");
		Actions builder=new Actions(driver);
		Thread.sleep(5000);
		builder.moveToElement(driver.findElementByLinkText("Kolkata, IN - Netaji Subhas Chandra Bose Airport (CCU)")).click();
		driver.close();

	}

}
