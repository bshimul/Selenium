package Interview;

import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

//import org.openqa.selenium.chrome.ChromeDriver;

public class GmailInbox {

	private static final TimeUnit TimeUnit = null;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver ();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);	
		driver.get("www.gmail.com");
		driver.findElementByXPath("//div[contains(@class,'wDzjuc hPcO1c')][1]//following::p[2]").click();
		driver.findElementByXPath("//input[@aria-label='Enter your password']").sendKeys("Shiradi@1994");
		driver.close();
		*/
		String S="Inbox12345";
		String N="[\\d]";
		Pattern P= Pattern.compile(N);
		Matcher match=P.matcher(S);
		while(match.find())
		{
			String group=match.group();
			System.out.println(group);
		}

	}

}
