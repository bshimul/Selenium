package Interview;

import java.util.Set;

public class Moveto3Window {
	public void switchToThirdWindow() {
		try{
		Set<String> allWin = driver.getWindowHandles();
		int i=0;
		for (String eachWin : allWin) {
			i++;
			driver.switchTo().window(eachWin);
			
			if(i==3)
				break;
		}
		System.out.println("The window is switched to "+driver.getTitle());
		}
		catch(NoSuchWindowException e)
		{
			System.err.println("Window not found");
		}

}
