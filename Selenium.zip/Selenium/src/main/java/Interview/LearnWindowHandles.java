

		package Interview;
		import java.util.ArrayList;
import java.util.List;
import java.util.Set;
		import java.util.concurrent.TimeUnit;

		import org.openqa.selenium.WebElement;
		import org.openqa.selenium.chrome.ChromeDriver;
		import org.openqa.selenium.interactions.Actions;

		public class LearnWindowHandles {

			public static void main(String[] args) throws InterruptedException {
				// TODO Auto-generated method stub
				System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
				ChromeDriver driver = new ChromeDriver ();
				
				
				 driver.get("https://www.flipkart.com/");
				 driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);		
				 driver.manage().window().maximize();
				 
				 WebElement item1 = driver.findElementByXPath("//span[text()='Electronics']");		 
				 
				 Actions builder = new Actions (driver);
				 builder.moveToElement(item1).build().perform();
				 Thread.sleep(2000);
					builder.click(driver.findElementByXPath("//span[text()='Mobile Cases']"))
					.build()
					.perform();
					
				driver.findElementByLinkText("Flipkart SmartBuy Back Cover for Mi Redmi Note 4").click();
					//driver.findElementByLinkText("KartV Back Cover for Redmi Note 4").click();
					driver.findElementByLinkText("Flipkart SmartBuy Back Cover for Motorola Moto E4 Plus").click();
					//driver.findElementByLinkText("Flipkart SmartBuy Back Cover for Mi Redmi Note 4").click();
					int i=0;
					Set<String> allWin = driver.getWindowHandles();
					System.out.println(allWin);
					String mainwindow = driver.getWindowHandle();
			List<String> tabs=new ArrayList<String>(allWin);
					driver.switchTo().window(tabs.get(2));
					driver.close();
					driver.switchTo().window(tabs.get(0));
					
					
					/*int j=-1;
					for (String eachWin : allWin) {
						driver.switchTo().window(eachWin);
						j++;
						if(j!=0){
						if(driver.getTitle()!= "Noise Back Cover for Mi Redmi Note 4 - Noise : Flipkart.com"){
							driver.close();
						}
						}
						driver.switchTo().window(mainwindow);*/
						
					}
			}
		
			


