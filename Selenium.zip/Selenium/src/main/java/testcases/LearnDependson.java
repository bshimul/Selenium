package testcases;

import org.testng.annotations.Test;
import org.testng.annotations.TestInstance;

public class LearnDependson {
	@Test(priority=1)
public void createLead()
{
	System.out.println("Create lead");
}

//@Test(dependsOnMethods={"createLead"})
@Test(priority=2)
public void Edit()
{
	System.out.println("Edit lead");
}
@Test(priority=5)
	public void duplicateLead()
	{
		System.out.println("Create lead");
	}
@Test(priority=4)
public void MergeLead()
{
	System.out.println("Merge Lead");
}
@Test(priority=5)
public void DeleteLead()

{
System.out.println("Deleted Lead");
}
}

