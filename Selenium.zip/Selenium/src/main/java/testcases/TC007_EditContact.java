package testcases;

import wrappers.WrapperMethods;

public class TC007_EditContact extends WrapperMethods {

	public void editContact()  {
		// TODO Auto-generated method stub
		invokeApp("chrome", "http://leaftaps.com/opentaps");
		enterById("username", "DemoSalesManager");
		enterById("password", "crmsfa");
		clickByClassName("decorativeSubmit");
		clickByLink("CRM/SFA");
		//Click Contact
		clickByLink("Contacts");
		clickByLink("Find Contacts");
		enterByXpath("(//div[@class='x-form-element'])[3]/input", "karthik");
		clickByXpath("//button[text()='Find Contacts']");
		clickByXpath("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a");
		//Verify Title of the page
		verifyTitle("View Contact | opentaps CRM");
		clickByLink("Edit");
		enterByXpath("(//input[@id='updateContactForm_firstName'])[1]", "keerthi");
		selectIndexById("addMarketingCampaignForm_marketingCampaignId",2);
		clickByXpath("//input[@value='Update']");
		verifyTextById("viewContact_firstName_sp","keerthi");
		closeBrowser();
		
		
	}

}
