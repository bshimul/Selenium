package testcases;
import org.junit.Test;

import wrappers.WrapperMethods;
 
public class TC003_deleteLead extends WrapperMethods
{
@Test
public void deleteLead() {
	invokeApp("chrome","http://leaftaps.com/opentaps");
	enterById("username", "DemoSalesManager");
	enterById("password", "crmsfa");
	clickByClassName("decorativeSubmit");
	clickByLink("CRM/SFA");
	clickByLink("Leads");
	clickByLink("Find Leads");
	clickByXpath("//span[text()='Phone']");
	enterByName("phoneNumber","8344393391");
	clickByXpath("//button[contains(text(),'Find Leads')]");
	getTextByXpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a");
	clickByXpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a");
	clickByLink("Delete");
	clickByXpath("//button[contains(text(),'Find Leads')]");
	String capture= getTextByXpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a");
	enterByName("id", capture);
	clickByXpath("//button[contains(text(),'Find Leads')]");
	verifyTextContainsByXpath("//div[contains(text(),'No records to display')]" , "No records to display");
	//clickByClassName("subMenuButtonDangerous");
	//clickByLink("Find Leads");
	//String capture= getTextByXpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a");
	//enterByName("id",capture);
	//clickByLink("Find Leads");
	//verifyTextContainsByXpath("//div[contains(text(),'No records to display')]" , "No records to display");
	//verifyTextByXpath("//div[contains(text(),'No records to display')]","No records to display");
	closeBrowser();
	
	
	
	
}
		// TODO Auto-generated method stu

	}


