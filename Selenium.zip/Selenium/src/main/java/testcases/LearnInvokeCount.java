package testcases;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;


public class LearnInvokeCount {

	@Test(invocationCount=2)
	public void main() {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://leaftaps.com");
		driver.manage().window().maximize();
		driver.findElementById("username").sendKeys("DemoSalesManager");
		driver.findElementById("password").sendKeys("crmsfa");
		driver.findElementByClassName("decorativeSubmit").click();
		driver.findElementByXPath("//*[@id='label']/a").click();
		driver.findElementByXPath("//*[@id='left-content-column']/div[1]/div[2]/ul/li[1]/a").click();
		System.out.println("Create Lead is clicked");
		driver.findElementById("createLeadForm_companyName").sendKeys("TestCompany");
		System.out.println("Testcompany is entered Successfully");
		driver.findElementByXPath("//*[@id='createLeadForm_firstName']").sendKeys("TestfirstName");
		System.out.println("FirstName is entered successfully");
		driver.findElementByXPath(" //*[@id='createLeadForm_lastName']").sendKeys("TestLastname");
		System.out.println("Lastname is entered successfully");
		driver.findElementByClassName("smallSubmit").click();
		System.out.println("Create Lead Button entered successfully");
		

	}

}
