package testcases;
import org.junit.Test;

import wrappers.WrapperMethods;


public class TC005_DuplicateLead extends WrapperMethods {
   @Test
	public  void duplicateLead() {
		// TODO Auto-generated method stub
	   invokeApp("chrome", "http://leaftaps.com/opentaps");
		enterById("username", "DemoSalesManager");
		enterById("password", "crmsfa");
		clickByClassName("decorativeSubmit");
		//clickByClassName("decorativeSubmit");
		clickByLink("CRM/SFA");
		clickByLink("Leads");
		clickByLink("Find Leads");
		clickByXpath("//span[contains(text(),'Email')]");
		enterByName("emailAddress", "keerthi.m1994@gmail.com");
		clickByXpath("//button[contains(text(),'Find Leads')]");
		String capture=getTextByXpath("//div[@class='x-grid3-cell-inner x-grid3-col-firstName']/a");
		clickByXpath("//div[@class='x-grid3-cell-inner x-grid3-col-firstName']/a");
		clickByLink("Duplicate Lead");
		verifyTitle("Duplicate Lead");
		clickByClassName("smallSubmit");
		verifyTextById("viewLead_firstName_sp", capture);
		closeBrowser();
		
		

	}

}
