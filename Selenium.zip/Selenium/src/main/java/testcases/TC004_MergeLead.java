package testcases;
import org.junit.Test;

import wrappers.WrapperMethods;

public class TC004_MergeLead extends WrapperMethods {
	
@Test
public void Mergelead()
		{

	invokeApp("chrome", "http://leaftaps.com/opentaps");
	enterById("username", "DemoSalesManager");
	enterById("password", "crmsfa");
	clickByClassName("decorativeSubmit");
	clickByLink("CRM/SFA");
	clickByLink("Leads");
	clickByLink("Merge Leads");
	clickByXpath("(//img[@alt='Lookup'])[1]");
	switchToLastWindow();
	enterByXpath("//label[contains(text(),'Lead ID:')]/following::input", "10415");
	clickByXpath("//button[contains(text(),'Find Leads')]");
	clickByXpathNoSnap("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a");
	switchToParentWindow();
	clickByXpath("(//img[@alt='Lookup'])[2]");
	switchToLastWindow();
	enterByXpath("//label[contains(text(),'Lead ID:')]/following::input", "10416");
	clickByXpath("//button[contains(text(),'Find Leads')]");
	clickByXpathNoSnap("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a");
	switchToParentWindow();
	clickByLinkNoSnap("Merge");
	acceptAlert();
	clickByLink("Find Leads");
	enterByXpath("//label[contains(text(),'Lead ID:')]/following::input", "10415");
	clickByXpath("//button[contains(text(),'Find Leads')]");
	verifyTextByXpath("//div[contains(text(),'No records to display')]","No records to display");
	//verifyTextContainsByXpath("//div[contains(text(),'No records to display')]", "No records to display");
	closeBrowser();
	
	
	
	
	
	
		}

	}


