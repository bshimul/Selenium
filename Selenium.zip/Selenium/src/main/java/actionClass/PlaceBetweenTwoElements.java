package actionClass;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class PlaceBetweenTwoElements {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
		ChromeDriver driver=new ChromeDriver();
		driver.get("http://jqueryui.com/sortable/");
		driver.manage().window().maximize();
		driver.switchTo().frame(driver.findElementByClassName("demo-frame"));
       WebElement item1= driver.findElementByXPath("//ul[@id='sortable']/li[1]");
       WebElement item4=driver.findElementByXPath("//ul[@id='sortable']/li[4]");
       Actions builder=new Actions(driver);
        int x=item4.getLocation().getX();
        int y=item4.getLocation().getY();
        builder.clickAndHold(item1).dragAndDropBy(item4,x,y).release().build().perform();
        driver.close();
       
	}

}
