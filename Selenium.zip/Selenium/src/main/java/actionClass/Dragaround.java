package actionClass;

import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;



public class Dragaround {
	public static void main(String args[])
	
	{
		System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
		ChromeDriver driver=new ChromeDriver();
		driver.get("http://jqueryui.com/draggable/");
		driver.manage().window().maximize();
		WebElement draggable=driver.findElementByClassName("ui-widget-content ui-draggable ui-draggable-handle");
	  Point loc= driver.findElementByClassName("ui-widget-content ui-draggable ui-draggable-handle").getLocation();
	   System.out.println(loc);
	   Actions builder=new Actions(driver);
	   builder.dragAndDropBy(draggable,20,20).build().perform();
	   System.out.println("performed successfully");
	   
	}
	

}
