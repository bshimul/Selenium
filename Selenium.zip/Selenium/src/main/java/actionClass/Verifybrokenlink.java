package actionClass;

import java.io.IOException;
import java.net.HttpURLConnection;
//import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

//import org.junit.internal.runners.model.EachTestNotifier;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

//import com.gargoylesoftware.htmlunit.javascript.host.URL;

public class Verifybrokenlink {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
		ChromeDriver driver=new ChromeDriver();
		driver.get("https://www.google.co.in");
		List<WebElement> element=driver.findElements(By.tagName("a"));
		for (WebElement webElement : element) {
			System.out.println(webElement);
		}
	int count=element.size();
	for(int i=0;i<count;i++)
	{
		WebElement e=element.get(i);
		String url=e.getAttribute("href");
		verifyLink(url);
	}

	}

	private static void verifyLink(String lurl) {
		// TODO Auto-generated method stub
		try {
			URL url= new URL(lurl);
			HttpURLConnection httpconnect=(HttpURLConnection)url.openConnection();
			httpconnect.setConnectTimeout(3000);
			httpconnect.connect();
			if(httpconnect.getResponseCode()==200)
			{
				System.out.println(lurl+" "+httpconnect.getResponseMessage());
			}
		} catch (Exception e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
	}

}
