package week3;

public class Vehicle {
	Vehicle()
	{
		System.out.println("Super class:Vehicle");
	}
	

}
