package week3;

public class Car extends Vehicle {
	Car()
	{
		System.out.println("Car is a Sub class for Vehicle and Parent class for Audi");
	}

}
