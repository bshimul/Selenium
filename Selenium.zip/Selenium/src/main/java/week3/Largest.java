package week3;

import java.util.Scanner;

public class Largest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in =new Scanner(System.in);
		System.out.println("enter number");
		int number=in.nextInt();
		int temp ;
		System.out.println("Enter the digit");
		int gd =in.nextInt();
		temp=number-1;
		
			int num,r;
			while(temp!=0)
			{
			num=temp;
			int c=0;
			while(num>0)
			{
			r=num%10;
			num=num/10;
			if(r==gd)
			{
			c++;
			break;
			}
			}
			if(c==1)
			{
			temp=temp-1;
			}
			else{
			break;
			}
			}
			System.out.println(temp);
			}
			}


