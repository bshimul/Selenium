package week3;

public class Audi extends Car{
	
Audi()
{
System.out.println("Child Class Audi");	
}

public static void main(String args[]) 
{
	Audi A =new Audi();
	
}
}
