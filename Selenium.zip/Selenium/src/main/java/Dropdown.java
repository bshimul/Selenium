import java.util.List;

import org.apache.poi.ss.formula.functions.Count;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Dropdown {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
ChromeDriver driver = new ChromeDriver();
driver.get("https://www.irctc.co.in/eticketing/userSignUp.jsf");
driver.manage().window().maximize();
Select country=new Select(driver.findElementById("userRegistrationForm:countries"));
country.selectByVisibleText("India");
//List<WebElement> alloptions=country.getOptions();
//int count= alloptions.size();
//for(int i=1;i<=count;i++)
//{
//System.out.println(alloptions.get(i).getText());

	//}
}
}
