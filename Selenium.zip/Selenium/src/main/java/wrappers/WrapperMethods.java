package wrappers;

import java.io.File;
import java.io.IOException;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.ObjectUtils.Null;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;



public class WrapperMethods implements Wrappers{
	RemoteWebDriver driver;
	int i=1;
	public void invokeApp(String browser, String url) {
		if(browser.equalsIgnoreCase("chrome")){
			System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
			driver = new ChromeDriver();
		}else if(browser.equalsIgnoreCase("firefox")){
			System.setProperty("webdriver.gecko.driver", "./drivers/geckodriver.exe");
			driver = new FirefoxDriver();
		}
		driver.get(url);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);		
		driver.manage().window().maximize();
		System.out.println("The browser "+browser+" is launched");
		takeSnap();
	}

	public void enterById(String idValue, String data) {
		try{
		driver.findElementById(idValue).clear();
		driver.findElementById(idValue).sendKeys(data);
		System.out.println("The text field "+idValue+" is entered with value :"+data);
		}
		catch(NoSuchElementException e){
			System.err.println("The Element "+idValue+" is not found");
			throw new RuntimeException("enterById failed");
		}
		catch(WebDriverException e){
			System.err.println("The Browser is closed");
			throw new RuntimeException("enterById failed");
		}
		
		finally{
		takeSnap();
		}
	}

	public void enterByName(String nameValue, String data) {
		try{
			
     driver.findElementByName(nameValue).sendKeys(data);
     System.out.println("The Entered value is:"+nameValue+"is entered with value:"+data);

	}
		catch(NoSuchElementException e)
		{
			System.err.println("The element"+nameValue+"is not found");
			}
		catch(WebDriverException e)
		{  
			System.err.println("Browser doesnot Exist");
			throw new RuntimeException("enterById failed");
	}
	}
	public void enterByXpath(String xpathValue, String data) {
       driver.findElementByXPath(xpathValue).sendKeys(data);
        System.out.println("The text field "+ xpathValue+" is entered with value :"+data);
        takeSnap();


	}

	public void verifyTitle(String title) {
		if(driver.getTitle().equals(title))
		{
			System.out.println("verified the title successfully");
		}
		else
		{
			System.out.println("Not the same title");
		}

	}

	public void verifyTextById(String id, String text) {
   String firstname= driver.findElementById(id).getText();
   if(firstname.equals(text)){
	   System.out.println("verified successfully using TextById");
   }
   else
	   System.out.println("Not Equals");

	}

	public void verifyTextByXpath(String xpath, String text) {
String textname=driver.findElementByXPath(xpath).getText();
if(textname.equals(text))
{
	System.out.println("verified successfully using Xpath ");
}
else {
	System.out.println("Text is not Equal");
}
	}

	public void verifyTextContainsByXpath(String xpath, String text) {

		String s = driver.findElementByXPath(xpath).getText();
		if(s.contains(text))
			System.out.println("The text matches");
		else
			System.out.println("The text does not match");
		takeSnap();
	}

	
	public void clickById(String id) {
		try{
		driver.findElementById(id).click();
		System.out.println("The button "+id+" is clicked");
		}
		catch(NoSuchElementException e){
			System.err.println("The Element "+id+" is not found");
			throw new RuntimeException("clickById failed");
		}
		catch(WebDriverException e){
			System.err.println("The Browser is closed");
			throw new RuntimeException("clickById failed");
		}
		
		finally{
			takeSnap();
		}

	}
	

	public void clickByClassName(String classVal) {
		try{
	driver.findElementByClassName(classVal).click();
	System.out.println("The button "+classVal+" is clicked");
		}
		
		catch(NoSuchElementException e){
			System.err.println("The Element "+classVal+" is not found");
			throw new RuntimeException("enterById failed");
		}
		finally{
	takeSnap();
		}
	}

	public void clickByName(String name) {
		try {
			driver.findElementByName(name).click();
				  System.out.println("The Button"+name+"is clicked");
  
 
		} catch (NoSuchElementException e) {
			
			 System.err.println(name +"doesn't exist.");
		}
		catch (WebDriverException e) {
			
			 System.err.println("Browser is not available");
		}
		finally{
			 takeSnap();
		}
	}

	public void clickByLink(String name) {
		
		try {
			driver.findElementByLinkText(name).click();
			System.out.println("The button "+ name +" is clicked");
			takeSnap();
		} catch (NoSuchElementException e) {
			System.out.println(name +"doesn't exist");
		}
		catch (WebDriverException e) {
			System.out.println("web browser is not available");
		}
	}
		

	public void clickByLinkNoSnap(String name) {

try {
	driver.findElementByLinkText(name).click();
	System.out.println("clicked by LinkText Without snap"+name);
} catch (NoSuchElementException e) {
	// TODO Auto-generated catch block
	System.out.println(name+"doesn't exist");
}
	}

	public void clickByXpath(String xpathVal) {
		
		try {
			driver.findElementByXPath(xpathVal).click();
			System.out.println("The button "+xpathVal+" is clicked");
			
		} catch (NoSuchElementException e) {
			System.err.println(xpathVal+"doesn't exist");
		}
		catch (WebDriverException e) {
			System.err.println("web browser is not available");
		}
		finally{
			takeSnap();
		}
	}



	public void clickByXpathNoSnap(String xpathVal) {

		driver.findElementByXPath(xpathVal).click();
		System.out.println("The button "+xpathVal+" is clicked");
	}

	public String getTextById(String idVal) {
		try{
			String s = driver.findElementById(idVal).getText();
			return s;
			}
			catch (NoSuchElementException e){
				System.out.println("The element "+idVal+" is not found");
				throw new RuntimeException ("getTextById failed");
			}
			catch (WebDriverException e){
				System.out.println("Browser does not exist");
				throw new RuntimeException ("getTextById failed");
			}
	}

	public String getTextByXpath(String xpathVal) {
		String s=null;
		try {
			 s= driver.findElementByXPath(xpathVal).getText();
			
		} 
		catch (NoSuchElementException e) {
			// TODO Auto-generated catch block
		System.out.println("The element"+ xpathVal+ "does not exist");
		}
		return s;
	}

	public void selectVisibileTextById(String id, String value) {
		WebElement  source= driver.findElementById(id);
		Select sourceDd = new Select(source);
		sourceDd.selectByVisibleText(value);
		takeSnap();

	}

	public void selectIndexById(String id, int value){

		try{
			WebElement src = driver.findElementById(id);
		Select opt = new Select(src);
		//List<WebElement> allOptions = opt.getOptions();
		//int count = allOptions.size();
		opt.selectByIndex(value);
		System.out.println("The index "+value+" is selected");
		}
		catch (NoSuchElementException e){
			System.out.println("The element "+id+" is not found");
			throw new RuntimeException ("selectTextById failed");
		}
		catch (WebDriverException e){
			System.out.println("Browser does not exist");
			throw new RuntimeException ("selectTextById failed");
		}
		finally{
		takeSnap();
		}
	}

	public  void switchToParentWindow() {
		
		
		try {
			Set<String> allWin = driver.getWindowHandles();
			int i=0;
			for (String eachWin : allWin) 
				{
					driver.switchTo().window(eachWin);
				
				if(i==0)
					break;
				System.out.println("Switched to parent Window");

}
		} catch (NoSuchWindowException e) {
			// TODO Auto-generated catch block
			System.out.println("The Window is not available");
		}
		}
	public void switchToLastWindow() {
		try {
			Set <String> allwindow=driver.getWindowHandles();
			for (String eachwin : allwindow) {
				driver.switchTo().window(eachwin);
				System.out.println("SwitchingToLastWindow");
				
			}
		} catch (NoSuchWindowException e) {
			System.err.println("window is not available");
		}
	}

	public void acceptAlert() {
 //String S= driver.switchTo().alert().getText();
		try{
		driver.switchTo().alert().accept();
		System.out.println("Alert is accepted ");
		}
		catch(NoAlertPresentException e){
			System.err.println("The alert is not present");
		}
		

	}

	public void dismissAlert() {

		try{
		driver.switchTo().alert().dismiss();
		System.out.println("The alert is dismissed");
		}
		catch (NoAlertPresentException e){
			System.out.println("dismissAlert failed");
		}

	}

	public String getAlertText() {

		try{
			String s = driver.switchTo().alert().getText();
			return s;
			}
			catch (NoAlertPresentException e){
				System.out.println("getAlertText failed");
				return null;
			}
	}

	public void takeSnap() {
		File srcFile = driver.getScreenshotAs(OutputType.FILE);
		File destFile = new File("./snaps/snap"+i+".jpg");
		try {
			FileUtils.copyFile(srcFile, destFile);
		} catch(UnhandledAlertException e){
			System.out.println("respond to alert");
		}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		i++;
		
	}

	public void closeBrowser() {
		try{
		driver.close();
		System.out.println("The browser is closed");
		}
		catch (WebDriverException e)
		{
			System.out.println("Browser does not exist");
			throw new RuntimeException ("closeBrowser failed");
		}
		//takeSnap();
	}

	public void closeAllBrowsers() {
		try{
		driver.quit();
		System.out.println("The browser is closed");
		}
		catch (WebDriverException e)
		{
			System.out.println("Browser does not exist");
			throw new RuntimeException ("closeBrowser failed");
		}
	
	}

	public void verifyTextContainsById(String id, String text) {
		// TODO Auto-generated method stub
		
	}

	public void enterByClassName(String nameValue, String data) {
		// TODO Auto-generated method stub
		
	}
}

