package week5.classwork;

import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class SampleReport {

	@Test
	public void report(){
		ExtentReports exRep = new ExtentReports("./reports/Sample.html", false);
		ExtentTest test = exRep.startTest("Delete Lead", "Deleting a Lead in Leaf Taps");
		test.assignAuthor("Devaki");
		test.assignCategory("Regression");
		test.log(LogStatus.PASS, "The First resulting Lead is clicked -PASS", "TEST 1"+test.addScreenCapture("./../snaps/snap1.jpg"));
		test.log(LogStatus.WARNING, "The First resulting Lead is clicked - WARN", "TEST 2"+test.addScreenCapture("./../snaps/snap5.jpg"));
		test.log(LogStatus.FAIL, "The Lead is not getting deleted", "FAIL::::: The text does not match with the text of the webelement");
		exRep.endTest(test);
		exRep.flush();
	}
}
