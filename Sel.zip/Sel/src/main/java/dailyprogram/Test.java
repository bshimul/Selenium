package dailyprogram;

public class Test {

	public static void main(String[] a) {
		// TODO Auto-generated method stub

	}

}
