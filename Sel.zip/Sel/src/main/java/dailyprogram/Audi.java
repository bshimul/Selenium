package dailyprogram;


class Vehicle {
	public Vehicle(){
		System.out.println("Inside Vehicle class's default constructor");
	}
}

class Car extends Vehicle {
	public Car() {
		System.out.println("Inside Car class's default constructor");
	}
}

public class Audi extends Car{
	public Audi() {
		System.out.println("Inside Audi class's default constructor");
	}
	
	public static void main(String[] args) {
		new Audi();
	}
}
/* OUTPUT
Inside Vehicle class's default constructor
Inside Car class's default constructor
Inside Audi class's default constructor*/