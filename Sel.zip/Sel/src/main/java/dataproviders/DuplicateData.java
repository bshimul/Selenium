package dataproviders;

import org.testng.annotations.DataProvider;

public class DuplicateData {
	@DataProvider (name="fetchDuplicate")
	public static String[][] fetchDuplicate()
	{
		String[][] testData=new String[3][1];
		testData[0][0]="16767";
		testData[1][0]="15454";
		testData[2][0]="56435";
		return testData;
	}

}
