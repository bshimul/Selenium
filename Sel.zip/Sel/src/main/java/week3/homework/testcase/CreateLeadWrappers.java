package week3.homework.testcase;

import org.junit.Test;

import wrappers.ProjectWrappers;

public class CreateLeadWrappers extends ProjectWrappers {
	@Test
	public void leadCreate () throws InterruptedException {
		loginToLeafTaps();
		clickByLinkNoSnap("Create Lead");
		enterById("createLeadForm_companyName", "Harness");
		enterById("createLeadForm_firstName", "Balachander");
		enterById("createLeadForm_lastName", "S");
		selectVisibileTextById("createLeadForm_dataSourceId", "Conference");
		selectIndexById("createLeadForm_marketingCampaignId", 2);
		enterById("createLeadForm_primaryPhoneNumber", "2692039");
		enterById("createLeadForm_primaryEmail", "balacander.cbe@gmail.com");
		Thread.sleep(5000);
		clickByName("submitButton");
		String leadId = getTextById("viewLead_companyName_sp");
		System.out.println("Captured Lead ID is "+leadId.substring(leadId.indexOf('(')+1, leadId.indexOf(')')));
		Thread.sleep(3000);
		closeBrowser();
	}
}
