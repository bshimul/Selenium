package week3.homework.testcase;

import org.junit.Test;

import wrappers.ProjectWrappers;

public class DeleteLeadWrappers extends ProjectWrappers {

	@Test
	public void deleteLead() throws InterruptedException {
		loginToLeafTaps();
		clickByLink("Leads");
		clickByLink("Find Leads");
		clickByXpath("//span[text()='Phone']");
		enterByName("phoneCountryCode", "2");
		enterByName("phoneAreaCode", "24");
		enterByName("phoneNumber", "81323928392");
		clickByXpath("//button[text()='Find Leads']");
		Thread.sleep(5000);
		String leadIdText = getTextByXpath("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a");
		clickByXpath("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a");
		clickByLink("Delete");
		clickByLink("Find Leads");
		enterByXpath("//input[@name='id']", leadIdText);
		clickByXpath("//button[text()='Find Leads']");
		Thread.sleep(5000);
		verifyTextByXpath("//div[@class='x-paging-info']", "No records to display");
		Thread.sleep(3000);
		closeBrowser();
	}
}
