package week3.homework.testcase;

import org.junit.Test;

import wrappers.ProjectWrappers;

public class EditLeadWrappers extends ProjectWrappers {

	@Test
	public void editLead() throws InterruptedException {
		
		loginToLeafTaps(); //Login to Leaf taps and do until CRM/SFA click
		clickByLink("Leads"); //Clicking the Link 'Leads'
		clickByLink("Find Leads"); //Clicking the link 'Find Leads'
		enterByXpath("(//input[@name='firstName'])[3]","RAVI"); //Entering the first name
		clickByXpath("//button[contains(text(),'Find Leads')]"); //Clicking the button 'Find Leads'
		Thread.sleep(5000);
		clickByXpath("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a"); //Clicking on the first resulting lead
		verifyTitle("View Lead | opentaps CRM"); //verifying the title of the window
		clickByLink("Edit"); //clicking the 'Edit' link
		enterById("updateLeadForm_companyName","Google"); //updating the new Company name
		clickByXpath("//input[@value='Update']"); //clicking the Update button
		verifyTextContainsById("viewLead_companyName_sp","Google"); /*verifying that the updated 
																Company name contains the entered company name */
		Thread.sleep(3000);
		closeBrowser(); //closing the browser
	}

}
