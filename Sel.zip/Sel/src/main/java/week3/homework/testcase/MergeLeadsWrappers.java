package week3.homework.testcase;

import org.junit.Test;

import wrappers.ProjectWrappers;

public class MergeLeadsWrappers extends ProjectWrappers {
	@Test
	public void merLead () throws InterruptedException {
		loginToLeafTaps();
		clickByLinkNoSnap("Leads");
		clickByLinkNoSnap("Merge Leads");
		
		clickByXpathNoSnap("(//img[@alt='Lookup'])[1]");
		switchToLastWindow();
		//verifyTitle("Find Leads");
		enterByXpath("//label[contains(text(),'Lead ID:')]/following::input","12577");
		clickByXpathNoSnap("//button[contains(text(),'Find Leads')]");
		clickByXpathNoSnap("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a");
		
		switchToParentWindow();
		
		clickByXpathNoSnap("(//img[@alt='Lookup'])[2]");
		switchToLastWindow();
		enterByXpath("//label[contains(text(),'Lead ID:')]/following::input","12579");
		clickByXpathNoSnap("//button[contains(text(),'Find Leads')]");
		clickByXpathNoSnap("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a");

		switchToParentWindow();
		
		clickByLink("Merge");
		Thread.sleep(2000);
		acceptAlert();
		Thread.sleep(5000);
		clickByLink("Find Leads");
		enterByXpath("//label[contains(text(),'Lead ID:')]/following::input", "12577");
		clickByXpathNoSnap("//button[contains(text(),'Find Leads')]");
		verifyTextByXpath("//div[contains(text(),'No records to display')]", "No records to display");
		Thread.sleep(5000);
		closeBrowser();
		
	}
}
