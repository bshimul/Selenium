package week3.homework.testcase;

import org.junit.Test;

import wrappers.ProjectWrappers;

public class DuplicateLeadsWrappers extends ProjectWrappers {
	@Test
	public void dupLead() throws InterruptedException {
		loginToLeafTaps();
		clickByLink("Leads");
		clickByLink("Find Leads");
		clickByXpath("//span[contains(text(),'Email')]");//E Mail
		enterByName("emailAddress", "a@a.com");
		clickByXpath("//button[text()='Find Leads']"); //Find Leads
		Thread.sleep(5000);
		String firstName = getTextByXpath("(//*[@class='x-grid3-cell-inner x-grid3-col-firstName'])[1]"); //Name of first resulting lead
		clickByXpath("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a");//click first resulting lead
		clickByLink("Duplicate Lead");
		verifyTitle("Duplicate Lead");
		clickByName("submitButton");
		verifyTextById("viewLead_firstName_sp", firstName);
		closeBrowser();
	}
}
