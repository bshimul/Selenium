package week3.homework.testcase;

import org.junit.Test;

public class AllTestCases {

	@Test
	public void leadOperations() throws InterruptedException {
		CreateLeadWrappers createLead = new CreateLeadWrappers();
		createLead.leadCreate();
		EditLeadWrappers editLead = new EditLeadWrappers();
		editLead.editLead();
		MergeLeadsWrappers merLead = new MergeLeadsWrappers();
		merLead.merLead();
		DuplicateLeadsWrappers dupLead = new DuplicateLeadsWrappers();
		dupLead.dupLead();
		DeleteLeadWrappers delLead = new DeleteLeadWrappers();
		delLead.deleteLead();
	}
}
