/* Do not add a package declaration */
import java.util.*;
import java.util.Map.Entry;
import java.io.*;

/* You may add any imports here, if you wish, but only from the 
   standard library */

public class Main {
	public static int processData(ArrayList<String> array) {
		/* 
		 * Modify this method to process `array` as indicated
		 * in the question. At the end, return the appropriate value.
		 *
		 * Please create appropriate classes, and use appropriate
		 * data structures as necessary.
		 *
		 * Do not print anything in this method.
		 *
		 * Submit this entire program (not just this method)
		 * as your answer
		 */
		Map<String, String> hmLatestSwDet = new TreeMap<String, String>();
		Set<String> uniqueServerDetails = new HashSet<String>(array);
		ServerDetails[] sd = new ServerDetails[uniqueServerDetails.size()];
		int outDatedVersions = 0, i=0;

		/*
		 * Loop to create server details object for each of the servers 
		 * 		with their name, application, software and version no.
		 * Get the latest version of the application and software 
		 * 			put in a map with application name:software name as key and version as value.
		 * 			if the latest version is unavailable set the latest version to zero.
		 */
		for (String uniqueServerDetail : uniqueServerDetails) {
			String[] eachServerDetails = uniqueServerDetail.split(",");
			sd[i] = new ServerDetails(eachServerDetails[0], eachServerDetails[1], eachServerDetails[2], eachServerDetails[3]);
			String swKey = sd[i].application+":"+sd[i].software;
			String currVersion = hmLatestSwDet.get(swKey) == null ? "0" : hmLatestSwDet.get(swKey);
			if (compareVersions(currVersion, sd[i].version) < 0) {
				hmLatestSwDet.put(swKey, sd[i].version);
			}
			i++;
		}
		/*
		 * Iterate through the latest software map and find the server count 
		 * with out-dated software among all servers with has the software installed..
		 * If the out-dated server count is > 1, then increment the out-dated version by one.
		 * Return out-dated version count after the iteration of all latest softwares.
		 */
		for (Entry<String, String> eachSwDet : hmLatestSwDet.entrySet()) {
			int outDatedServers = 0;
			for (int j = 0; j < sd.length; j++) {
				String swKey = sd[j].application+":"+sd[j].software;
				if (swKey.equals(eachSwDet.getKey()) && !sd[j].version.equals(eachSwDet.getValue())) {
					outDatedServers = outDatedServers + ServerDetails.calcOutDatedSrv(swKey+"_"+ sd[j].version);
				}
			}
			if (outDatedServers > 1) {
				outDatedVersions++;
			}
		}
		return outDatedVersions;
	}

	/**
	 * Compares the two versions, version1 and version2.
	 * @param version1
	 * @param version2
	 * @return  value 0 if two versions are equal or  
	 * 			a value <0 if version2 is latest or 
	 * 			a value >0 if version1 is latest
	 */
	public static int compareVersions(String version1, String version2) {
		String[] levels1 = version1.split("\\.");
		String[] levels2 = version2.split("\\.");
		int length = Math.max(levels1.length, levels2.length);
		for (int i = 0; i < length; i++){
			Integer v1 = i < levels1.length ? Integer.parseInt(levels1[i]) : 0;
			Integer v2 = i < levels2.length ? Integer.parseInt(levels2[i]) : 0;
			int compare = v1.compareTo(v2);
			if (compare != 0){
				return compare;
			}
		}
		return 0;
	}

	public static void main (String[] args) {
		ArrayList<String> inputData = new ArrayList<String>();
		try {
			Scanner in = new Scanner(new BufferedReader(new FileReader("input.txt")));
			while(in.hasNextLine()) {
				String line = in.nextLine().trim();
				if (!line.isEmpty()) // Ignore blank lines
					inputData.add(line);
			}
			int retVal = processData(inputData);
			PrintWriter output = new PrintWriter(new BufferedWriter(new FileWriter("output.txt")));
			output.println("" + retVal);
			output.close();
			in.close();
		} catch (IOException e) {
			System.out.println("IO error in input.txt or output.txt");
		}
	}
	
	
	
	static class ServerDetails {
		String name, application, software, version;
		static Map<String, Integer> hmAllSwDet = new TreeMap<String, Integer>();

		/**
		 * Creates a ServerDetails instance with name, application, software and version
		 * @param name 
		 * 			The name of the server
		 * 
		 * @param application
		 * 			The application which is installed in the server
		 * 
		 * @param software
		 * 			The software name of the application
		 * 
		 * @param version
		 * 			The version of the software installed in the server
		 */
		public ServerDetails(String name, String application, String software, String version) {
			this.name = name;
			this.application = application;
			this.software = software;
			this.version = version.trim();
			String serSwVersionKey = application+":"+software+"_"+version.trim();
			if (!hmAllSwDet.containsKey(serSwVersionKey)) {
				hmAllSwDet.put(serSwVersionKey, 1);
			} else {
				hmAllSwDet.put(serSwVersionKey, hmAllSwDet.get(serSwVersionKey)+1);
			}
		}

		/**
		 * 
		 * @param key as application:software_version
		 * @return value 0 if the key is not present and if only one server has the key   
		 * 		   a value 1 if more than one server has the key 
		 */
		public static int calcOutDatedSrv(String key) {
			return (hmAllSwDet.get(key) == null && hmAllSwDet.get(key) > 0) ? 0 : 1;
		}
	}

}