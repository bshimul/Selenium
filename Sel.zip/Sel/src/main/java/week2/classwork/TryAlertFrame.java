package week2.classwork;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TryAlertFrame {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		//Creating Chromedriver instance
		ChromeDriver driver=new ChromeDriver();
		//Launch the browser
		driver.get("https://www.w3schools.com/js/tryit.asp?filename=tryjs_prompt");
		//Maximizing the browser
		driver.manage().window().maximize();
		
		//switchTo.frame
		WebElement frame1 = driver.findElementById("iframeResult");
		driver.switchTo().frame(frame1);
		
		//find element.click
		driver.findElementByXPath("/html/body/button").click();
		
		//switchTo.alert.SendKeys
		driver.switchTo().alert().sendKeys("Devaki");
		Thread.sleep(5000);
				
		//switchTo.alert.accept
		driver.switchTo().alert().accept();

		//find element by text
		String text = driver.findElementById("demo").getText();
		
		
		//sysout in the console
		System.out.println(text);
		
		if(text.contains("Devaki"))
			System.out.println(text+ " contains Devaki");
		else
			System.out.println(text+ " does not contain Devaki");
		
		driver.switchTo().defaultContent();
		
		driver.findElementById("tryhome").click();

	}

}
