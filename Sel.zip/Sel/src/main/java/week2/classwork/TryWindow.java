package week2.classwork;

import java.util.Set;

import org.openqa.selenium.chrome.ChromeDriver;

public class TryWindow {

	public static void main(String[] args) {
		//Driver initialize
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		//Creating Chromedriver instance
		ChromeDriver driver=new ChromeDriver();
		//Launch the browser
		driver.get("http://legacy.crystalcruises.com/");
		//Maximizing the browser
		driver.manage().window().maximize();
		
		//Getting the window handle of the parent window
		String parWinHandle = driver.getWindowHandle();
		
		//printing the title and URL of the second window
				System.out.println("Title of the first window is: " +driver.getTitle());
				System.out.println("URL of first window is: " +driver.getCurrentUrl());
				
		//Click the Guest Check-in button
		driver.findElementByLinkText("GUEST CHECK-IN").click();
		
		//Getting the window hanles of all the opened windows
		Set<String> allHandles = driver.getWindowHandles();
		
		//to switch to the other windows
		for (String eachHandle : allHandles) {
			//if(!eachHandle.equals(parWinHandle))
				driver.switchTo().window(eachHandle);
		}
		
		//printing the title and URL of the second window
		System.out.println("Title of the second window is: " + driver.getTitle());
		System.out.println("URL of second window is: " + driver.getCurrentUrl());
		
		
		String firstNameLbl = driver.findElementByXPath("//*[@id='leftColumn'"
				+ "]/div[2]/table/tbody/tr/td[1]/table/tbody/tr[1]/td[1]").getText();
		
		System.out.println("Firsname Label in Guest Login:: " + firstNameLbl);
		driver.close();
		driver.switchTo().window(parWinHandle);
		String phNum = driver.findElementById("PlanAndBookPhoneNumber").getText();
		System.out.println("Contact Number to Plan and Book:: " + phNum);
		
		System.out.println("Title of the Parent window is: " +driver.getTitle());
		System.out.println("URL of Parent window is: " +driver.getCurrentUrl());
		
		}

}
