package week2.classwork;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Platform;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

public class MergeLeads {

	public static void main(String[] args) throws InterruptedException, MalformedURLException {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		//ChromeDriver driver = new ChromeDriver();
		DesiredCapabilities dc = new DesiredCapabilities();
		dc.setBrowserName("chrome");
		dc.setPlatform(Platform.WINDOWS);
		RemoteWebDriver driver = new RemoteWebDriver(new URL("http://localost:4444/wd/hub"), dc);
		driver.get("http://leaftaps.com/control/main");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		driver.findElementById("username").sendKeys("DemoSalesManager");
		driver.findElementById("password").sendKeys("crmsfa");
		
		driver.findElementByClassName("decorativeSubmit").click();
		driver.findElementByLinkText("CRM/SFA").click();
		driver.findElementByLinkText("Leads").click();
		driver.findElementByLinkText("Merge Leads").click();
		
		String parentWinHandle = driver.getWindowHandle();
		driver.findElementByXPath("(//img[@alt='Lookup'])[1]").click();
		
		Set<String> allHandles = driver.getWindowHandles();
		for (String eachHandle : allHandles) {
			if (!eachHandle.equals(parentWinHandle))
				driver.switchTo().window(eachHandle);
		}
		driver.findElementByXPath("//label[contains(text(),'Lead ID:')]/following::input").sendKeys("14301");
		driver.findElementByXPath("//button[contains(text(),'Find Leads')]").click();
		driver.findElementByXPath("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a").click();
		
		driver.switchTo().window(parentWinHandle);
		System.out.println(driver.findElementById("ComboBox_partyIdFrom").getText());
		driver.findElementByXPath("(//img[@alt='Lookup'])[2]").click();
		
		allHandles = driver.getWindowHandles();
		for (String eachHandle : allHandles) {
			if (!eachHandle.equals(parentWinHandle))
				driver.switchTo().window(eachHandle);
		}
		driver.findElementByXPath("//label[contains(text(),'Lead ID:')]/following::input").sendKeys("14303");
		driver.findElementByXPath("//button[contains(text(),'Find Leads')]").click();
		driver.findElementByXPath("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a").click();
		
		driver.switchTo().window(parentWinHandle);
		System.out.println(driver.findElementByName("ComboBox_partyIdFrom").getText());
		driver.findElementByLinkText("Merge").click();
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		driver.findElementByLinkText("Find Leads").click();
		driver.findElementByXPath("//label[contains(text(),'Lead ID:')]/following::input").sendKeys("11908");
		driver.findElementByXPath("//button[contains(text(),'Find Leads')]").click();
		String errorText = driver.findElementByXPath("//div[contains(text(),'No records to display')]").getText();
		System.out.println(errorText);
		
		driver.close();
		
	}

}
