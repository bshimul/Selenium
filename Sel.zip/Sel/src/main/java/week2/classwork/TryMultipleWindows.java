package week2.classwork;

import java.util.Set;

import org.openqa.selenium.chrome.ChromeDriver;

public class TryMultipleWindows {

	public static void main(String[] args) throws InterruptedException {
		//Driver initialize
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		//Creating Chromedriver instance
		ChromeDriver driver=new ChromeDriver();
		//Launch the browser
		driver.get("http://legacy.crystalcruises.com/");
		//Maximizing the browser
		driver.manage().window().maximize();
		
		//Getting the window handle of the parent window
		String parWinHandle = driver.getWindowHandle();
		
		//printing the title and URL of the Parent window
		System.out.println("--------------PRINTING THE DETAILS of Parent window-----------------------");
				System.out.println("Title of the Parent window is: " +driver.getTitle());
				System.out.println("URL of Parent window is: " +driver.getCurrentUrl());
				
		//Click the Guest Check-in button
		driver.findElementByLinkText("GUEST CHECK-IN").click();
		
		//Getting the window hanles of all the opened windows
		Set<String> allHandles = driver.getWindowHandles();
		
		//to switch to the other windows
		for (String eachHandle : allHandles) {
			//if(!eachHandle.equals(parWinHandle))
				driver.switchTo().window(eachHandle);
		}
		
		//printing the title and URL of the second window
		System.out.println("--------------PRINTING THE DETAILS of Second window-----------------------");
		System.out.println("Title of the second window is: " +driver.getTitle());
		System.out.println("URL of second window is: " +driver.getCurrentUrl());
		
		//Switching to the parent window
		driver.switchTo().window(parWinHandle);
		Thread.sleep(3000);
		
		//finding the element BLOG
		driver.findElementByLinkText("BLOG").click();
		
		//Getting the window handles of all the opened windows
				Set<String> allHandles1 = driver.getWindowHandles();
				
				//to switch to the other windows
				for (String eachHandle : allHandles1) {
					if(!eachHandle.equals(parWinHandle))
						driver.switchTo().window(eachHandle);
				}
		
				//printing the title and URL of the third window
				System.out.println("--------------PRINTING THE DETAILS of Third window-----------------------");
				System.out.println("Title of the third window is: " +driver.getTitle());
				System.out.println("URL of third window is: " +driver.getCurrentUrl());
				
				driver.findElementByClassName("vc_gitem-link vc-zone-link").click();

				//closing the current window opened the driver in the current segment
				driver.close();
				
				Thread.sleep(3000);
				
				
				
				//closing all the windows opened via Selenium program
				driver.quit();
			
		}

}
