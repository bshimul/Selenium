package week2.homework.testcase;

import org.junit.Test;

import wrappers.GenericWrappers;

public class MergeLeadsWrappers  extends GenericWrappers{
	@Test
	public void leadCreate () throws InterruptedException {
		invokeApp("chrome", "http://www.leaftaps.com/opentaps");
		enterById("username", "DemoSalesManager");
		enterById("password", "crmsfa");
		clickByClassName("decorativeSubmit");
		clickByLinkNoSnap("CRM/SFA");
		clickByLinkNoSnap("Leads");
		clickByLinkNoSnap("Merge Leads");
		
		clickByXpathNoSnap("(//img[@alt='Lookup'])[1]");
		switchToLastWindow();
		verifyTitle("Find Leads");
		enterByXpath("//label[contains(text(),'Lead ID:')]/following::input","10188");

		clickByXpathNoSnap("//button[contains(text(),'Find Leads')]");
		Thread.sleep(2000);
		clickByXpathNoSnap("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a");
		
		switchToParentWindow();
		
		clickByXpathNoSnap("(//img[@alt='Lookup'])[2]");
		switchToLastWindow();
		enterByXpath("//label[contains(text(),'Lead ID:')]/following::input","10195");
		clickByXpathNoSnap("//button[contains(text(),'Find Leads')]");
		Thread.sleep(2000);

		clickByXpathNoSnap("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a");

		switchToParentWindow();
		
		clickByLinkNoSnap("Merge");
		Thread.sleep(2000);
		//acceptAlert();
		driver.switchTo().alert().sendKeys("");
		Thread.sleep(5000);
		clickByLink("Find Leads");
		enterByXpath("//label[contains(text(),'Lead ID:')]/following::input", "10117");
		clickByXpathNoSnap("//button[contains(text(),'Find Leads')]");
		verifyTextByXpath("//div[contains(text(),'No records to display')]", "No records to display");
		Thread.sleep(5000);
		closeBrowser();
		
	}
}
