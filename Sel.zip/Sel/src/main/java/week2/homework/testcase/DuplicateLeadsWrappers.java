package week2.homework.testcase;

import org.junit.Test;

import wrappers.GenericWrappers;

public class DuplicateLeadsWrappers extends GenericWrappers {
	@Test
	public void leadCreate () throws InterruptedException {
		invokeApp("chrome", "http://www.leaftaps.com/opentaps");
		enterById("username", "DemoSalesManager");
		enterById("password", "crmsfa");
		clickByClassName("decorativeSubmit");
		clickByLinkNoSnap("CRM/SFA");
		clickByLinkNoSnap("Leads");
		clickByLinkNoSnap("Find Leads");
		//clickByXpathNoSnap("(//*[@class='x-tab-strip-text '])[3]");//E Mail
		clickByXpathNoSnap("//span[contains(text(),'Email')]");//E Mail
		enterByName("emailAddress", "a@a.com");
		clickByXpathNoSnap("(//*[@class='x-btn-text'])[7]"); //Find Leads
		Thread.sleep(5000);
		String firstResultName = getTextByXpath("(//div[@class='x-grid3-cell-inner x-grid3-col-firstName'])[1]"); //Name of first resulting lead
		clickByXpathNoSnap("(//*[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a");//click first resulting lead
		clickByLinkNoSnap("Duplicate Lead");
		verifyTitle("Duplicate Lead");
		clickByName("submitButton");
		verifyTextById("viewLead_firstName_sp", firstResultName);
		closeBrowser();
	}
}
