package week2.homework.testcase;


import java.util.Set;

import org.junit.Test;
import org.openqa.selenium.Alert;

import wrappers.GenericWrappers;

public class LeafTaps extends GenericWrappers{

	String Browser="Chrome";
	String Url="http://www.leaftaps.com";
	 String fromLead = "", toLead = "";
	
	
@Test()
public void createlead() throws Exception{
	invokeApp(Browser, Url);
	enterById("username", "DemoSalesManager");
	enterById("password", "crmsfa");
	clickByClassName("decorativeSubmit");
	String companyname="kijk";
	String Firstname="hlkj";
	String lastname="mopk";

	
	clickByXpath(".//*[@for='crmsfa']");
	
	Thread.sleep(3000);
	
	clickByXpath(".//*[@class='frameSectionBody']/ul/li[1]");
	
	
	enterByXpath(".//*[@id='createLeadForm_companyName']", companyname);
	

	enterByXpath(".//*[@id='createLeadForm_firstName']",Firstname);
	enterByXpath(".//*[@id='createLeadForm_lastName']", lastname);
	
	clickByXpath(".//*[@class='smallSubmit']");

	

		 fromLead = getTextByXpath(".//*[@id='viewLead_companyName_sp']");
System.out.println(fromLead);

Thread.sleep(4000);

String compan="sohfj";
String Firstnam="rhfa";
String lastnam="rkhhjh";
System.out.println("next lead");

//clickByLink("Create Lead");
driver.findElementByXPath(".//*[@href='/crmsfa/control/createLeadForm']").click();

enterByXpath(".//*[@id='createLeadForm_companyName']", compan);
enterByXpath(".//*[@id='createLeadForm_firstName']",Firstnam);
enterByXpath(".//*[@id='createLeadForm_lastName']", lastnam);
clickByXpath(".//*[@class='smallSubmit']");
System.out.println("*************************************************");
System.out.println(getTextByXpath(".//*[@id='viewLead_companyName_sp']"));
System.out.println("*************************************************");

toLead = getTextByXpath(".//*[@id='viewLead_companyName_sp']");

System.out.println(toLead);

	



////////////////////////////////////////merge leads///////////////////////////////////////////////////




clickByLink("Merge Leads");
	String primaryWindow = driver.getWindowHandle();
	System.out.println(driver.getTitle());
clickByXpath("(//img[@alt='Lookup'])[1]");
	

	Set<String> lastWindow = driver.getWindowHandles();
	for (String allWindow : lastWindow) {
		driver.switchTo().window(allWindow);
	}
	System.out.println(driver.getTitle());


enterByXpath("//label[contains(text(),'Lead ID:')]/following::input", fromLead);
clickByXpath("//button[contains(text(),'Find Leads')]");

clickByXpath("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a");




	driver.switchTo().window(primaryWindow);
	
	clickByXpath("(//img[@alt='Lookup'])[2]");

	lastWindow = driver.getWindowHandles();
	for (String allWindow : lastWindow) {
		driver.switchTo().window(allWindow);
	}
	System.out.println(driver.getTitle());

	Thread.sleep(6000);
	enterByXpath("//label[contains(text(),'Lead ID:')]/following::input",toLead);

	Thread.sleep(6000);

clickByXpath("//button[contains(text(),'Find Leads')]");

	Thread.sleep(6000);
	clickByXpath("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a");

	driver.switchTo().window(primaryWindow);
	System.out.println(driver.getTitle());

clickByLink("Merge");

	Thread.sleep(10000);

	Alert alert = driver.switchTo().alert();
	String msg=alert.getText();
	System.out.println(msg);
	alert.accept();
	Thread.sleep(4000);



	//testcase1

	System.out.println("testcase1");

	//FINDLEADS MODULE FROM FIELD INVISIBLE CHECK

	

clickByLink("Find Leads");
	
	
enterByXpath("//label[contains(text(),'Lead ID:')]/following::input",fromLead);


clickByXpath("//button[contains(text(),'Find Leads')]");

	String verify=getTextByXpath("//div[contains(text(),'No records to display')]");
	String a="No records to display";
	if (verify.equalsIgnoreCase(a)){
		System.out.println("verify pass record is not there");
		
	}
		else{
			System.out.println("fail");
		}





	//testcase2
	System.out.println("testcase2");

	//FINDLEADS MODULE TO FIELD VISIBLE CHECK

	clickByLink("Find Leads");

	//driver.findElementByXPath("//label[contains(text(),'Lead ID:')]/following::input").sendKeys(From);


	enterByXpath("//label[contains(text(),'Lead ID:')]/following::input",toLead);



clickByXpath("//button[contains(text(),'Find Leads')]");
	//String verify=driver.findElementByXPath("//div[contains(text(),'No records to display')]").getText();

	/*String Actuali=getByLinkText(toLead, "link found");
			
			
	System.out.println(Actuali);
	if(Actuali.contains(toLead)){
		System.out.println("***********"+toLead+ "is present***************");
		
	}
	else{
		System.out.println("***********"+toLead+ "is not present***************");
	}*/





}


@Test
public void Login() throws Exception {
//login(idvalue);
	
	
	invokeApp(Browser, Url);
	enterById("username", "DemoSalesManager");
	enterById("password", "crmsfa");
	clickByClassName("decorativeSubmit");
	//login();
	
}
/*@Test


public void Mergelead() throws Exception {
	
	System.out.println(toLead);
	clickByLink("Merge Leads");
}
*/

}
