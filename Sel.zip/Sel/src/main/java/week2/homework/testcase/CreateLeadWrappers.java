package week2.homework.testcase;

import org.junit.Test;

import wrappers.GenericWrappers;

public class CreateLeadWrappers extends GenericWrappers{
	@Test
	public void leadCreate () throws InterruptedException {
		invokeApp("chrome", "http://www.leaftaps.com/control/main");
		enterById("username", "DemoSalesManager");
		enterById("password", "crmsfa");
		clickByClassName("decorativeSubmit");
		clickByLinkNoSnap("CRM/SFA");
		clickByLinkNoSnap("Create Lead");
		enterById("createLeadForm_companyName", "Harness");
		enterById("createLeadForm_firstName", "Balachander");
		enterById("createLeadForm_lastName", "S");
		/*//enterById("createLeadForm_parentPartyId", "13240");
		clickByXpath("//img[@alt='Lookup']");
		switchToLastWindow();
		//switchToFrame("org.opentaps.gwt.crmsfa.crmsfa");
		//enterByXpath("//input[@class=' x-form-text x-form-field ']", "132");
		clickByXpathNoSnap("//a[@class='linktext']");
		switchToParentWindow();
		selectVisibileTextById("createLeadForm_dataSourceId", "Conference");
		selectIndexById("createLeadForm_marketingCampaignId", 2);
		enterById("createLeadForm_firstNameLocal", "Bala");
		enterById("createLeadForm_lastNameLocal", "Subramanian");
		enterById("createLeadForm_personalTitle", "Er.");
		enterById("createLeadForm_generalProfTitle", "Mr.");
		enterById("createLeadForm_departmentName", "Technical");
		enterById("createLeadForm_annualRevenue", "750000");
		selectValueById("createLeadForm_currencyUomId", "INR");
		selectValueById("createLeadForm_industryEnumId", "IND_SOFTWARE");
		enterById("createLeadForm_numberEmployees", "50");
		selectVisibileTextById("createLeadForm_ownershipEnumId", "Sole Proprietorship");
		enterById("createLeadForm_sicCode", "12345");
		enterById("createLeadForm_tickerSymbol", "23456");
		enterById("createLeadForm_description", "Test create lead with wrapper methods");
		enterById("createLeadForm_importantNote", "Important note goes here");
		enterById("createLeadForm_primaryPhoneCountryCode", "091");
		enterById("createLeadForm_primaryPhoneAreaCode", "0422");
		enterByXpath("//*[@id='createLeadForm_primaryPhoneNumber']", "2692039");
		enterByName("primaryPhoneExtension", "9999");
		enterByName("primaryPhoneAskForName", "Bala");
		enterById("createLeadForm_primaryEmail", "balacander.cbe@gmail.com");
		enterByName("primaryWebUrl", "www.harnessgroup.net");
		enterById("createLeadForm_generalToName", "Balachander S");
		enterById("createLeadForm_generalAttnName", "Subramanian");
		enterByName("generalAddress1", "8-18/Union Tank Road");
		enterByName("generalAddress2", "Perianaicken Palayam");
		enterByName("generalCity", "Coimbatore");
		enterByName("generalPostalCode", "641020");
		selectValueById("createLeadForm_generalCountryGeoId", "IND");
		Thread.sleep(5000);
		selectValueById("createLeadForm_generalStateProvinceGeoId", "IN-TN");
		enterByName("generalPostalCodeExt", "-");
		Thread.sleep(5000);*/
		clickByName("submitButton");
		//Thread.sleep(10000);
		closeBrowser();
	}
	
	@Test
	public void duplicateLead () throws InterruptedException {
		invokeApp("chrome", "http://www.leaftaps.com/control/main");
		enterById("username", "DemoSalesManager");
		enterById("password", "crmsfa");
		clickByClassName("decorativeSubmit");
		clickByLinkNoSnap("CRM/SFA");
		clickByLinkNoSnap("Leads");
		clickByLinkNoSnap("Find Leads");
		//clickByXpathNoSnap("(//*[@class='x-tab-strip-text '])[3]");//E Mail
		clickByXpathNoSnap("//span[contains(text(),'Email')]");//E Mail
		enterByName("emailAddress", "a@a.com");
		clickByXpathNoSnap("(//*[@class='x-btn-text'])[7]"); //Find Leads
		Thread.sleep(5000);
		String firstResultName = getTextByXpath("(//*[@class='x-grid3-cell-inner x-grid3-col-firstName'])[1]"); //Name of first resulting lead
		clickByXpathNoSnap("(//*[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a");//click first resulting lead
		clickByLinkNoSnap("Duplicate Lead");
		verifyTitle("Duplicate Lead");
		clickByName("submitButton");
		verifyTextById("viewLead_firstName_sp", firstResultName);
		closeBrowser();
	}
	@Test
	public void deleteLead() throws InterruptedException {
		invokeApp("chrome", "http://www.leaftaps.com/control/main");
		enterById("username", "DemoSalesManager");
		enterById("password", "crmsfa");
		clickByClassName("decorativeSubmit");
		clickByLinkNoSnap("CRM/SFA");
		clickByLink("Leads");
		clickByLink("Find Leads");
		clickByXpath("//span[text()='Phone']");
		enterByName("phoneCountryCode", "2");
		enterByName("phoneAreaCode", "24");
		enterByName("phoneNumber", "81323928392");
		clickByXpath("//button[text()='Find Leads']");
		Thread.sleep(5000);
		String leadIdText = getTextByXpath("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a");
		clickByXpath("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a");
		clickByLink("Delete");
		clickByLink("Find Leads");
		enterByXpath("//input[@name='id']", leadIdText);
		clickByXpath("//button[text()='Find Leads']");
		Thread.sleep(5000);
		verifyTextByXpath("//div[@class='x-paging-info']", "No records to display");
		Thread.sleep(3000);
		closeBrowser();
	}
}
