package week7.classwork;

public class LearnEncap {

	private String creditCardNum = "1234 5678 8765 4321";

	public String getCreditCardNum() {
		return creditCardNum;
	}

	public void setCreditCardNum(String creditCardNum) {
		this.creditCardNum = creditCardNum;
	}

}
