 package week7.classwork;

public class GetCreditCardNum {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		LearnEncap obj = new LearnEncap();
		obj.setCreditCardNum("9876 5874 1236 5478");
		System.out.println(obj.getCreditCardNum());

	}

}
 