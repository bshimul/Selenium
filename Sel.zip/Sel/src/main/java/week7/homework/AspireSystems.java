package week7.homework;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class AspireSystems {

	public static void main(String[] args) {
		String aspSys = "AaaasppppiireSystems";
		char[] ch = aspSys.toLowerCase().toCharArray();
		Set<Character> asp = new HashSet<Character>();
		Map<Character, Integer> map = new HashMap<Character, Integer>();
		for (char c : ch) {
			if(asp.add(c)){
				map.put(c, 1);
			} else {
				map.put(c, map.get(c)+1);
			}
		}
		System.out.println("unsorted map --> "+map);
		        
		Set<Entry<Character, Integer>> set = map.entrySet();
        List<Entry<Character, Integer>> list = new ArrayList<Entry<Character, Integer>>(set);
        Comparator<Entry<Character, Integer>> cmp =  new Comparator<Entry<Character, Integer>>() {
            public int compare(Entry<Character, Integer> o1, Entry<Character, Integer> o2) {
                return (o2.getValue()).compareTo( o1.getValue());
            }
        };
        Collections.sort(list, cmp);
        
		System.out.println("sorted map by their values in desc order --> "+list);
		/*int i = 1;
		for (Entry<Character, Integer> e : list) {
			if(i==1) {
				System.out.println("The Most repeatin char is ---> "+ e.getKey()+" ---> Repeated "+e.getValue()+" times");
			} else if(i==2) {
				System.out.println("The Second Most repeatin char is ---> "+ e.getKey()+" ---> Repeated "+e.getValue()+" times");
			} else {
				break;
			}
			i++;
		}*/
		
		
		int i1 = 1;
		int firstMaxVal = 0;
		int secondMaxVal = 0;
		for (Entry<Character, Integer> e : list) {
			if(i1==1) {
				System.out.println("The Most repeatin char is ---> "+ e.getKey()+" ---> Repeated "+e.getValue()+" times");
				firstMaxVal = e.getValue();
			} else if(i1==2 && firstMaxVal== e.getValue()) {
				System.out.println("The Most repeatin char is ---> "+ e.getKey()+" ---> Repeated "+e.getValue()+" times");
				i1--;
			} else if(i1==2) {
				System.out.println("The Second Most repeatin char is ---> "+ e.getKey()+" ---> Repeated "+e.getValue()+" times");
				secondMaxVal = e.getValue();
			}  else if(i1==3 && secondMaxVal == e.getValue()) {
				System.out.println("The Second Most repeatin char is ---> "+ e.getKey()+" ---> Repeated "+e.getValue()+" times");
				i1--;
			} else {
				break;
			}
			i1++;
		}
		
		String inputStr = "Good looking";
		inputStr = inputStr.toLowerCase().replace(" ", "");//convert to lower case and remove space
		String uniqueCharStr = "";//resultant string
		for(int i=0; i<inputStr.length(); i++){ // for loop from first character to last character
			if(uniqueCharStr.indexOf(inputStr.charAt(i))<0){//if the character is not present in resultant string means add it to resultant string
				uniqueCharStr = uniqueCharStr + inputStr.charAt(i);
			}
		}
		System.out.println("String of unique characters: " +uniqueCharStr);
		
	}
	
}
