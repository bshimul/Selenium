package week7.homework;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Table1 {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://testleaf.herokuapp.com/pages/table.html");
		

		WebElement table = driver.findElementByXPath("//table[@cellspacing='0']");

		//List<WebElement> rows = table.findElements(By.tagName("tr"));
		
		List<WebElement> columns = table.findElements(By.xpath("//font[text()[contains(.,'%')]]"));
/*		
		
for(WebElement eachcol:columns)
{
	//System.out.println(eachcol.getText());
	String txt=(String) eachcol.getText();
    txt=txt.replace("%", "");
    int num=Integer.parseInt(txt);

if(num>num1)
	num1=num;
else
	num1
	
	
}

System.out.println(num1);
*/
		
		int num1=Integer.parseInt(columns.get(0).getText().replace("%",""));
		System.out.println("first"+num1);

		for (WebElement eachcol : columns) { // System.out.println(eachcol.getText());

			String txt = (String) eachcol.getText();

			txt = txt.replace("%", "");

			int num = Integer.parseInt(txt);

			if (num > num1) {
				num1 = num;
				System.out.println("first-->"+num1);
			}

		}
		System.out.println(num1);
	}
}