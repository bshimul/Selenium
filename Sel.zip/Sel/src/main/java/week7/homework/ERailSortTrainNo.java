package week7.homework;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class ERailSortTrainNo {

	public static void main(String[] args) throws AWTException, InterruptedException {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		/*driver.get("http://soma.fm/");
		// this one (and all the ones before) passes
		driver.findElement(By.xpath("//div[@id='stations']/ul/li[8]/a")).click();
		// back
		driver.findElement(By.linkText("soma fm")).click();
		// this one fails in chromedriver
		driver.findElement(By.xpath("//div[@id='stations']/ul/li[9]/a")).click();*/

		
		
		driver.get("https://erail.in");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		String selectAll = Keys.chord(Keys.CONTROL,Keys.ALT, Keys.DELETE);

		/*	Actions a = new Actions(driver);
		a.keyDown(Keys.ALT)
		.keyDown(Keys.LEFT_CONTROL)
		.keyDown(Keys.DELETE)
		.build().perform();
				Thread.sleep(2000);
		a.keyUp(Keys.ALT);
		a.keyUp(Keys.CONTROL);
		a.keyUp(Keys.DELETE);
		a.build().perform();
		*/
		 Robot r = new Robot();
		 r.keyPress(KeyEvent.VK_CONTROL);
		 r.keyPress(KeyEvent.VK_ALT);
		 r.keyPress(KeyEvent.VK_DELETE);
		 r.keyRelease(KeyEvent.VK_CONTROL);
		 r.keyRelease(KeyEvent.VK_ALT);
		 r.keyRelease(KeyEvent.VK_DELETE);
		driver.findElementById("txtStationFrom").clear();
		
		/*WebElement element = driver.findElement(By.linkText("iTime Alt (Time Sheet Management System)"));
        JavascriptExecutor js =(JavascriptExecutor)driver;
        js.executeScript("window.scrollTo(0,"+element.getLocation().x+")");
        element.click();*/
        
        
		driver.findElementById("txtStationFrom").sendKeys("MS", selectAll);

		driver.findElementById("txtStationTo").clear();
		driver.findElementById("txtStationTo").sendKeys("RMM", Keys.TAB);

		WebElement table = driver.findElementByXPath("//table[@class='DataTable TrainList']");

		
		List<WebElement> rows1 = table.findElements(By.tagName("tr"));
		List<WebElement> columns1 = rows1.get(1).findElements(By.tagName("td"));
		System.out.println(columns1.get(1).getText());
		
		
		
		List<WebElement> rows = table.findElements(By.tagName("tr"));
		System.out.println("No of trains -->"+rows.size());
		
		
		for (int i = 0; i < rows.size(); i++) {
			
		}
		List<Integer> trainNoList = new ArrayList<Integer>();
		for (WebElement row : rows) {
			List<WebElement> columns = row.findElements(By.tagName("td"));
			int trainNo = Integer.parseInt(columns.get(0).getText());
			trainNoList.add(trainNo);
		}
		System.out.println("Train Numbers Before Sort -->"+trainNoList);
		Collections.sort(trainNoList);
		System.out.println("Train Numbers After Sort -->"+trainNoList);
		driver.findElementByLinkText("Train").click();
		System.out.println("Train numbers are sorted in webpage");
		
		WebElement table1 = driver.findElementByXPath("//table[@class='DataTable TrainList']");

		List<WebElement> rows2 = table1.findElements(By.tagName("tr"));
		List<Integer> trainNoList1 = new ArrayList<Integer>();
		
		for (WebElement row : rows2) {
			List<WebElement> columns = row.findElements(By.tagName("td"));
			int trainNo = Integer.parseInt(columns.get(0).getText());
			trainNoList1.add(trainNo);
		}
		
		if (trainNoList1.equals(trainNoList))
			System.out.println("Train Numbers are Sorted correctly");
		else
			System.out.println("Train Numbers are Not Sorted correctly");
	}

}
