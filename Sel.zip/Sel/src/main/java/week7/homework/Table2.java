package week7.homework;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Table2 {
	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://erail.in");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		driver.findElementById("txtStationFrom").clear();
		driver.findElementById("txtStationFrom").sendKeys("MS", Keys.TAB);

		driver.findElementById("txtStationTo").clear();
		driver.findElementById("txtStationTo").sendKeys("RMM", Keys.TAB);

		WebElement table = driver.findElementByXPath("//table[@class='DataTable TrainList']");

		List<WebElement> columns = table.findElements(By.xpath("//a[@title='Click on train number to View fare and schedule']"));
		
		for(WebElement eachcol:columns)
		{
			System.out.println(eachcol.getText());
		}
		
		driver.findElementByXPath("//a[@title='Click here to sort on Train Number']").click();
		table = driver.findElementByXPath("//table[@class='DataTable TrainList']");
        List<WebElement> scolumns = table.findElements(By.xpath("//a[@title='Click on train number to View fare and schedule']"));
		
		for(WebElement eachcol:scolumns)
		{
			System.out.println(eachcol.getText());
		}
		
		
		

		
		
		
	}
}


