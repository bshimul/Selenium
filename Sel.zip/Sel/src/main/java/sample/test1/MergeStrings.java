package sample.test1;

public class MergeStrings {
	
	public static void main(String[] args) {
		String a="1";
		String b="45";
		System.out.println(mergeString(a,b));
	}

	private static String mergeString(String a, String b) {
		if (a.length()>25000 || b.length() > 25000){
			return "Invalid Input";
		}
		String result = "";
		int i;
		for (i=0;i<a.length()&&i<b.length();i++){
			result += a.charAt(i)+""+b.charAt(i);
		}
		if (a.length()>b.length()){
			result+=a.substring(i);
		} else {
			result+=b.substring(i);
		}
		return result;
			
	}
}
