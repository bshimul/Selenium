package sample.test1;

import java.util.Arrays;

public class MinimalOperations {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String []arr = {"ab","aab","abb","abab","abaaaaaab"};
		System.out.println(Arrays.toString(minimalOperations(arr)));
	}
	private static int[] minimalOperations(String[] words) {
		int []result = new int[words.length];
		for (int i=0;i<words.length;i++) {
			String s = words[i];
			char input[] = s.toCharArray();
			int k=0;
			for (int j=1;j<input.length;j++){
				if (input[j-1]==input[j]){
					input[j]='-';
					k++;
				}
			}
			result[i]=k;
		}
		return result;
	}
	
}
