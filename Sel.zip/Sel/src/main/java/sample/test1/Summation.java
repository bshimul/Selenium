package sample.test1;

public class Summation {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int []a = {1,5,2,2,3,3,5,1,9};
		System.out.println(summation(a));
	}
	
	private static int summation(int[] numbArray) {
		int sum=0;
		for(int i:numbArray){
			sum+=i;
		}
		return sum;
	}


}
