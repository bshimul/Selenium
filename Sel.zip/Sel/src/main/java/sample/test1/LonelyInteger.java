package sample.test1;

import java.util.Arrays;
import java.util.Collections;

import org.apache.commons.lang3.ArrayUtils;

public class LonelyInteger {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int []a = {1,5,2,2,3,3,5,1,9};
		System.out.println(lonelyInteger(a));
	}

	private static int lonelyInteger(int[] arr) {
		Arrays.sort(arr);
		for (int i = 0; i < arr.length; i=i+2) {
			for (int j = i+1; j < arr.length;) {
				if(arr[i]!=arr[j]){
					return arr[i];
				} else {
					break;
				}
			}
		}
		return arr[arr.length-1];
	}

}
