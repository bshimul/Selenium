package sample.test1;

import java.util.Arrays;

public class Emma {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String []arr={"2 27","17 1000000000"};
		System.out.println(Arrays.toString(getMinimumUniqueSum(arr)));
	}
	
	private static int[] getMinimumUniqueSum(String[] arr) {
		long sTime = System.currentTimeMillis();
		int len = arr.length;
		int result[] = new int[len];
		for(int i=0;i<len;i++){
			String input =arr[i];
			String inputValues[] = input.split(" ");
			if (inputValues.length==2) {
				int start = Integer.parseInt(inputValues[0]);
				int end = Integer.parseInt(inputValues[1]);
				int count =0;
				System.out.println(Math.sqrt(end));
				System.out.println(Math.floor(Math.sqrt(end)));
				System.out.println(Math.sqrt(start));
				System.out.println(Math.ceil(Math.sqrt(start)));
				System.out.println(Math.floor(Math.sqrt(end)) - Math.ceil(Math.sqrt(start))+1);
				
				result[i] = (int) (Math.floor(Math.sqrt(end)) - Math.ceil(Math.sqrt(start))+1);
				/*for(int j=start; j<=end;j++) {
					int sqrt = (int) Math.sqrt(j);
					if ((sqrt*sqrt)==j) {
						count++;
					}
				}
				result[i]=count;*/
			} else {
				result[i]=-1;
			}
		}
		long eTime = System.currentTimeMillis();
		System.out.println((eTime - sTime));
		return result;
	}

	

}
