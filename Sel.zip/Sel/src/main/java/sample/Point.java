package sample;

public class Point {
	int x,y;
	Point(int x1, int y1){
		x=x1;
		y=y1;
	}
}
