package sample;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TableLeafGroundHW {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://leafground.com/pages/table.html");
		WebElement table=driver.findElementByXPath("//table[@cellspacing='0']");
		List<WebElement> rows = table.findElements(By.tagName("tr"));
		
		int leastval = Integer.parseInt(rows.get(1).findElements(By.tagName("td")).get(1).getText().replace("%",""));
		int leastRow = 1;
		int noOfCols = 0;
		for (int i = 0; i < rows.size(); i++) {
			WebElement firstRow = rows.get(i);
			List<WebElement> columns = firstRow.findElements(By.tagName("td"));
			for (int j = 1; j < columns.size() - 1; j++) {
				String col = columns.get(j).getText().replace("%", "");
				noOfCols = columns.size();
				int curValue = Integer.parseInt(col);
				if (curValue < leastval) {
					leastval = curValue;
					leastRow = i;
				}
				System.out.println(col);
			}
		}
		System.out.println("No of columns is --> "+noOfCols);
		System.out.println("No of Rows is --> "+rows.size());
		System.out.println("Row "+leastRow+1+" has the least progress --> "+ leastval);
		rows.get(leastRow).findElements(By.tagName("td")).get(2).click();
		
}
}
