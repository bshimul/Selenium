package sample;

import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.ArrayUtils;


public class HomeWork {

	public static void main(String[] args) {
		//1.Write a program to reverse a number(eg. 1234 to 4321) without using modulus operator
		int numReverse = 1234;
		String sb = numReverse+"";
		char[] revNum = sb.toCharArray();
		System.out.print("Reverse of number "+numReverse+" is --> ");
		for (int i=sb.length()-1; i>=0 ; i--) {
			System.out.print(revNum[i]);
		}
		System.out.println();
		System.out.println();
		
		/*2.In a paragraph, I have to extract the following things
		Get only numbers
		Get only alphabets
		Get only alpha-numerics
		Get only spaces
		Get only special characters*/
		
		String paragraph = "It was 123123the bes-t of times, it was312312 the worst of times,\n"
		         + "i2t was th@e age 2of wisdom, it was the ag\\e of foolishness,\n"
		         + "it was the e5poch of belief, it wa{s the epoch o23f incredulity,\n"
		         + "it was the 654(7s)eason of Light, it was the season54@75 of Darkness,\n"
		         + "it was the spring of hope, it was the winter of despair,\n"
		         + "we ha34d everyt_0hing befo9re us, we had nothing b6ef}ore us";
		
		Pattern p = Pattern.compile("[\\d]");
		Matcher m = p.matcher(paragraph);
		int count=1;
		System.out.println("The numbers present in the paragraph are -->");
		while(m.find()){
			System.out.print(count+".-->"+m.group()+"   ");
			count++;
		}
		System.out.println();

		p = Pattern.compile("[a-zA-Z]");
		m = p.matcher(paragraph);
		count=1;
		System.out.println("The alphabets present in the paragraph are -->");
		while(m.find()){
			System.out.print(count+".--> "+m.group() + " ");
			count++;
		}
		System.out.println();

		//p = Pattern.compile("[a-zA-Z0-9]");
		String[] alphaNumerics = paragraph.split(" ");
		count=1;
		System.out.println("The alpha-numerics present in the paragraph are -->");
		for (String str : alphaNumerics) {
			if(str.matches("[A-Za-z]+[0-9]+[A-Za-z0-9]*|[0-9]+[A-Za-z]+[A-Za-z0-9]*")){
				System.out.print(count+".--> "+str + " ");
				count++;
			}
		}
		/*p = Pattern.compile("[A-Za-z]+[0-9]+[A-Za-z0-9]*|[0-9]+[A-Za-z]+[A-Za-z0-9]*");
		m = p.matcher(paragraph);
		i=1;
		while(m.find()){
			System.out.print(i+".--> "+m.group() + ", ");
			i++;
		}*/
		System.out.println();
		
		p = Pattern.compile("[\\s]");
		m = p.matcher(paragraph);
		count=1;
		System.out.println("The white spaces present in the paragraph are -->(new line also will be displayed as spaces)");
		while(m.find()){
			System.out.print(count+".-->"+m.group() + "");
			count++;
		}
		System.out.println();
		
		p = Pattern.compile("[^a-zA-Z0-9\\s]");
		//p = Pattern.compile("[a-zA-Z]+[0-9]+[a-zA-Z0-9]*|[0-9]+[a-zA-Z]+[a-zA-Z0-9]*");
		m = p.matcher(paragraph);
		count=1;
		System.out.println("The special characters present in the paragraph are -->");
		while(m.find()){
			System.out.print(count+".-->"+m.group() + " ");
			count++;
		}
		System.out.println();
		System.out.println();
		
		/*3.I have a string "CZ1234ABC45"
		For example in for loop :�for (i=1; i<=n; i++)
			In the above for loop, instead of 1 (one) for variable "i", we need assign the above string
			And it has to increment based on "i++"
			Write a logic for this.*/
		String loop = "CZ1234ABC45";
		Pattern p4=Pattern.compile("[0-9]");
		Matcher m4=p4.matcher(loop);
		if(m4.find()){
			for (int i=Integer.parseInt(m4.group());   ; i=Integer.parseInt(m4.group())) {
				System.out.print(i);
				if(!m4.find()){
					System.out.println();
					break;
				}
			}
		}
		System.out.println();
		
		//4.I have a float value 12345.4566
		double d = 12345.4566;
		int intPart = (int) d;
		double d1=d-intPart;
		System.out.println("Method 1 ####The value after dot is --> "+d1);

		String doubleStr = d+"";
		System.out.println("Method 2 ####The value after dot is --> "+doubleStr.split("\\.")[1]);
		System.out.println();
		
		//5.n=1238975. Find the biggest integer value in 'N'. [o/p : 9]
		int origDigit = 1238975;
		int digit = origDigit;
		int maxVal = 0;
		int val;
		while(digit>0){
			val = digit%10;
			digit = digit/10;
			if (val>maxVal){
				maxVal = val;
			}
		}
		System.out.println("The biggest integer Value in "+origDigit+" is "+maxVal);
		System.out.println();
		
		//6.Write Code: n=16845. O/p will be "n=14568". It should be integer value, It should be in ascending form.
		int origDigit1 = 16845;
		int digit1 = origDigit1;
		String digitStr = origDigit1+"";
		int[] arr = new int[digitStr.length()];
		int index = 0, tmp;
		while(digit1>0){
			val = digit1%10;
			digit1 = digit1/10;
			arr[index] = val;
			index++;
		}
		// Arrays.sort(arr) can also be used for below
		for (int j = 0; j < arr.length; j++) {
			for (int j2 = j; j2 < arr.length; j2++) {
				if(arr[j]>arr[j2]){
					tmp = arr[j2];
					arr[j2]=arr[j];
					arr[j]=tmp;
				}
			}
		}
		System.out.print("The ascending order of number "+origDigit1+" is ");
		for (int j : arr) {
			System.out.print(j);
		}
		System.out.println();
		System.out.println();
		
		//7.Write a code to Reverse a String. Without using any builtin functions like reverse(), charAt()
		String str = "Test Leaf Selenium";
		byte[] strChar = str.getBytes();
		byte[] rev = new byte[strChar.length];
		for (int i = 0; i < strChar.length; i++) {
			rev[i] = strChar[strChar.length -i -1];
		}
		System.out.println("The reverse of String "+str+" is "+new String(rev));
		System.out.println();
		
		//8.Write Code: Find the repeated words in a string.
		String repWords = "tis tis a a a repeated word";
		String[] repStr = repWords.split(" ");
		String[] dupStr = new String[0];
		for (int i = 0; i < repStr.length; i++) {
			for (int j = i+1; j < repStr.length; j++) {
				if(repStr[i].equals(repStr[j]) && !ArrayUtils.contains(dupStr, repStr[i])){
					dupStr = add(dupStr,repStr[i]);
				}
			}
		}
		System.out.println("The repeated words in the String are -->"+Arrays.toString(dupStr));
		System.out.println();
		
		//9. a{1,2,2,6,7,3,4,4,5,5,6,7}. Find the duplicate numbers in the above array and store in to a seperate array�9.
		int[] a = {1,2,2,3,4,4,5,5,6,7};
		int dup[] = new int[0] ;
		int nondup[] = new int[0];
		System.out.println("The Duplicated numbers in the array are -->"+Arrays.toString(a));
		System.out.println("The Duplicated numbers in the array are -->"+a);
		for (int i = 0; i < a.length; i++) {
			for (int j = i+1; j < a.length; j++) {
				if(a[i]==a[j] && !ArrayUtils.contains(dup, a[i])){
					dup = add(dup,a[i]);				
				}
			}
			if(!ArrayUtils.contains(dup, a[i])){
				nondup = add(nondup, a[i]);
			}
		}
		System.out.println("The Duplicated numbers in the array are -->"+Arrays.toString(dup));
		System.out.println("The Non-Duplicated numbers in the array are -->"+Arrays.toString(nondup));
		System.out.println();
		
		//10.You have a string with Alphabets,numeric & special character. Write a code to print alphabets,numeric and special character separately
		String print = "Th11@is is m2#y Wo4r6l8d!:)";
		Pattern p1=Pattern.compile("[\\W]");
		Matcher m1=p1.matcher(print);
		System.out.print("The special characters in the given string are ");
		while(m1.find()){
			System.out.print(m1.group().replace(" ", ""));
		}
		System.out.println(); //even spaces are special characters
		Pattern p2=Pattern.compile("[a-zA-Z]");
		Matcher m2=p2.matcher(print);
		System.out.print("The alphabets in the given string are ");
		while(m2.find()){
			System.out.print(m2.group());
		}
		System.out.println();
		Pattern p3=Pattern.compile("[0-9]");
		Matcher m3=p3.matcher(print);
		System.out.print("The digits in the given string are ");
		while(m3.find()){
			System.out.print(m3.group());
		}
		System.out.println();
	}
	
	private static int[] add(int[] b, int a) {
		int c[] = Arrays.copyOf(b, b.length +1);
	    c[b.length] = a;
		return c;
		
	}
	
	private static String[] add(String[] b, String a) {
		String c[] = Arrays.copyOf(b, b.length +1);
	    c[b.length] = a;
		return c;
		
	}
}

