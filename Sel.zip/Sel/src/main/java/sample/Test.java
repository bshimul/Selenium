package sample;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.Stack;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
@SuppressWarnings({"rawtypes","unused"})
public class Test {
	
	private static final Map map = new HashMap();
	public static final int X_SIZE = 4;
	public static final int Y_SIZE = 4;
	
	public static Set<Integer> primeFactors(long number) { 
		Set<Integer> primefactors = new HashSet<Integer>(); 
		long copyOfInput = number; 
		for (int i = 2; i <= copyOfInput; i++) { 
			if (copyOfInput % i == 0) {
				primefactors.add(i); // prime factor 
				copyOfInput /= i; 
				//i--; 
			} 
		} return primefactors; 
	}
	
	public static void spiralPrint(int xSize, int ySize, int matrix[][]){
		
		 
	    int i,  k = 0, l = 0;
	    xSize--;  ySize--;      

	    while(k <= xSize && l <= ySize){
	        for(i = l; i <= ySize; ++i) {
	            System.out.print(matrix[k][i]+ " ");
	        }           
	        k++;

	        for(i = k; i <= xSize; ++i) {
	            System.out.print(matrix[i][ySize] + " ");
	        }
	        ySize--;

	        for(i = ySize; i >= l; --i) {
	                System.out.print(matrix[xSize][i] + " ");
	        }
	        xSize--;


	        for(i = xSize; i >= k; --i) {
	            System.out.print(matrix[i][l] + " ");
	        }
	        l++;
	    }
	}

	public static void main(String[] args) {
		
		for (int i = 0; i < args.length; i++) {
			System.out.println(args[i]);
		}
		int a1 = 7, b1= 6;
		
		a1 = a1^b1;  // 0111 or 0110 = 0001 
		b1 = a1^b1;  // 0001 or 0110 = 0111
		a1 = a1^b1;  // 0001 or 0111 = 0110
		
		System.out.println("Value of a is :" + a1);
		System.out.println("Value of b is :" + b1);
		
		int findFact,finalFact=1;
		{
			System.out.println("Enter a number to find fatorial:");
			
			findFact= 1;
			if(findFact<0)
		{
		System.out.println("Invalid entry!!!");		
		}
			if(findFact==0||findFact==1)
			{
				System.out.println("The factorial of " +findFact +" is 1" );
			}
			else
			{
			for(int i=1;i<=findFact;i++)
			{	
				finalFact=finalFact*i;
			}
				System.out.println("Factorial of "+ findFact +" is: "+ finalFact);
			}
		}
		
		
		System.out.println(primeFactors(40));
		String a= "GoodLooking";
		int b = a.length();
		a.contains('c'+"");
		Boolean found= false;
		l:for(int i= 0; i<b; i++){
			for(int j=i+1; j<b; j++){
				if(a.charAt(i)==a.charAt(j)){
					found= true;
					break l;
				}
			}
			System.out.print(a.charAt(i));
		}
		 /*long num = 144;

		    for(long i = 1; i <= Math.sqrt(num); i++) {
		        if(num % i == 0) {
		            System.out.println(i);
		            if(i != num/i) {
		                System.out.println(num/i);
		            }
		        }
		    }
		    int[][] array = new int[X_SIZE][Y_SIZE];

		    for(int i = 0; i < X_SIZE; i++){
		        for (int j = 0; j < Y_SIZE; j++){
		            array[i][j] = i * X_SIZE + (j + 1);
		            System.out.print(array[i][j] + " ");
		        } 
		        System.out.println();
		    }*/

		    /*System.out.println("************");
		    System.out.println("Spiral");       

		    spiralPrint(X_SIZE, Y_SIZE, array);
*/
		
		//String str= "12345678";
		//System.out.println(reverseRecursively(str));
		/*Scanner in = new Scanner(System.in);
		System.out.println("Enter the Input IntNumber");
		int intNum = in.nextInt();
		System.out.println("Enter the Input IntDigit");
		int intDigit = in.nextInt();
		
		while (Integer.toString(intNum).contains(Integer.toString(intDigit))){
			intNum--;
		}
			System.out.println(" The Largest Numer is " + intNum);
		int[] dest = new int[]{0,1,2,3,4,5};
	    System.out.println(dest[0]+ dest[5]+dest[2]);
	    map.put("param1","value1");
	    map.put("param2","value2");
	   // map=new HashMap();
		//int[] intArray = {20, 340, 21, 879, 92, 21,474,83647,-200};
		//topTwo(intArray);
		new Test().test(null);
		f1(Integer.valueOf(8));
		int i=1999;
		if((i%4==0)&&(i%100!=0)||(i%400==0)){
			System.out.println("Given year is leapyear:"+i);
		}
		else
			System.out.println("Given year is not leapyear:"+i);
		
		String s3 = "JournalDev";
		int start = 1;
		char end = 5;
		System.out.println(start + end);
		System.out.println(s3.substring(start, end));*/
		
		/**
		 * @param args
		 */
			System.out.println(brackets("()[]{}(([])){[()][]}")); // true
			System.out.println(brackets("())[]{}")); // false
			System.out.println(brackets("[(])")); // false
			
			 System.out.println(prime(1));
			  // true
			  System.out.println(prime(2));
			  // true
			  System.out.println(prime(3));
			  // true
			  System.out.println(prime(5));
			  // false
			  System.out.println(prime(8));
			  // true
			  System.out.println(prime(13));
			  // false
			  System.out.println(prime(14));
			  // false
			  System.out.println(prime(15));
			  
			  String line = " aa bbbbb   ccc     d  ";
			// " aa bbbbb ccc d "
			System.out.println(line.replaceAll("[\\s]+", " ").trim());
			 String text = "     t     ";

			    text = text.replaceAll("\\s+$", "");
			    System.out.println("Text:" + text);
			    int leapYear=2000;
				if(leapYear%4==0 && leapYear%100!=0 || leapYear%400==0){
					System.out.println("The year "+leapYear+" is a leap year");
				}/*else if(leapYear%4==0 && leapYear%100==0 && leapYear%400==0){
					System.out.println("The year "+leapYear+" is a leap year");
				}*/else{
					System.out.println("The year "+leapYear+" is not a leap year");
				}
				
				
				String s = "  'aa bbb   cc  dd'  ";
				
				System.out.println("Given String:"+s);
				
				//Trim the trailing spaces
				s=s.trim();
				System.out.println("Given String after trimming trailing spaces:"+s);
				
				//trimmed more than one space
				s=s.replaceAll("( )+", " ");
				System.out.println("Given String after trimming more than one space: "+s);
				
				String s3=" aa bbbbb   ccc   d ";
				String s1=s3.replaceAll("( )+", " ");
				System.out.println(s1.replaceFirst("\\s++$", ""));
				
				
				int inputYear = 1700;
			      int isLeap = 0;
			      if(inputYear == 0)  //Checking for zero in console
			      {
			    	  System.out.println("Come on... "+inputYear+" is an invalid entry..!!");
			      }
			      else if(inputYear < 0) //Checking negative entry
			      {
			    	  inputYear = inputYear*(-1);
			      }
			      if(inputYear > 0) //Checking positive entry
			    	{
			    	  if(inputYear%4 == 0)  // Checking no. is divisible by 4
			    	    {
			    	     if ((inputYear%100 != 0)||(inputYear%400 == 0)) //Checking no. is divisible by 400 but not by 100
			    	      {
			    	       isLeap = 1;
			    	      }
			    	    }
			    	     if(isLeap == 1)
			    	     System.out.println(inputYear+" is a leap year..!");
			    	     else
			    	     System.out.println(inputYear+" is not a leap year..!");	 
			    	}
			      
			      int[] inArray = {10, -10, -20, -5, -21, -3}; //{20, 340, 21, 879, 92, 21, 474, 83647, -200};
					int grNum1, grNum2;
					
					//Find the second maximum number and print the value
					grNum1 = Integer.MIN_VALUE;
					grNum2 = Integer.MIN_VALUE;
					for(int x=0; x<inArray.length;x++){
						if(grNum1 < inArray[x]){
							grNum2 = grNum1;
							grNum1 = inArray[x];
						}else if (grNum2 < inArray[x]){
							grNum2 = inArray[x];
						}				
					}
					System.out.println(grNum2);
					
					int arr[] = {0,-5, -9, -6,-7, -3, -29, -52, -48, -36, -76, -81,-9};
			        int largest = arr[0];
			        int secondLargest = arr[0];

			        System.out.println("The given array is:" );

			        boolean find=false;
			        boolean flag=true;

			        for (int i = 0; i < arr.length; i++) 
			        {
			            System.out.print(arr[i]+"\t");
			        }
			        System.out.println("");

			        while(flag)
			        {
			            for (int i = 0; i < arr.length; i++) 
			            {
			                if (arr[i] > largest) 
			                {
			                    find=true;
			                    secondLargest = largest;
			                    largest = arr[i];
			                } 
			                else if (arr[i] > secondLargest) 
			                {
			                    find=true;
			                    secondLargest = arr[i];
			                }
			            }
			            if(find)
			            {
			                System.out.println("\nSecond largest number is:" + secondLargest);
			                flag=false;
			            }else
			            {
			                largest = arr[1];
			                secondLargest = arr[1];     
			            }
			        }
			        
			        String test = "{Java}/\\*(Selenium)";
			        System.out.println(test.replaceAll("\\W", ""));
			        System.out.println(test.replaceAll("[(]", "").replaceAll("[)]", "").replace("{", "").replace("}", "").replaceAll("\\*", "").replaceAll("/", "").replace("\\", " "));
			        
			        
					
					
					
			        for (int y = 0; y < 5; y++)
			        {
			            for (int j = 5; j > y; j--)
			            {
			                System.out.print(" ");
			            }
			            for (int k = 1; k <= y + 1; k++) {
			                System.out.print(" *");
			            }
			            System.out.print("\n");
			        }
	
	
	for (int ii = 1; ii <= 5; ii++)
    {
        if (ii%2!=0) {
			for (int j = 5; j >= ii; j--) {
				System.out.print(" ");
			}
			for (int k = 1; k <= ii; k++) {
				System.out.print(k + " ");
			}
		System.out.print("\n");
        }
    }
	for (int ii = 3; ii >= 1; ii--)
    {
        if (ii%2!=0) {
			for (int j = ii; j <= 5; j++) {
				System.out.print(" ");
			}
			for (int k = ii; k >= 1; k--) {
				System.out.print(k + " ");
			}
		System.out.print("\n");
        }
    }
	
	
	
	String s12 = "a";
	char c1 = s12.charAt(0);
	
	//here you can handle cases like z->a
	if (c1=='z') c1 = 'a';
	else c1++;
	System.out.println(c1);
	

	String pattern = "[a-zA-Z]{2}[0-9]{7}";
	System.out.println( "aa1234567".matches(pattern) ); // true
	System.out.println( "aa123456".matches(pattern) ); // false
	System.out.println( "aS1234567".matches(pattern) );
	
	String x = "abc";
	String y = new String("abc");
	System.out.println(x==y);
	
	
	
	String pwd1 = "ABCD";
	int dcount =0;
	int lcount = 0;
	int upcount=0;
	
		int i1111=0;			
	

		char r1 = pwd1.charAt(i1111);
		if(Character.isLetter(r1)||Character.isUpperCase(r1)||Character.isDigit(r1))
		{
			lcount++;
			upcount++;
			dcount++;
	
		if (lcount>2||upcount>2||dcount>2)
		{
			System.out.println("invalid");
			
		
		}
		if(pwd1.length()<3)
		{
			System.out.println("Please enter atleasr ten characters");
		
		}
		
		else
		{
			System.out.println("Valid password");
		}
	}
		Double dddd= 12345.67898779999999999999999999999999999999999999999999999999999999999;
		float d = (float) 2.2223;
        int i = (int) d;
        float r = d-i;
        System.out.println(d +"dddd"+ i +"iii"+ r);
        
        Double f = 12345.67898779999999999999999999999999999999999999999999999999999999999;;
        String ss = f%1 +"";
        System.out.println(ss.split("\\.")[0]+"dddd"+ss.split("\\.")[1]);
        
        Double b11=12345.45666666666;
		String c=b11+"";
		String[] d1=c.split("\\.");
		System.out.println(d1[1]);
		
		int n=16845;
		String nStr = n+"";
		Integer[] arr1 = new Integer [nStr.length()];
		int index = 0, reminder,temp;
		while (n>0) {
			reminder = n%10;
			arr1[index]=reminder;
			n=n/10;
			index++;
		}
		for (int j = 0; j < arr1.length; j++) {
			for (int j2 = j; j2 < arr1.length; j2++) {
				if(arr1[j]>arr1[j2]){
					temp = arr1[j];
					arr1[j] = arr1[j2];
					arr1[j2]=temp;
				}
			}
		}
		int result = Integer.valueOf(StringUtils.join(arr1));
		System.out.println(result);
		for (int j : arr1) {
			System.out.print(j);
		}
		System.out.println();
		char[] arr2 = nStr.toCharArray();
		Arrays.sort(arr2);
		int result1 =Integer.parseInt(ArrayUtils.toString(arr2).replaceAll("[\\W]", ""));
		System.out.println(result1);
		int a1111[] =  {1,2,2,6,7,3,4,4,5,5,6,7};
		extract();
		
	}
	private static void extract() {
		final int iii;
		iii=2;
		String a = "Th11is is m2y Wo4r6l8d!:)";
		Pattern p1=Pattern.compile(".");
		Matcher m1=p1.matcher(a);
		System.out.print("The special characters in the given string are ");
		while(m1.find()){
			System.out.print(m1.group());
		}
		System.out.println(); //even spaces are special characters
		Pattern p2=Pattern.compile("[a-zA-Z]");
		Matcher m2=p2.matcher(a);
		System.out.print("The alphabets in the given string are ");
		while(m2.find()){
			System.out.print(m2.group());
		}
		System.out.println();
		Pattern p3=Pattern.compile("[0-9]");
		System.out.println(a.matches("[0-9]"));
		System.out.println("99".matches("[0-9]+"));

		Matcher m3=p3.matcher(a);
		System.out.print("The digits in the given string are ");
		while(m3.find()){
			System.out.print(m3.group());
		}
		System.out.println();
		
		String input="AliveisAwesome";
		  StringBuilder input1 = new StringBuilder();
		  input1.append(input);
		  input1=input1.reverse(); 
		  for (int i=0;i<input1.length();i++)
			  System.out.print(input1.charAt(i)); 
		  System.out.println();
		  System.out.println(input1);
	
		  String str = "Test Leaf Selenium";
		  byte[] strChar = str.getBytes();
		  byte[] rev = new byte[strChar.length];
		  for (int i = 0; i < strChar.length; i++) {
			rev[i] = strChar[strChar.length -i -1];
		  }
		  System.out.println(new String(rev));
		  String loop = "CZ1234ABC45";
		  Pattern p4=Pattern.compile("[0-9]");
		  Matcher m4=p4.matcher(loop);
		  if(m4.find()){
			  for (int i=Integer.parseInt(m4.group());   ; i=Integer.parseInt(m4.group())) {
				System.out.print(i);
				if(!m4.find()){
					System.out.println();
					break;
				}
			  }
		  }
	}

	public static boolean prime(int n) {
		int a[] = {1,2,2,6,7,3,4,4,5,5,6,7};
		  return !new String(new char[n]).matches(".?|(..+?)\\1+");
		}
	
	public static boolean brackets(String in) {
		// Use a stack
		Stack<Character> s = new Stack<Character>();
		for (char c : in.toCharArray()) {
			if (s.empty()) {
				s.push(c);
				continue;
			}
			char last = s.peek();
			
			switch (c) {
			case ')':
				if (last != '(') {
					return false;
				}
				s.pop();
				break;
			case '}':
				if (last != '{') {
					return false;
				}
				s.pop();
				break;
			case ']':
				if (last != '[') {
					return false;
				}
				s.pop();
				break;
			default:
				if (c=='(' || c=='[' || c=='{') {
					s.push(c);
				}
				if (c==')' || c==']' || c=='}') {
					return false;
				}
				break;
			}
		}
		
		return true;
		
	}
	
	public static void f1(Integer i){
	     System.out.println("inside 1");
	   }
	   public void f1(int i){
	     System.out.println("inside 2");
	   }
	public void f1(Object o1) {
	    System.out.println("Inside f1 with object as argument");
	  }
	  public void f1(String s) {
	    System.out.println("Inside f1 with String as argument");
	  }
	private void test(String object) {
		System.out.println("strin");		
	}
	

	public static void topTwo(int[] numbers) { 
		int max1 = Integer.MIN_VALUE; 
		int max2 = Integer.MIN_VALUE; 
		for (int number : numbers) { 
			if (number > max1) { 
				max2 = max1; 
				max1 = number; 
			} else if (number > max2) {
				max2 = number; 
			} 
		} 
		System.out.println("Given integer array : " + Arrays.toString(numbers)); 
		System.out.println("First largest number is : " + max1); 
		System.out.println("Second largest number is : " + max2); 
	}

	public static String reverseRecursively(String str) {

        if (str.length() < 2) {
            return str;
        }
        System.out.println(str.substring(1)+"-----"+str.charAt(0));
        return reverseRecursively(str.substring(1)) + str.charAt(0);
        
        
        }

}
