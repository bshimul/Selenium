package sample;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Super {
	@BeforeMethod(groups={"common"})
	public void beforeMet() throws InterruptedException{
		System.out.println("common" +Thread.currentThread().getName());
	}
}
