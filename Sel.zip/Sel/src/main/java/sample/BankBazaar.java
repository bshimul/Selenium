package sample;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import week4.homework.GenericWrappers;

public class BankBazaar extends GenericWrappers {
@Test
	public void bank() throws InterruptedException
	{
		invokeApp("chrome","https://www.bankbazaar.com/personal-loan.html");
		clickByXpath("//div[@class = 'tab-sec custom-quote']");
//		clickByClassName("eligcol-md-5 col-xs-5 eform-col-section");
		clickByXpath("//div[@class = 'eligcol-md-5 col-xs-5 eform-col-section']");
//		clickByXpath("//label[text() = 'Chennai']");
//		clickById("slideForm_form_applicantPlaceHolder_residenceCity_valueNEW DELHI");
		Thread.sleep(3000);
		clickByXpath("//span[@class='sprite-city icon-city-new-delhi']");
		
//		clickByClassName("sprite-city icon-city-new-delhi");
//		enterById("form_applicantPlaceHolder_companyName_autoComplete","microsoft");
		Thread.sleep(3000);
		enterByXpath("(//input[@name='form.applicantPlaceHolder.companyName'])[2]", "microsoft");
		
		Thread.sleep(3000);
		enterByXpath("//input[@id='form_details_applicant_income_monthlyTakeHomeSalary']","105000");
		Thread.sleep(3000);
		clickByXpath("//div[@class = 'col-md-2 col-xs-3 eform-col col-12 eform-col-section eform-col-section']");
		Thread.sleep(3000);
		clickByXpath("//a[text()='Before 2013']");
		Thread.sleep(3000);
        WebElement slider = driver.findElement(By.xpath("(//div[@class='slider-handle round'])[4]"));
        Actions move = new Actions(driver);
        Action action = (Action) move.dragAndDropBy(slider, 280, 0).click().build();
        action.perform();
        Thread.sleep(1000);
        System.out.println("slider moved");
		Thread.sleep(3000);
		//clickByXpath("//div[@class='tooltip-inner' and text()='>6']");
        //clickByXpath("(//button[@class='btn  js-move-next js-move-next-btn'])[4]");
		clickByXpath("(//a[text()='Before 2013'])[2]");
		clickByXpath("(//a[text()='Before 2013'])[3]");
		Thread.sleep(5000);
		clickByXpath("//span[text()='Owned by self/spouse']");
		
		}

}
