package sample;

public class Vehicle {
	public Vehicle(){
		System.out.println("inside Vehicle");
	}
	public static void main(String[] args) {
		new Audi();
	}
}
class Car extends Vehicle {
	public Car() {
		System.out.println("inside car");
	}
}
	class Audi extends Car{
		public Audi() {
			System.out.println("inside Audi");
		}
	}

