package sample;

import java.util.HashSet;
import java.util.Set;

public class Parent {

	 public  void staticMethod(){
	   System.out.println("Inside Parent static");
	 }
	 public Parent(int i)
	    {
	        System.out.println(1);
	    }
	 public static void main(String[] args) {
	   Parent p = new Child();
	   p.staticMethod();
	   
	   
	   String [] sValue = new String[]{"abc","bcd","abc","dca","bcd"};
	   
	   System.out.println("Normal Method \n"+FindDupValue(sValue));
	   
	   System.out.println("Using Builtin Class Set \n"+FindDupValueUsingSet(sValue));
	   
	   }
	   
	   private static String FindDupValue(String[] sValueTemp)
	   {
	   for (int i = 0; i < sValueTemp.length; i++) {
	   String sValueToCheck = sValueTemp[i];
	   if(sValueToCheck==null || sValueToCheck.equals(""))continue;
	   for (int j = 0; j < sValueTemp.length; j++) {
	   if(i==j)continue;
	   String sValueToCompare = sValueTemp[j];
	   if (sValueToCheck.equals(sValueToCompare)){
	   return sValueToCompare;
	   }
	   }
	   
	   }
	   return "";
	   
	   }
	   @SuppressWarnings({ "unchecked", "rawtypes" })
	private static String FindDupValueUsingSet(String[] sValueTemp)
	   {
	   Set sValueSet = new HashSet();
	   for(String tempValueSet : sValueTemp)
	   {
	   if (sValueSet.contains(tempValueSet))
	   return tempValueSet;
	   else
	   if(!tempValueSet.equals(""))
	   sValueSet.add(tempValueSet);
	   }
	   return "";
	   }
	   
	}