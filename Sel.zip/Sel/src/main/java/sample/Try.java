package sample;

import java.io.IOException;

class C {
    public float m(float x, float y) throws IOException {
        return 0;
    }
    @Override
    public boolean equals(Object obj) {
        return (this == obj);
    }
    @Override
    public int hashCode() {
        return 0;
    }
}

class D extends C {
    @Override
    public float m(float x, float y) throws ArithmeticException{
        return 0;
    }
}

public class Try {
    public static void main(String[] args) {
    	/*Integer a = null;
    	int b = a;
    	System.out.println(b);*/
    	System.out.println(m (new C(), new C()));
    	long start = System.currentTimeMillis();
    	new Try().n_squares(2000);
    	long end = System.currentTimeMillis();
    	System.out.println(end-start);
    }
    
    
    String n_squares(int n) {
        StringBuffer s = new StringBuffer("0");
        int n_squared = n*n;
        for (int i=0; i<n_squared; i++) {
            s.append (", " + i);
        }
        return s.toString();
    }
    public static String m(C o1, C o2) {
        String s1 = o1 == o2 ? "T" : "F";
        String s2 = o1.equals(o2) ? "T" : "F";
        String s3 = o1.hashCode() == o2.hashCode() ? "T" : "F";
        System.out.println(o1.hashCode() +"  "+o2.hashCode());
        try {
            int c = 1/0;
        } catch (Exception e) {
            System.out.println("E");
        } finally {
            System.out.println("F");
        }
        
        
        
        return s1 + s2 + s3;
    }
}