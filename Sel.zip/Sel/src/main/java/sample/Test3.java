package sample;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.ArrayUtils;
import org.testng.Assert;


public class Test3 {

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static void main(String[] args) throws UnknownHostException {
		int rows=4,columns=4;
		int sumOfDiagonal1=0;
		int sumOfDiagonal2=0;
		ArrayList<Integer> aboveDiagonal = new ArrayList<Integer>();
		LinkedList<Integer> ll = new LinkedList<>();
		ArrayList<Integer> belowDiagonal = new ArrayList<Integer>();
        int[][] matrix = {{1,2,3,4},{5,6,7,8},{9,10,11,12},{13,14,15,16}};
        for (int i = 0; i < rows-1; i++) {
        	for(int j=0; j<columns - 1 - i ;j++){
        		System.out.print(matrix[i][j] +",");
        		sumOfDiagonal1= sumOfDiagonal1 + matrix[i][j];
        		aboveDiagonal.add(matrix[i][j]);
        	}
		}
        
        String sss="a";
        switch (sss) {
		case "a":
			
			break;

		default:
			break;
		}
        System.out.println();
        for (int i = rows-1; i >=0 ; i--) {
        	for(int j=columns - 1; j>=columns -i ;j--){
        		System.out.print(matrix[i][j]+",");
        		sumOfDiagonal2= sumOfDiagonal2 + matrix[i][j];
        		belowDiagonal.add(matrix[i][j]);
        	}
		}
        System.out.println();
		System.out.println("sum of diaognal1 elements(above)="+sumOfDiagonal1);
		System.out.println("sum of diaognal2 elements(below)="+sumOfDiagonal2);
		if(sumOfDiagonal1>sumOfDiagonal2) {
			System.out.println(aboveDiagonal);
		} else {
			System.out.println(belowDiagonal);
		}
		System.out.println("b6ef}ore".matches("[A-Za-z]+[0-9]+[A-Za-z0-9]*|[0-9]+[A-Za-z]+[A-Za-z0-9]*"));
		
		String input = "12vbvmebri23u92";
		System.out.println(input.indexOf(""));
		 final StringBuilder sb = new StringBuilder(input.length());
		 for(int i = 0; i < input.length(); i++){ 
			 final char c = input.charAt(i);        
			 if(c > 47 && c < 58){             
				 sb.append(c);         
			}     
		}     
		 System.out.println(sb.toString()); 
		 
		 StringBuffer SA = new StringBuffer("Test"); 
		 StringBuffer SB = SA; 
		 SA = SA.append("Leaf");  
		 System.out.println(SA); System.out.println(SB); 
		 double d = 12345.4566; // option 1  
		 double v = d - (int) d;  
		 System.out.println(v);  
		 Float f = 12345.4566f; // option 2  
		 v = f - Math.floor(f);  
		 System.out.println(v);
		 Integer[] arr={1,2,3,21,2,1,5};
		 Object[] arr1 = new HashSet(Arrays.asList(arr)).toArray();
		 System.out.println(ArrayUtils.toString(arr1));  
		 
		 int rows1 = 5;
			for(int i =0;i<rows1;i++) {
	        int number = 1;
	                  System.out.format("%"+(rows1-i)+"s","");
			           
			            for(int j=0;j<=i;j++) {
			            	
			                System.out.format("%2d",number);
			            
			                
			                
			            	number = number * (i - j) / (j + 1);
			               }

			            System.out.println();

			        }
			
			int a[]={1,8,6,5,5,3};
			int temp;
			for(int i=0;i<=5;i++) 		{ 		
				for(int j=i+1;j<=5;j++) 		{ 		
					if(a[j]<a[i]) 		{ 
						temp = a[i]; 	
						a[i] = a[j];
						a[j] = temp;
						// need to compare a[i] and a[j] not i and j
			}
				 //swapping to bring less value to first 
					} 
				System.out.println("after iteration i="+i+"-->"+ArrayUtils.toString(a));
				} 
			System.out.println(ArrayUtils.toString(a));
			
			int[] ascendingNumber = {1,8,6,5,3,5};
			for (int i = 0; i < 6; i++) {
				for (int j = i+1; j < 6; j++) {

					if(ascendingNumber[i]>ascendingNumber[j]){
						temp=ascendingNumber[i];
						ascendingNumber[i]=ascendingNumber[j];
						ascendingNumber[j]=temp;
					}

				}
			}
			
			StringBuilder strNum = new StringBuilder();

			for (int num : ascendingNumber) 
			{
			     strNum.append(num);
			}
			int finalInt = Integer.parseInt(strNum.toString());
			System.out.println("Numbers in Ascending order: "+finalInt);
			String val1="Pradeep";
			String val2="Raj";	
			val1=val1+val2;
			val2=val1.substring(0, val1.length()-val2.length());
			System.out.println(val2.length());
	        val1=val1.substring(val2.length());
		    System.out.println(val1);
		    System.out.println(val2);
		    
		    int[] z=new int[10];
		    System.out.println(Arrays.toString(z));
		    z[0]=1;
		    z[1]=2;
		    System.out.println(Arrays.toString(z));
		    z=new int[5];
		    System.out.println(Arrays.toString(z));
		    z[0]=1;
		    z[1]=2;
		    System.out.println(Arrays.toString(z));
		    
		    int[] a1 = {1, 2, 3, 4, -5,6,7,8};
		    // make a one bigger
		    a1 = Arrays.copyOf(a1, a1.length + 1);
		    for (int i : a1)
		    System.out.println(i);
		    
		    
		    String[] newTest = new String[]{"-1","-2","3","4", "5","6","-9","5","6","-9"};
		    String word = "";
		    int wordMaxLen = 0;
		    String  wordMax= "";
		    for (int i = 0; i < newTest.length; i++) {
				int num = Integer.parseInt(newTest[i]);
				if (num>=0) {
					word += newTest[i]+"";
				} else {
					word = "";
				}
				if (word!="" &&  word.length()>wordMaxLen){
					wordMax = word;
					wordMaxLen = wordMax.length();
					//word = "";
				}
			}
		    System.out.println(wordMax);
		    System.out.println(wordMaxLen);
		    
		    
		    int i=7;
		    int ii = i/2;
		    System.out.println(ii);
		    
		    int year = 1700;
			if (year % 4 == 0) {
				if (year % 100 != 0) {
					System.out.println("Given year is leap year");
				} else if (year % 400 == 0) {
					System.out.println("Given year is leap year");
				}

				else {
					System.out.println("Given year is not leap year");
				}
			} else {
				System.out.println("Given year is not leap year");
			}
			String str = "yyyyyHelloyyyy";
			System.out.println(str.replaceAll("[y]", ""));
		        Scanner s = new Scanner(System.in);
		        String abc = s.next();
				Pattern ptn = Pattern.compile("[a-zA-Z0-9]{1,}\\s{1}+[(][\\d]+[)]");
				Pattern ptn1 = Pattern.compile("[a-zA-Z0-9]+( \\(\\d+\\))*");
		        Matcher mtch = ptn1.matcher(abc);
		        System.out.println(mtch.matches());
		        System.out.println(validate("01.255.255.255"));
		        System.out.println(InetAddress.getLocalHost().getHostAddress());

	        
	}
	private static final Pattern PATTERN = Pattern.compile(
	        "^(([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.){3}([01]?\\d\\d?|2[0-4]\\d|25[0-5])$");

	public static boolean validate(final String ip) {
	    return PATTERN.matcher(ip).matches();
	}


}
