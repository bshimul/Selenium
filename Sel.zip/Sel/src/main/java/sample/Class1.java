package sample;

import org.testng.annotations.Test;

public class Class1 extends Super{
	@Test(groups={"smoke"})
	public void smoke1() throws InterruptedException{
		System.out.println("smoke1 ---> Thread Name -- " +Thread.currentThread().getName());
		Thread.sleep(5000);
	}
}
