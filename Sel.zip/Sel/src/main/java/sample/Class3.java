package sample;

import org.testng.annotations.Test;

public class Class3 extends Super{
	@Test(groups={"sanity"}, dependsOnGroups={"smoke"})
	public void smoke2() throws InterruptedException{
		System.out.println("sanity1 ---> Thread Name -- " +Thread.currentThread().getName());
		Thread.sleep(5000);
	}
}







