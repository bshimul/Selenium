package sample;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BookTransfer {

	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");

		//Creating Chromedriver instance
		ChromeDriver driver=new ChromeDriver();

		//Launch the browser
		driver.get("https://www.amazon.com/");

		//Maximizing the browser
		driver.manage().window().maximize();
		WebDriverWait wait = new WebDriverWait(driver,15);

		WebElement menu = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='nav-link-accountList']/span[1]")));
		//WebElement menu= driver.findElementByXPath("//*[@id='nav-link-accountList']/span[1]");

		Actions mouseover=new Actions(driver);
		mouseover.moveToElement(menu).perform();
		mouseover.pause(Duration.ofSeconds(5));
		WebElement submenu= driver.findElementByXPath("//*[@id='nav-flyout-ya-signin']/a/span");
		mouseover.click(submenu).perform();
		System.out.println("Sign In Clicked");

		driver.findElementById("ap_email").sendKeys("nischitha.gu@gmail.com");
		driver.findElementById("ap_password").sendKeys("kindleda");
		driver.findElementById("signInSubmit").click();

		//WebElement menu2= driver.findElementByXPath("//*[@id='nav-link-accountList']/span[2]");
		WebElement menu2= wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='nav-link-accountList']/span[2]")));

		Actions mouseover2=new Actions(driver);
		mouseover2.moveToElement(menu2).perform();
		mouseover2.pause(Duration.ofSeconds(5));
		//WebElement submenu2= driver.findElementByXPath("//*[@id='nav-al-your-account']/a[13]/span");
		WebElement submenu2= wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='nav-al-your-account']/a[13]/span")));
		mouseover2.click(submenu2).perform();
		System.out.println("Your content and device Clicked");
		WebElement booksText= wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[starts-with(text(),'Showing ')]")));
		String text = booksText.getText();
		int i=0;
		int totalBooks = Integer.parseInt(text.substring(text.indexOf("of")+3, text.indexOf("items")-1));
		System.out.println("total number of books --> "+totalBooks);
		Thread.sleep(5000);
		List <WebElement> checkBoxes = driver.findElementsByXPath("//label[starts-with(@class,'listViewIconPosition_myx')]");
		for( ; i<totalBooks; i++) {
			if (i<checkBoxes.size()) {
				WebElement ele = wait.until(ExpectedConditions.elementToBeClickable(checkBoxes.get(i)));
				try {
					ele.click();
				} catch (WebDriverException e) {
					System.out.println("element not clickable at center point");
					new Actions(driver).moveToElement(ele, 0, 20).click().perform();
				}
				if((i+1)%10==0){
					deliverBooks(driver);
					System.out.println("Books - "+(i-8)+" to "+(i+1)+" are delivered");
				}
			} else {
				((JavascriptExecutor)driver).executeScript("window.scrollBy(0,250)", "");
				checkBoxes = driver.findElementsByXPath("//label[starts-with(@class,'listViewIconPosition_myx')]");
				i--;
			}
		}
		deliverBooks(driver);
		System.out.println("Books - 1 to "+i+" are delivered");
	}
	
	public static void deliverBooks(RemoteWebDriver driver) throws InterruptedException {
		driver.findElementByXPath("//span[text()='Deliver']").click();
		driver.findElementByXPath("//span[contains(text(),'Devices Selected')]").click();
		driver.findElementByXPath("//span[contains(text(),'7th Kindle')]").click();
		driver.findElementByXPath("//span[text()=' Deliver ']").click();
		try {
			WebDriverWait wait4 = new WebDriverWait(driver,4);
			WebElement OK= wait4.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()=' OK ']")));
			OK.click();
			System.out.println("pop up of undelivered books appeared");
		} catch (TimeoutException e) {
			System.out.println("pop up of undelivered books did not appear");
		}
		Thread.sleep(5000);
	}
}