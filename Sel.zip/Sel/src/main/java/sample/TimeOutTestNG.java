package sample;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class TimeOutTestNG {
	
	@BeforeMethod
	public static void met1(){
		System.out.println("Before met..."+ Thread.currentThread().getId());
	}
	
	
	@AfterMethod
	public static void met2(){
		System.out.println("After met..."+ Thread.currentThread().getId());
	}
	
	@Test(invocationCount=2, expectedExceptions={ArrayIndexOutOfBoundsException.class,RuntimeException.class})
	public static void test(){
		System.out.println("Test met..."+ Thread.currentThread().getId());
		throw new RuntimeException();
	}
	@Test( invocationTimeOut = 1000, invocationCount = 10, threadPoolSize = 1 ) 
	   public void test1ShouldFail() throws InterruptedException { 
		System.out.println("test1ShouldFail");
	      Thread.sleep( 10 ); 
	   } 

	   /*@Test(invocationTimeOut = 100, invocationCount = 10, threadPoolSize = 5 ) 
	   public void test2ShouldFail() throws InterruptedException { 
			System.out.println("test2ShouldFail");
	      Thread.sleep( 20 ); 
	   } 

	   @Test( invocationTimeOut = 500, invocationCount = 10, threadPoolSize = 2 ) 
	   public void test3ShouldFail() throws InterruptedException { 
			System.out.println("test3ShouldFail");
	      Thread.sleep( 20 ); 
	   } */

}

