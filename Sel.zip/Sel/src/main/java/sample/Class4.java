package sample;

import org.testng.annotations.Test;

public class Class4 extends Super{
	@Test(groups={"sanity"}, dependsOnGroups={"smoke"})
	public void smoke2() throws InterruptedException{
		System.out.println("sanity2 ---> Thread Name -- " +Thread.currentThread().getName());
		Thread.sleep(5000);
	}
}
