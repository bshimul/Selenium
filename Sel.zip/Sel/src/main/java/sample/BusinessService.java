package sample;

public class BusinessService {

	public void businessMethod() {
		Context context = MyThreadLocal.get();
		System.out.println(context.getTransactionId());
	}
}