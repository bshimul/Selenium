package sample;
import java.util.Map;
import java.util.TreeMap;

public class ServerDetails {
	String name, application, software, version;
	static Map<String, Integer> hmAllSwDet = new TreeMap<String, Integer>();

	/**
	 * Creates a ServerDetails instance with name, application, software and version
	 * @param name 
	 * 			The name of the server
	 * 
	 * @param application
	 * 			The application which is installed in the server
	 * 
	 * @param software
	 * 			The software name of the application
	 * 
	 * @param version
	 * 			The version of the software installed in the server
	 */
	public ServerDetails(String name, String application, String software, String version) {
		this.name = name;
		this.application = application;
		this.software = software;
		this.version = version.trim();
		String serSwVersionKey = application+":"+software+"_"+version.trim();
		if (!hmAllSwDet.containsKey(serSwVersionKey)) {
			hmAllSwDet.put(serSwVersionKey, 1);
		} else {
			hmAllSwDet.put(serSwVersionKey, hmAllSwDet.get(serSwVersionKey)+1);
		}
	}
	
	/**
	 * 
	 * @param key as application:software_version
	 * @return value 0 if the key is not present and if only one server has the key   
     * 		   a value 1 if more than one server has the key 
	 */
	public static int calcOutDatedSrv(String key) {
		return (hmAllSwDet.get(key) == null && hmAllSwDet.get(key) > 1) ? 0 : 1;
	}

}
