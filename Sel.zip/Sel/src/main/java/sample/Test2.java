package sample;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.ArrayUtils;

public class Test2 {

	public static void main(String[] args) {
		
		
		List<String> mentors = new ArrayList<String>();
		mentors.add("Gopi");
		mentors.add("Nesa");
		mentors.add("Sethu");
		mentors.add("Babu");
		mentors.add("Lokesh");
		mentors.add("Chaitanya");
		mentors.add("Karim");
		mentors.add("Gopi");
		mentors.add("Babu");
		mentors.add("Karim");
		mentors.add("Chaitanya");
		mentors.add("Babu");
		mentors.add("Gopi");
		mentors.add("Karim");
		mentors.add("Gopi");
		mentors.add("Babu");
		mentors.add("Gopi");
		mentors.add("Babu");
		Map<String, Integer> map = new LinkedHashMap<String, Integer>();
		Set<String> set = new LinkedHashSet<String>(mentors);
		for (String s : set) {
			for (String mentor : mentors) {
				if(s.equals(mentor)){
					if(map.containsKey(s)){
						map.put(s, map.get(s)+1);
					} else {
						map.put(s, 1);
					}
				}
			}
		}
		for (Entry<String, Integer> e : map.entrySet()) {
			if (e.getValue()>1){
				System.out.println("the mentor "+e.getKey()+" is repeated "+e.getValue()+" times");
			}
		}
		 int a[] = {1,2,2,3,4,4,5,5,6,7};
		 int dup[] = new int[0] ;
		 int nondup[] = new int[0] ;
		 for (int i = 0; i < a.length; i++) {
			for (int j = i+1; j < a.length; j++) {
				if(a[i]==a[j] && !ArrayUtils.contains(dup, a[i])){
					dup = add(dup,a[i]);				
				}
			}
			if(!ArrayUtils.contains(dup, a[i])){
				nondup = add (nondup, a[i]);
			}
		 }
			 System.out.println(Arrays.toString(dup));
			 System.out.println(Arrays.toString(nondup));
			 String t = "123abc,;)";
			 System.out.println(t.replaceAll("[^0-9]", ""));
			 System.out.println(t.replaceAll("[^a-zA-Z]", ""));
			 System.out.println(t.replaceAll("[^\\W]", ""));
			 Pattern p = Pattern.compile("[0-9]{1,}");
			 Matcher m = p.matcher(t);
			 while(m.find()){
				 System.out.println(m.group());
			 }
			 for (int i = 0; i <= 9; i++) {
							System.out.println(i+""+i+""+i);
			}
			 String rep = "tis tis a a a repeated word";
			 String[] repStr = rep.split(" ");
			 String[] dupStr = new String[0];
			 for (int i = 0; i < repStr.length; i++) {
				for (int j = i+1; j < repStr.length; j++) {
					if(repStr[i].equals(repStr[j]) && !ArrayUtils.contains(dupStr, repStr[i])){
						System.out.println(repStr[i]);
						dupStr = add(dupStr,repStr[i]);
					}
				}
			}
			int n=16845;
			String asc =Integer.toString(n);
			char as[]= asc.toCharArray();
			Arrays.sort(as);
			System.out.println(Arrays.toString(as).replace("[" , "").replace("]" , "").replace(", " , ""));
			System.out.println();
			 
			String str1= "ABC1234CDE";
			System.out.println(str1.replaceAll("\\d+", ""));
			
			 
			 
			 
			 
			 primeFact(10);
			 System.out.println();
			 for (int i = 1; i <= 9; i++) {
				 for (int j = 1; j <= i; j++) {
					 System.out.print(i+"");
				 }
				 System.out.println();
					
			 }
			 System.out.println(String.format("%06d", 1110));
			 System.out.println(String.join("", Collections.nCopies(4, "ABC")));
			 double d = 12345.4566;
			 int i = (int) d;
			 System.out.println(d-i);
	}

	
	public static void primeFact(int inVal){
		System.out.println();
		System.out.print("Prime Factorial of the number \""+inVal+"\" : ");
		int outVal=0,divVal, primeFlag=0;
		divVal=inVal;
		while(divVal!=1)
		{
			for(int i=2; i<inVal;i++){
				if(divVal%i==0){
					if(outVal<i){
						outVal=i;
						System.out.print(outVal+" ");
					}
					divVal=divVal/i; 
					primeFlag=1;
					break;
				}			
			}
			if (primeFlag==0){
				System.out.println("is prime by itself");
				break;
			}
		}
	}
	
	private static int[] add(int[] b, int a) {
		int c[] = Arrays.copyOf(b, b.length +1);
	    c[b.length] = a;
		return c;
		
	}
	private static String[] add(String[] b, String a) {
		String c[] = Arrays.copyOf(b, b.length +1);
	    c[b.length] = a;
		return c;
		
	}
	
}
