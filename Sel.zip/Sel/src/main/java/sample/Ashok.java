package sample;

import wrappers.GenericWrappers;

public class Ashok extends GenericWrappers{

	public static void main(String[] args) throws InterruptedException {
		Child c = new Child();
		c.a =11;
		c.staticMethod();
		GenericWrappers wra = new GenericWrappers();
		wra.invokeApp("chrome", "https://www.bankbazaar.com/personal-loan.html");
		wra.clickByXpath("//div[@class='tab-sec custom-quote']");
		wra.clickByXpath("//div[@class='eligcol-md-5 col-xs-5 eform-col-section']");
		Thread.sleep(5000);
		wra.clickByXpath("//span[@class='sprite-city icon-city-chennai']");
		Thread.sleep(5000);
		wra.enterByXpath("(//input[@name='form.applicantPlaceHolder.companyName'])[2]", "microsoft");
		
	}

}
