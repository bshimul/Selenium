package sample;

import org.testng.annotations.Test;

public class Class2 extends Super{
	@Test(groups={"smoke"})
	public void smoke2() throws InterruptedException{
		System.out.println("smoke2 ---> Thread Name -- " +Thread.currentThread().getName());
		Thread.sleep(5000);
	}
}
