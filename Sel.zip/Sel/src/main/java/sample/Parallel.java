package sample;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Parallel {
	@BeforeMethod
	public static void met1(){
		System.out.println("111Before met..."+ Thread.currentThread().getId());
	}
	
	
	@AfterMethod
	public static void met2(){
		System.out.println("1111After met..."+ Thread.currentThread().getId());
	}
	
	@Test(expectedExceptions={ArrayIndexOutOfBoundsException.class,RuntimeException.class})
	public static void test(){
		System.out.println("1111111Test met..."+ Thread.currentThread().getId());
		throw new RuntimeException();
	}
}
