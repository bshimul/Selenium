package sample;

import org.testng.annotations.Test;

public class Class5 extends Super{
	@Test(groups={"re"}, dependsOnGroups={"sanity"})
	public void smoke2() throws InterruptedException{
		System.out.println("re ---> Thread Name -- " +Thread.currentThread().getName());
		Thread.sleep(5000);
	}
}
