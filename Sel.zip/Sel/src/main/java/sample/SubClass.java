package sample;


class SubClass
{
   SubClass(){
	/* super() must be added to the first
	 * line of constructor otherwise it would
	 * throw compilation error: 
	 * " Constructor call must be the first statement 
	 * in a constructor".
	 */
	super();
	System.out.println("Constructor of Subclass");
		
   }
   void display(){
	System.out.println("Hello");
   }
   public static void main(String args[]){
	SubClass obj= new SubClass();
	Parentclass c = new Parentclass();
        obj.display();
        new AnonymousInner() {
            public void mymethod() {
               System.out.println("This is an example of anonymous inner class");
            }
         };

   }
   private static class Parentclass
   {
	   Parentclass(){
		   System.out.println("Constructor of Superclass");
	   }
   }
}

abstract class AnonymousInner {
	   public abstract void mymethod();
}
