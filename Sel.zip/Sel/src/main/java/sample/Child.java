package sample;

public class Child extends Parent {
	int a = 10;
	public Child()
    {
		super(0);
        System.out.println(2);
    }

	public void staticMethod(){
		System.out.println(a);
	     System.out.println("Inside Child static");
	   }
	}