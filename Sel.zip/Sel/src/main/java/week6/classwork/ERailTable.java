package week6.classwork;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
class Dummy{
    private void foo(){
        System.out.println("hello foo()");
    }
}

class Test{
    public static void main(String[] args) throws Exception {
    }
}
public class ERailTable {

	public static void main(String[] args) throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		Dummy d = new Dummy();
        Method m = Dummy.class.getDeclaredMethod("foo");
        //m.invoke(d);// throws java.lang.IllegalAccessException
        m.setAccessible(true);// Abracadabra 
        m.invoke(d);// now its OK
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://erail.in");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		driver.findElementById("txtStationFrom").clear();
		driver.findElementById("txtStationFrom").sendKeys("MS", Keys.TAB);

		driver.findElementById("txtStationTo").clear();
		driver.findElementById("txtStationTo").sendKeys("RMM", Keys.TAB);

		WebElement table = driver.findElementByXPath("//table[@class='DataTable TrainList']");

		List<WebElement> rows = table.findElements(By.tagName("tr"));
		System.out.println(rows.size());
		
		WebElement firstRow = rows.get(0);
		List<WebElement> columns = firstRow.findElements(By.tagName("td"));
		System.out.println(columns.size());
		
		WebElement secondRow = rows.get(1);
		
		List<WebElement> all = secondRow.findElements(By.tagName("td"));
		
		System.out.println(all.get(1).getText());
		
//		List<Integer> trainNoList = new ArrayList<Integer>();
		for (WebElement row : rows) {
			int trainNo = Integer.parseInt(columns.get(0).getText());
		//	trainNoList.add(trainNo);
		}
		

	}

}
