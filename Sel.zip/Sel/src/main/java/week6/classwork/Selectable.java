package week6.classwork;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

@Test
public class Selectable {
	public void actionPerform(){
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://jqueryui.com/selectable/");
		driver.manage().window().maximize();
		driver.switchTo().frame(driver.findElementByClassName("demo-frame"));
		Actions builder = new Actions(driver);
		WebElement item2 = driver.findElementByXPath("//li[text()='Item 2']");
		//System.out.println(draggable.getLocation());
		WebElement item3 = driver.findElementByXPath("//li[text()='Item 3']");
		//System.out.println(droppable.getLocation());
		//builder.dragAndDrop(draggable, droppable)
		builder.clickAndHold(item2)
		.clickAndHold(item3)
		.release()
		.perform();
	}
}
