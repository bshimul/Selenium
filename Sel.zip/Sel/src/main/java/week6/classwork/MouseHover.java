package week6.classwork;

import java.time.Duration;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

@Test
public class MouseHover {
	public void actionPerform(){
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://www.flipkart.com/");
		driver.manage().window().maximize();
		WebElement applicances = driver.findElementByXPath("//span[text()='Appliances']");
		Actions builder = new Actions(driver);
		builder.moveToElement(applicances).perform();
		builder.pause(Duration.ofSeconds(5));
		WebElement singleDoor = driver.findElementByXPath("//span[text()='Single Door']");
		builder.click(singleDoor)
		//.build()
		.perform();
	}
}
