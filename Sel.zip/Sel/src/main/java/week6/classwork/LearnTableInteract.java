package week6.classwork;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LearnTableInteract {
	
	public static void main(String []args){
		
		//driver initialize
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		
		//URL launch
		driver.get("http://testleaf.herokuapp.com/pages/table.html");
		driver.manage().window().maximize();
		
		//find the table
		WebElement table = driver.findElementByXPath("//table[@cellspacing='0']");
		
		//find the rows
		List<WebElement> rows = table.findElements(By.tagName("tr"));
		
		String progressPercent = null;
		int progressValue = 0;
		List<Integer> myList = new 	ArrayList<Integer>();
		
		for(int i=1;i<rows.size();i++)
		{
			WebElement row =  rows.get(i); //row 1 to 3
			List<WebElement> column  = row.findElements(By.tagName("td")); //get table data in each row
			
			for (int j=1;j<column.size()-1;j++)
			{
				//get the value in column 2
				//remove %
				//convert String to integer
				
				progressPercent = column.get(j).getText().replace("%", "");								
				
				progressValue = Integer.parseInt(progressPercent);
				
				myList.add(progressValue);
			}
						
		}
		
		System.out.println("The Progress list is: "+myList);
		
		Object obj = Collections.min(myList); // Using the Collections class find minimum of my List
		
		System.out.println(obj);
		
		//finding the index of minimum progress
		int index = myList.indexOf(obj);
		
		
		//increment the index by 1 to find xpath of check box as xpath starts with 1
		index = index + 1;
		
		//finding the checkbox using xpath
		WebElement vitalTask = driver.findElementByXPath("(//input[@type='checkbox'])["+index+"]");
		
		//clicking the checkbox
		vitalTask.click();
	}

}
