package week4.classwork;

import org.testng.annotations.Test;

public class DependsOn {
	
	@Test(dependsOnMethods={"createLead"})
	public void editLead(){
		System.out.println("Edit Lead");
	}
	
	@Test(priority=0)
	public void createLead(){
		System.out.println("Create Lead");
	}
	
	@Test(priority=0)
	public void delLead(){
		System.out.println("del Lead");
	}
	
	@Test(priority=1)
	public void test1112(){
		System.out.println("Test 2");
	}
	
	@Test(priority=1)
	public void test001(){
		System.out.println("Test 1");
	}
	
	
	@Test(priority=-1)
	public void priorityNegative(){
		System.out.println("Negative Priority");
	}
	

}
