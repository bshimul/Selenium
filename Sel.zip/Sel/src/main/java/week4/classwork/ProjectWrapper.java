package week4.classwork;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import wrappers.GenericWrappers;

public class ProjectWrapper extends GenericWrappers {
	@Parameters({ "url", "uName", "pwd" })
	@BeforeMethod(groups = { "common" })
	public void loginToLeafTaps(String url, String uName, String pwd) {
		invokeApp("chrome", url); // launching URL
		enterById("username", uName); // entering user id
		enterById("password", pwd); // entering password
		clickByClassName("decorativeSubmit"); // clicking Login
		clickByLinkNoSnap("CRM/SFA"); // click CRM/SFA link
	}

	@AfterMethod(groups = "common")
	public void close() {
		closeBrowser(); // closing browser
	}

	@DataProvider(name="fetchData")
	public static String[][] getData(){
		String[][] testData = new String[2][3];
		
		testData[0][0]="Google";
		testData[0][1]="firstName";
		testData[0][2]="lastName";
		
		testData[1][0]="Google2";
		testData[1][1]="firstName2";
		testData[1][2]="lastName2";
		
		return testData;
		
	}

}
