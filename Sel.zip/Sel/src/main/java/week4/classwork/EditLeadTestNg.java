package week4.classwork;

import org.testng.annotations.Test;

import wrappers.ProjectWrappers;

public class EditLeadTestNg extends ProjectWrappers {

	@Test
	public void editLead() throws InterruptedException {
		clickByLink("Leads"); //Clicking the Link 'Leads'
		clickByLink("Find Leads"); //Clicking the link 'Find Leads'
		enterByXpath("(//input[@name='firstName'])[3]","Sivakumar"); //Entering the first name
		clickByXpath("//button[contains(text(),'Find Leads')]"); //Clicking the button 'Find Leads'
		clickByXpath("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a"); //Clicking on the first resulting lead
		verifyTitle("View Lead | opentaps CRM"); //verifying the title of the window
		clickByLink("Edit"); //clicking the 'Edit' link
		enterById("updateLeadForm_companyName","Google"); //updating the new Company name
		clickByXpath("//input[@value='Update']"); //clicking the Update button
		verifyTextContainsById("viewLead_companyName_sp","Google"); 
	}

}
