package week4.classwork;

import org.testng.annotations.Test;

public class BDependsOnMet2 {
	
	@Test
	public void editLead(){
		System.out.println("BBBBBEdit Lead");
	}
	
	@Test
	public void createLead(){
		System.out.println("BBBBBCreate Lead");
	}
	
	@Test
	public void delLead(){
		System.out.println("BBBBBdel Lead");
	}
	
	@Test
	public void test1112(){
		System.out.println("BBBBBTest 11112");
	}
	
	@Test
	public void test001(){
		System.out.println("BBBBBTest 001");
	}
	
	
	@Test
	public void priorityNegative(){
		System.out.println("BBBBBNegative Priority");
	}
	

}
