package week4.classwork;

import org.testng.annotations.DataProvider;

public class DataProvdrNew {
	
	@DataProvider(name="fetchData", parallel=true)
	public static String[][] getData(){
		String[][] testData = new String[2][3];
		
		testData[0][0]="Google";
		testData[0][1]="firstName";
		testData[0][2]="lastName";
		
		testData[1][0]="Google2";
		testData[1][1]="firstName2";
		testData[1][2]="lastName2";
		
		return testData;
		
	}
	
	@DataProvider(name="fetchData11")
	public static String[][] getData11(){
		String[][] testData = new String[2][3];
		
		testData[0][0]="Google";
		testData[0][1]="firstName";
		testData[0][2]="lastName";
		
		testData[1][0]="Google2";
		testData[1][1]="firstName2";
		testData[1][2]="lastName2";
		
		return testData;
		
	}

}
