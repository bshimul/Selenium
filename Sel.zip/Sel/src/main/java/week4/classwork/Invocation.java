package week4.classwork;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Invocation {

	@Test(invocationCount=2,threadPoolSize=3)
	public static void main() {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver=new ChromeDriver();
		driver.get("http://www.leaftaps.com/control/main");
		driver.manage().window().maximize();		
		driver.findElementById("username").sendKeys("DemoSalesManager");
		driver.findElementById("password").sendKeys("crmsfa");
		driver.findElementByClassName("decorativeSubmit").click();
		driver.findElementByLinkText("CRM/SFA").click();
		driver.findElementByLinkText("Create Lead").click();
		driver.findElementById("createLeadForm_firstName").sendKeys("Rajesh");
		driver.findElementById("createLeadForm_lastName").sendKeys("Jayaraman");	
		driver.findElementById("createLeadForm_companyName").sendKeys("Google");
		driver.findElementByName("submitButton").click();
		driver.close();
	}
}
