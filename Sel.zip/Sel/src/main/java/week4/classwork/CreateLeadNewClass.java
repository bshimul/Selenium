package week4.classwork;

import org.testng.annotations.Test;

import wrappers.ProjectWrappers;

//class A extends class B
public class CreateLeadNewClass extends ProjectWrappers{
	
@Test(dataProvider="fetchData",dataProviderClass=DataProvdrNew.class)
	
	public void createLead(String cName,String fName, String lName) throws InterruptedException {
		
	/*	loginToLeafTaps(); */
		
		clickByLink("Create Lead"); // click create lead
		
		 //enter the company name
		enterById("createLeadForm_companyName", cName);
		
		//Enter First Name
		enterById("createLeadForm_firstName", fName);

		//Enter Last Name
		enterById("createLeadForm_lastName", lName);	

		//clicking the create lead button
		clickByName("submitButton");
		
		//Thread.sleep(2000);
		
		/*//closing the browser
		closeBrowser();*/
		
	}
}