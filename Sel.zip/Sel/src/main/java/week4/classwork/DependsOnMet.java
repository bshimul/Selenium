package week4.classwork;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class DependsOnMet {
	@BeforeMethod
	public void met1(){
		System.out.println(11);
	}
	@BeforeMethod
	public void met(){
		System.out.println("tro");
	}
	@Test
	public void editLead(){
		System.out.println("DDDDDEdit Lead");
	}
	
	@Test
	public void createLead() throws AWTException{
		System.out.println("DDDDDCreate Lead");
		Robot r = new Robot();
		r.keyPress(KeyEvent.VK_ENTER);
	}
	
	@Test
	public void delLead(){
		System.out.println("DDDDDdel Lead");
	}
	
	@Test
	public void test1112(){
		System.out.println("DDDDDTest 11112");
	}
	
	@Test
	public void test001(){
		System.out.println("DDDDDTest 001");
	}
	
	
	@Test
	public void priorityNegative(){
		System.out.println("DDDDDNegative Priority");
	}
	@AfterMethod
	public void met3(){
		System.out.println("after 3");
	}
	@AfterMethod
	public void met2(){
		System.out.println("after 2");
	}
}
