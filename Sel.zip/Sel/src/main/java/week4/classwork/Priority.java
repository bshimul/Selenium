package week4.classwork;

import org.testng.annotations.Test;

public class Priority {
	@Test(priority=1)
	public void priority1(){
		System.out.println("Priority 1");
	}
	
	
	@Test(priority=2)
	public void priority2(){
		System.out.println("Priority 2");
	}
	
	@Test(priority=0)
	public void priority0(){
		System.out.println("Priority 0");
	}
	
	
	@Test(priority=-999999)
	public void priorityNegative(){
		System.out.println("Negative Priority");
	}
	

}
