package week4.classwork;

import org.testng.annotations.Test;

public class ADependsOnMet1 {
	
	@Test
	public void editLead(){
		System.out.println("AAAAAAAEdit Lead");
	}
	
	@Test
	public void createLead(){
		System.out.println("AAAAAAACreate Lead");
	}
	
	@Test
	public void delLead(){
		System.out.println("AAAAAAAdel Lead");
	}
	
	@Test
	public void test1112(){
		System.out.println("AAAAAAATest 11112");
	}
	
	@Test
	public void test001(){
		System.out.println("AAAAAAATest 001");
	}
	
	
	@Test
	public void priorityNegative(){
		System.out.println("AAAAAAANegative Priority");
	}
	

}
