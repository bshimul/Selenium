package week4.homework;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


public class CreateLeadTestNg extends Week4ProjectWrappers{
	@Test(dataProvider="createLeadData")
	public void createLead(String cName,String fName, String lName) throws InterruptedException {
		clickByLink("Create Lead");
		enterById("createLeadForm_companyName", cName);
		enterById("createLeadForm_firstName", fName);
		enterById("createLeadForm_lastName", lName);	
		selectVisibileTextById("createLeadForm_dataSourceId", "Partner");
		selectIndexById("createLeadForm_marketingCampaignId",3);
		enterById("createLeadForm_primaryPhoneNumber", "12345678");
		enterById("createLeadForm_primaryEmail", "devaki.gg@gmail.com");
		clickByName("submitButton");
	}
	
	@DataProvider(name="createLeadData", parallel=true)
	public static String[][] getData(){
		String[][] testData = new String[4][3];
		
		testData[0][0]="Google";
		testData[0][1]="firstName";
		testData[0][2]="lastName";
		testData[1][0]="Google111";
		testData[1][1]="firstName1111111";
		testData[1][2]="lastName1111111";
		testData[2][0]="Google222222";
		testData[2][1]="firstName2222222";
		testData[2][2]="lastName222222";
		testData[3][0]="Google3333333";
		testData[3][1]="firstName33333";
		testData[3][2]="lastName33333333";
		return testData;
		
	}
}