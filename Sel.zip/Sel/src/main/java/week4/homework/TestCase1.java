package week4.homework;

import org.testng.annotations.Test;

public class TestCase1 {
	@Test
	public void testCase1() {
		System.out.print("Test Case 1 is run - using Thread ID - ");
		System.out.println(Thread.currentThread().getId());
	}
}
