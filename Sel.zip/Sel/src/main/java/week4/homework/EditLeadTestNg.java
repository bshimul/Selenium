package week4.homework;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class EditLeadTestNg extends Week4ProjectWrappers {

	@Test(dataProvider="editLeadData")
	public void editLead(String fName, String title, String cName) throws InterruptedException {
		clickByLink("Leads"); //Clicking the Link 'Leads'
		clickByLink("Find Leads"); //Clicking the link 'Find Leads'
		enterByXpath("(//input[@name='firstName'])[3]", fName); //Entering the first name
		clickByXpath("//button[contains(text(),'Find Leads')]"); //Clicking the button 'Find Leads'
		clickByXpath("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a"); //Clicking on the first resulting lead
		verifyTitle(title); //verifying the title of the window
		clickByLink("Edit"); //clicking the 'Edit' link
		enterById("updateLeadForm_companyName", cName); //updating the new Company name
		clickByXpath("//input[@value='Update']"); //clicking the Update button
		verifyTextContainsById("viewLead_companyName_sp",cName); 
	}
	
	@DataProvider(name="editLeadData")
	public static String[][] getData(){
		String[][] testData = new String[1][3];
		
		testData[0][0]="M";
		testData[0][1]="View Lead | opentaps CRM";
		testData[0][2]="Google";
		return testData;
		
	}

}
