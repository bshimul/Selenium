package week4.homework;

import org.testng.annotations.Test;

public class GroupsImplementation {
	@Test(groups={"s."})
	public void testCase1() {
		System.out.println("Test Case 1 - smoke is run");
	}
	
	@Test(groups={"rmoke"})
	public void testCase2() {
		System.out.println("Test Case 2 - smoke is run");
	}
	
	@Test(groups={"sanity"}, dependsOnGroups={"s."})
	public void testCase3() {
		System.out.println("Test Case 3 - sanity is run");
	}
	
	@Test(groups={"sanity"}, dependsOnGroups={"rmoke"})
	public void testCase4() {
		System.out.println("Test Case 4 - sanity is run");
	}
	@Test(groups={"sanity"})
	public void testCase5() {
		System.out.println("Test Case 5555 - sanity is run");
	}
	@Test
	public void testCase64() {
		System.out.println("Test Case 666666 - sanity is run");
	}
}
