package week4.homework;

import org.testng.annotations.Test;

public class TestCase4 {
	@Test
	public void testCase4() {
		System.out.print("Test Case 4 is run - using Thread ID - ");
		System.out.println(Thread.currentThread().getId());
	}
}
