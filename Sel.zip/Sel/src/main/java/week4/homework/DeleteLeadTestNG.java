package week4.homework;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class DeleteLeadTestNG extends Week4ProjectWrappers {

	@Test(dataProvider="deleteLeadData")
	public void deleteLead(String pNum1, String pNum2, String pNum3) throws InterruptedException {
		clickByLink("Leads");
		clickByLink("Find Leads");
		clickByXpath("//span[text()='Phone']");
		enterByName("phoneCountryCode", pNum1);
		enterByName("phoneAreaCode", pNum2);
		enterByName("phoneNumber", pNum3);
		clickByXpath("//button[text()='Find Leads']");
		Thread.sleep(5000);
		String leadIdText = getTextByXpath("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a");
		clickByXpath("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a");
		clickByLink("Delete");
		clickByLink("Find Leads");
		enterByXpath("//input[@name='id']", leadIdText);
		clickByXpath("//button[text()='Find Leads']");
		verifyTextByXpath("//div[@class='x-paging-info']", "No records to display");
	}
	
	@DataProvider(name="deleteLeadData")
	public static String[][] getData(){
		String[][] testData = new String[1][3];
		
		testData[0][0]="2";
		testData[0][1]="24";
		testData[0][2]="81323928392";
		
		return testData;
		
	}
}
