package week4.homework;

import org.testng.annotations.Test;

public class TestCase2 {
	@Test
	public void testCase2() {
		System.out.print("Test Case 2 is run - using Thread ID - ");
		System.out.println(Thread.currentThread().getId());
	}
}
