package week4.homework;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


public class DuplicateLeadsTestNG extends Week4ProjectWrappers {
	@Test(dataProvider="duplicateLeadData")
	public void dupLead(String email) throws InterruptedException {
		clickByLink("Leads");
		clickByLink("Find Leads");
		clickByXpath("//span[contains(text(),'Email')]");//E Mail
		enterByName("emailAddress", email);
		clickByXpath("//button[text()='Find Leads']"); //Find Leads
		Thread.sleep(5000);
		String firstName = getTextByXpath("(//*[@class='x-grid3-cell-inner x-grid3-col-firstName'])[1]"); //Name of first resulting lead
		clickByXpath("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a");//click first resulting lead
		clickByLink("Duplicate Lead");
		verifyTitle("Duplicate Lead");
		clickByName("submitButton");
		verifyTextById("viewLead_firstName_sp", firstName);
	}
	
	@DataProvider(name="duplicateLeadData")
	public static String[][] getData(){
		String[][] testData = new String[1][1];
		
		testData[0][0]="a@a.com";
		
		return testData;
		
	}
}
