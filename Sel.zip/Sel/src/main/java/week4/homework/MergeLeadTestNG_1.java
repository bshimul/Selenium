package week4.homework;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class MergeLeadTestNG_1 extends Week4ProjectWrappers {
	//annotate Test mentioned as there is no main method
		@Test(dataProvider="mergeLeadData", enabled=false)
		public void mergeLead(String lead1, String lead2) throws InterruptedException {
			
			clickByLinkNoSnap("Leads"); //click Leads
			clickByLinkNoSnap("Merge Leads"); //click Merge leads
			clickByXpathNoSnap("(//img[@alt='Lookup'])[1]"); //click icon near 'From Lead' field
			switchToLastWindow();//switch to new window			
			enterByXpath("//label[contains(text(),'Lead ID:')]/following::input", lead1);//Enter From Lead id
			clickByXpathNoSnap("//button[contains(text(),'Find Leads')]");//clicking Find leads button
			clickByXpathNoSnap("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a");//clicking on the first resulting lead
			
			switchToParentWindow();//switch back to primary window
			
			clickByXpathNoSnap("(//img[@alt='Lookup'])[2]");//click icon near 'To Lead' field
			
			switchToLastWindow();//switch to new window
			enterByXpath("//label[contains(text(),'Lead ID:')]/following::input", lead2);//Enter To Lead id
			clickByXpathNoSnap("//button[contains(text(),'Find Leads')]");//clicking Find leads button
			clickByXpathNoSnap("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a");//clicking on the first resulting lead
			
			switchToParentWindow();//switch back to primary window
			
			clickByLinkNoSnap("Merge"); //Click Merge
			Thread.sleep(3000);
			acceptAlert(); //Accept the alert
			clickByLinkNoSnap("Find Leads"); //Click Find Leads
			enterByXpath("//label[contains(text(),'Lead ID:')]/following::input", lead1); //Enter the Lead id to check if it is found
			clickByXpathNoSnap("//button[contains(text(),'Find Leads')]"); //Click Find Leads to check if the merged Lead id is found
			Thread.sleep(3000);
			getTextByXpath("//div[contains(text(),'No records to display')]");
			/*closeBrowser();	//Close the browser. Do not Logout*/
		}
		
		@DataProvider(name="mergeLeadData")
		public static String[][] getData(){
			String[][] testData = new String[1][2];
			
			testData[0][0]="12896";
			testData[0][1]="12897";
			return testData;
			
		}
}