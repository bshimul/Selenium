package week4.homework;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.security.UserAndPassword;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.UnexpectedTagNameException;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;

import wrappers.Wrappers;

public class GenericWrappers implements Wrappers {
	public static RemoteWebDriver driver;
	public RemoteWebDriver driver1;
	public static RemoteWebDriver driver2;
	public static RemoteWebDriver driver3;
	public static RemoteWebDriver driver4;
	
	public HashMap<Long, RemoteWebDriver> m = new HashMap<Long, RemoteWebDriver>();
	int i =1;
	
	public RemoteWebDriver currentDriver()  {
		RemoteWebDriver curDriver = null;
		try {
			long bar = Thread.currentThread().getId();
			curDriver = (RemoteWebDriver) m.get(bar);
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (SecurityException e) {
			e.printStackTrace();
		}
		return curDriver;
	}
	
	public synchronized void invokeApp(String browser, String url) {
		try {
			if(browser.equalsIgnoreCase("chrome")){
				System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
				if (driver == null) {
					driver = new ChromeDriver();
					driver.get(url); // enter url 
					driver.manage().window().maximize();
					driver.manage().timeouts().implicitlyWait(15,TimeUnit.SECONDS);
					System.out.println("PASS:::::The Browser "+browser+" launched successfully");
					m.put(Thread.currentThread().getId(), driver);
				} else if (driver1==null) {
					driver1 = new ChromeDriver();
					driver1.get(url); // enter url 
					driver1.manage().window().maximize();
					driver1.manage().timeouts().implicitlyWait(15,TimeUnit.SECONDS);
					System.out.println("PASS:::::The Browser "+browser+" launched successfully");
					m.put(Thread.currentThread().getId(), driver1);
				} else if (driver2==null) {
					driver2 = new ChromeDriver();
					driver2.get(url); // enter url 
					driver2.manage().window().maximize();
					driver2.manage().timeouts().implicitlyWait(15,TimeUnit.SECONDS);
					System.out.println("PASS:::::The Browser "+browser+" launched successfully");
					m.put(Thread.currentThread().getId(), driver2);
				} else if (driver3==null) {
					driver3 = new ChromeDriver();
					driver3.get(url); // enter url 
					driver3.manage().window().maximize();
					driver3.manage().timeouts().implicitlyWait(15,TimeUnit.SECONDS);
					System.out.println("PASS:::::The Browser "+browser+" launched successfully");
					m.put(Thread.currentThread().getId(), driver3);
				} else if (driver4==null) {
					driver4 = new ChromeDriver();
					driver4.get(url); // enter url 
					driver4.manage().window().maximize();
					driver4.manage().timeouts().implicitlyWait(15,TimeUnit.SECONDS);
					System.out.println("PASS:::::The Browser "+browser+" launched successfully");
					m.put(Thread.currentThread().getId(), driver4);
				}
			}else if(browser.equalsIgnoreCase("firefox")){
				System.setProperty("webdriver.gecko.driver", "./drivers/geckodriver.exe");
				ProfilesIni prof = new ProfilesIni();//FireFox		
				FirefoxProfile ffProfile= prof.getProfile ("myProfile");
				ffProfile.setAcceptUntrustedCertificates(true) ;
				ffProfile.setAssumeUntrustedCertificateIssuer(false);
				
				DesiredCapabilities handlSSLErr = DesiredCapabilities.chrome ();//chrome      
				handlSSLErr.setCapability (CapabilityType.ACCEPT_SSL_CERTS, true);
				
				
				driver.navigate().to("javascript:document.getElementById('overridelink').click()");//IE Option 1
				DesiredCapabilities capabilities = new DesiredCapabilities();//IE Option 2
				capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
				
				driver = new ChromeDriver (handlSSLErr);
				driver = new FirefoxDriver(); // launch browser	
			}		
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::The Browser "+browser+" did not launch.");
			e.printStackTrace();
			throw new RuntimeException();
		} catch (Exception e) {
			System.err.println("FAIL:::::The Browser "+browser+" did not launch. There was a Exception.");
			e.printStackTrace();
			throw new RuntimeException();
		}
	}

	public void enterById(String idValue, String data) {
		try {
			/*WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.ignoring(RuntimeException.class, NullPointerException.class);
			wait.ignoring(TimeoutException.class);
			Alert alert = wait.until(ExpectedConditions.alertIsPresent());
			Actions a = new Actions(driver);
			
			alert.authenticateUsing(new UserAndPassword("", ""));
			//RemoteWebDriver driver = currentDriver();*/
			driver.findElementById(idValue).clear();
			driver.findElementById(idValue).sendKeys(data);
			this.driver1 = driver;
			System.out.println("PASS:::::The Text field "+idValue+ " is entered with text "+data);
		} catch (NoSuchElementException e) {
			System.err.println("FAIL:::::The Text field "+idValue+ " was not found");
			e.printStackTrace();
			throw new RuntimeException();
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred-->The Text field "+idValue+ " is not entered with text "+data);
			e.printStackTrace();
			throw new RuntimeException();
		} finally {
			takeSnap();
		}
	}

	public void enterByName(String nameValue, String data) {
		try {
			//RemoteWebDriver driver = currentDriver();
			driver.findElementByName(nameValue).clear();
			driver.findElementByName(nameValue).sendKeys(data);
			System.out.println("PASS:::::The Text field with name "+nameValue+ " is entered with text "+data);
		} catch (NoSuchElementException e) {
			System.err.println("FAIL:::::The Text field with name "+nameValue+ " was not found");
			e.printStackTrace();
			throw new RuntimeException();
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred-->The Text field with name "+nameValue+ " is not entered with text "+data);
			e.printStackTrace();
			throw new RuntimeException();
		} finally {
			takeSnap();
		}
	}

	public void enterByXpath(String xpathValue, String data) {
		try {
			driver.findElementByXPath(xpathValue).clear();
			driver.findElementByXPath(xpathValue).sendKeys(data, org.openqa.selenium.Keys.ENTER);
			System.out.println("PASS:::::The Text field with XPath "+xpathValue+ " is entered with text "+data);
		} catch (NoSuchElementException e) {
			System.err.println("FAIL:::::The Text field with XPath "+xpathValue+ " was not found");
			e.printStackTrace();
			throw new RuntimeException();
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred-->The Text field with XPath "+xpathValue+ " is not entered with text "+data);
			e.printStackTrace();
			throw new RuntimeException();
		} finally {
			takeSnap();
		}
	}

	public void verifyTitle(String title) {
		try {
			String pageTitle = driver.getTitle();
			if(title.equals(pageTitle)){
				System.out.println("PASS:::::"+title +" matches with the title of the web page "+pageTitle);
			} else {
				System.out.println("FAIL:::::"+title +" does not match with the title of the web page "+pageTitle);
			}
		} catch (WebDriverException e) {
			System.err.println("FAIL::::: Unknown Exception has occurred");
			e.printStackTrace();
			throw new RuntimeException();
		} finally {
			takeSnap();
		}
	}

	public void verifyTextById(String id, String text) {
		try {
			String webElementText = driver.findElementById(id).getText();
			if(text.equals(webElementText)){
				System.out.println("PASS:::::"+text +" matches with the text of the webelement ("+webElementText+") with id "+id);
			} else {
				System.out.println("FAIL:::::"+text +" does not match with the text of the webelement ("+webElementText+") with id "+id);
			}
		} catch (NoSuchElementException e) {
			System.err.println("FAIL:::::The WebElement with id "+id+ " was not found");
			e.printStackTrace();
			throw new RuntimeException();
		} catch (WebDriverException e) {
			System.err.println("FAIL::::: Unknown Exception has occurred");
			e.printStackTrace();
			throw new RuntimeException();
		} finally {
			takeSnap();
		}
	}

	public void verifyTextContainsById(String id, String text) {
		try {
			String webElementText = driver.findElementById(id).getText();
			if(webElementText.contains(text)){
				System.out.println("PASS:::::"+text +" is present in the text of the webelement ("+webElementText+") with id "+id);
			} else {
				System.out.println("FAIL:::::"+text +" is not present in the text of the webelement ("+webElementText+") with id "+id);
			}
		} catch (NoSuchElementException e) {
			System.err.println("FAIL:::::The WebElement with id "+id+ " was not found");
			e.printStackTrace();
			throw new RuntimeException();
		} catch (WebDriverException e) {
			System.err.println("FAIL::::: Unknown Exception has occurred");
			e.printStackTrace();
			throw new RuntimeException();
		} finally {
			takeSnap();
		}
	}

	public void verifyTextByXpath(String xpath, String text) {
		try {
			String webElementText = driver.findElementByXPath(xpath).getText();
			if(text.equals(webElementText)){
				System.out.println("PASS:::::"+text +" matches with the text of the webelement ("+webElementText+") with xpath "+xpath);
			} else {
				System.out.println("FAIL:::::"+text +" does not match with the text of the webelement ("+webElementText+") with xpath "+xpath);
			}
		} catch (NoSuchElementException e) {
			System.err.println("FAIL:::::The WebElement with xpath "+xpath+ " was not found");
			e.printStackTrace();
			throw new RuntimeException();
		} catch (WebDriverException e) {
			System.err.println("FAIL::::: Unknown Exception has occurred");
			e.printStackTrace();
			throw new RuntimeException();
		} finally {
			takeSnap();
		}
	}

	public void verifyTextContainsByXpath(String xpath, String text) {
		try {
			String webElementText = driver.findElementByXPath(xpath).getText();
			if(webElementText.contains(text)){
				System.out.println("PASS:::::"+text +" is present in the text of the webelement("+webElementText+") with xpath "+xpath);
			} else {
				System.out.println("FAIL:::::"+text +" is not present in the text of the webelement("+webElementText+") with xpath "+xpath);
			}
		} catch (NoSuchElementException e) {
			System.err.println("FAIL:::::The WebElement with xpath "+xpath+ " was not found");
			e.printStackTrace();
			throw new RuntimeException();
		} catch (WebDriverException e) {
			System.err.println("FAIL::::: Unknown Exception has occurred");
			e.printStackTrace();
			throw new RuntimeException();
		} finally {
			takeSnap();
		}
	}

	public void clickById(String id) {
		try {
			driver.findElementById(id).click();
			System.out.println("PASS:::::The Webelement with id "+id+ " is clicked");
		} catch (NoSuchElementException e) {
			System.err.println("FAIL:::::The Webelement with id "+id+ " is not found");
			e.printStackTrace();
			throw new RuntimeException();
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred");
			e.printStackTrace();
			throw new RuntimeException();
		} finally {
			takeSnap();
		}
	}

	public void clickByClassName(String classVal) {
		try {
			//RemoteWebDriver driver = currentDriver();
			driver.findElementByClassName(classVal).click();
			System.out.println("PASS:::::The Webelement with Class Name "+classVal+ " is clicked");
		} catch (NoSuchElementException e) {
			System.err.println("FAIL:::::The Webelement with Class Name "+classVal+ " is not found");
			e.printStackTrace();
			throw new RuntimeException();
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred");
			e.printStackTrace();
			throw new RuntimeException();
		} finally {
			takeSnap();
		}
	}

	public void clickByName(String name) {
		try {
			//RemoteWebDriver driver = currentDriver();
			driver.findElementByName(name).click();
			System.out.println("PASS:::::The Webelement with Name "+name+" is clicked");
		} catch (NoSuchElementException e) {
			System.err.println("FAIL:::::The Webelement with Name "+name+ " is not found");
			e.printStackTrace();
			throw new RuntimeException();
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred");
			e.printStackTrace();
			throw new RuntimeException();
		} finally {
			takeSnap();
		}
	}

	public void clickByLink(String name) {
		try {
			//RemoteWebDriver driver = currentDriver();
			driver.findElementByLinkText(name).click();
			System.out.println("PASS:::::The Webelement with Link Text "+name+" is clicked");
		} catch (NoSuchElementException e) {
			System.err.println("FAIL:::::The Webelement with Link Text "+name+" is not found");
			e.printStackTrace();
			throw new RuntimeException();
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred");
			e.printStackTrace();
			throw new RuntimeException();
		} finally {
			takeSnap();
		}
	}

	public void clickByLinkNoSnap(String name) {
		try {
			//RemoteWebDriver driver = currentDriver();
			driver.findElementByLinkText(name).click();
			System.out.println("PASS:::::The Webelement with Link Text " +name+ " is clicked");
		} catch (NoSuchElementException e) {
			System.err.println("FAIL:::::The Webelement with Link Text "+name+" is not found");
			e.printStackTrace();
			throw new RuntimeException();
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred");
			e.printStackTrace();
			throw new RuntimeException();
		}
	}

	public void clickByXpath(String xpathVal) {
		try {
			//RemoteWebDriver driver = currentDriver();
			driver.findElementByXPath(xpathVal).click();
			System.out.println("PASS:::::The Webelement with xpath "+xpathVal+" is clicked");
		} catch (NoSuchElementException e) {
			System.err.println("FAIL:::::The Webelement with xpath "+xpathVal+" is not found");
			e.printStackTrace();
			throw new RuntimeException();
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred");
			e.printStackTrace();
			throw new RuntimeException();
		} finally {
			takeSnap();
		}
	}

	public void clickByXpathNoSnap(String xpathVal) {
		try {
			//RemoteWebDriver driver = currentDriver();
			driver.findElementByXPath(xpathVal).click();
			System.out.println("PASS:::::The Webelement with xpath "+xpathVal+" is clicked");
		} catch (NoSuchElementException e) {
			System.err.println("FAIL:::::The Webelement with xpath "+xpathVal+" is not found");
			e.printStackTrace();
			throw new RuntimeException();
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred");
			e.printStackTrace();
			throw new RuntimeException();
		}
	}

	public String getTextById(String idVal) {
		try {
			//RemoteWebDriver driver = currentDriver();
			String idText = driver.findElementById(idVal).getText();
			System.out.println("PASS:::::The Webelement with id "+idVal+" has text as "+idText);
			return idText;
		} catch (NoSuchElementException e) {
			System.err.println("FAIL:::::The Webelement with id "+idVal+" is not found");
			e.printStackTrace();
			throw new RuntimeException();
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred");
			e.printStackTrace();
			throw new RuntimeException();
		} finally {
			takeSnap();
		}
	}

	public String getTextByXpath(String xpathVal) {
		try {
			//RemoteWebDriver driver = currentDriver();
			String xpathText = driver.findElementByXPath(xpathVal).getText();
			System.out.println("PASS:::::The Webelement with xpath "+xpathVal+" has text as "+xpathText);
			return xpathText;
		} catch (NoSuchElementException e) {
			System.err.println("FAIL:::::The Webelement with xpath "+xpathVal+" is not found");
			e.printStackTrace();
			throw new RuntimeException();
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred");
			e.printStackTrace();
			throw new RuntimeException();
		} finally {
			takeSnap();
		}
	}

	public void selectVisibileTextById(String id, String value) {
		try {
			//RemoteWebDriver driver = currentDriver();
			WebElement element = driver.findElementById(id);
			Select src = new Select(element);
			src.selectByVisibleText(value);
			System.out.println("PASS:::::"+value +" is select from dropdown webelement with id "+id);
		} catch (NoSuchElementException e) {
			System.err.println("FAIL:::::The Webelement with id "+id+" is not found/The Webelement with visible text "+value+" is not found");
			e.printStackTrace();
			throw new RuntimeException();
		} catch (UnexpectedTagNameException e) {
			System.err.println("FAIL:::::The Webelement with id "+id+" is not a dropdown field to select a item");
			e.printStackTrace();
			throw new RuntimeException();
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred");
			e.printStackTrace();
			throw new RuntimeException();
		} finally {
			takeSnap();
		}
	}

	public void selectIndexById(String id, int value) {
		try {
			//RemoteWebDriver driver = currentDriver();
			WebElement element = driver.findElementById(id);
			Select src = new Select(element);
			src.selectByIndex(value);
			System.out.println("PASS:::::Item no "+value+" is selected from dropdown webelement with id "+id);
		} catch (NoSuchElementException e) {
			System.err.println("FAIL:::::The Webelement with id "+id+" is not found/The Webelement with index "+value+" is not found");
			e.printStackTrace();
			throw new RuntimeException();
		} catch (UnexpectedTagNameException e) {
			System.err.println("FAIL:::::The Webelement with id "+id+" is not a dropdown field to select a item");
			e.printStackTrace();
			throw new RuntimeException();
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred");
			e.printStackTrace();
			throw new RuntimeException();
		} finally {
			takeSnap();
		}
	}

	public void selectValueById(String id, String value) {
		try {
			//RemoteWebDriver driver = currentDriver();
			WebElement element = driver.findElementById(id);
			Select src = new Select(element);
			src.selectByValue(value);
			System.out.println("PASS:::::Item with value "+value+" is selected from dropdown webelement with id "+id);
		} catch (NoSuchElementException e) {
			System.err.println("FAIL:::::The Webelement with id "+id+" is not found/The Webelement with index "+value+" is not found");
			e.printStackTrace();
			throw new RuntimeException();
		} catch (UnexpectedTagNameException e) {
			System.err.println("FAIL:::::The Webelement with id "+id+" is not a dropdown field to select a item");
			e.printStackTrace();
			throw new RuntimeException();
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred");
			e.printStackTrace();
			throw new RuntimeException();
		} finally {
			takeSnap();
		}
	}
	
	public void switchToParentWindow() {
		try {
			//RemoteWebDriver driver = currentDriver();
			Set<String> allWindowHandles = driver.getWindowHandles();
			for (String eachHandle : allWindowHandles) {
				driver.switchTo().window(eachHandle);
				break;
			}
			System.out.println("PASS:::::The control is switched to the parent window");
		} catch (NoSuchWindowException e) {
			System.err.println("FAIL:::::The window cannot be switced to ParentWindow");
			e.printStackTrace();
			throw new RuntimeException();
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred");
			e.printStackTrace();
			throw new RuntimeException();
		}
	}

	public void switchToLastWindow() {
		try {
			//RemoteWebDriver driver = currentDriver();
			Set<String> allWindowHandles = driver.getWindowHandles();
			//int windowCount = allWindowHandles.size();
			//int i = 0;
			for (String eachHandle : allWindowHandles) {
				driver.switchTo().window(eachHandle);
				//i++;
				//if (i==windowCount) break;
			}
			System.out.println("PASS:::::The control is switched to the last window");
		} catch (NoSuchWindowException e) {
			System.err.println("FAIL:::::The window cannot be switced to one of the Window Handle");
			e.printStackTrace();
			throw new RuntimeException();
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred");
			e.printStackTrace();
			throw new RuntimeException();
		}
	}

	public void switchToFrame(String frameIdorName) {
		try {
			//RemoteWebDriver driver = currentDriver();
			driver.switchTo().frame(frameIdorName);
			System.out.println("PASS:::::The Frame has been switced to "+frameIdorName);
		} catch (NoSuchFrameException e) {
			System.err.println("FAIL:::::The Frame cannot be switced to "+frameIdorName);
			e.printStackTrace();
			throw new RuntimeException();
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred");
			e.printStackTrace();
			throw new RuntimeException();
		}
	}
	
	public void acceptAlert() {
		try {
			//RemoteWebDriver driver = currentDriver();
			driver.switchTo().alert().accept();
			System.out.println("PASS:::::The Alert has been accepted with OK button");
		} catch (NoAlertPresentException e) {
			System.err.println("FAIL:::::There is no Alert present to accept");
			e.printStackTrace();
			throw new RuntimeException();
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred");
			e.printStackTrace();
			throw new RuntimeException();
		}
	}

	public void dismissAlert() {
		try {
			//RemoteWebDriver driver = currentDriver();
			driver.switchTo().alert().dismiss();
			System.out.println("PASS:::::The Alert has been dismissed with cancel button");
		} catch (NoAlertPresentException e) {
			System.err.println("FAIL:::::There is no Alert present to dismiss");
			e.printStackTrace();
			throw new RuntimeException();
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred");
			e.printStackTrace();
			throw new RuntimeException();
		}
	}

	public String getAlertText() {
		try {
			//RemoteWebDriver driver = currentDriver();
			String alertText = driver.switchTo().alert().getText();
			System.out.println("PASS:::::The Alert has the text "+alertText);
			return alertText;
		} catch (NoAlertPresentException e) {
			System.err.println("FAIL:::::There is no Alert present to get the Text");
			e.printStackTrace();
			throw new RuntimeException();
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred");
			e.printStackTrace();
			throw new RuntimeException();
		}
	}

	public long takeSnap() {
		try {
			////RemoteWebDriver driver = currentDriver();
			File src = driver.getScreenshotAs(OutputType.FILE);
			File dest = new File("./snaps/snap"+i+".jpg");
			i++;
			FileUtils.copyFile(src, dest);
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred while taking snap shot");
			e.printStackTrace();
			throw new RuntimeException();
		} catch (IOException e) {
			System.err.println("Unable to take snap shot");
			e.printStackTrace();
			throw new RuntimeException();
		}
		return 1;
	}
	
	
	
	public void closeBrowser() {
		try {
			//RemoteWebDriver driver = currentDriver();
			driver.close();
			System.out.println("PASS:::::The current active browser has been closed");
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred - Browser cannot be closed");
			e.printStackTrace();
			throw new RuntimeException();
		}
	}

	public void closeAllBrowsers() {
		try {
		driver.quit();
		System.out.println("PASS:::::All the current active browsers have been closed");
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred - Browser cannot be quitted");
			e.printStackTrace();
			throw new RuntimeException();
		}
	}

}
