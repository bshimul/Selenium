package week4.homework;

import org.testng.annotations.Test;


public class CreateLeadTestNg_1 extends Week4ProjectWrappers{
	@Test(groups = { "sanity" }, invocationCount=2, invocationTimeOut=200000)
	public void createLead() throws InterruptedException {
		clickByLink("Create Lead");
		enterById("createLeadForm_companyName", "Google");
		enterById("createLeadForm_firstName", "Rajesh");
		enterById("createLeadForm_lastName", "Jayaraman");	
		selectVisibileTextById("createLeadForm_dataSourceId", "Partner");
		selectIndexById("createLeadForm_marketingCampaignId",3);
		enterById("createLeadForm_primaryPhoneNumber", "12345678");
		enterById("createLeadForm_primaryEmail", "devaki.gg@gmail.com");
		clickByName("submitButton");
	}
}