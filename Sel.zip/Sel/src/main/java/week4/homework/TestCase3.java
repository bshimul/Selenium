package week4.homework;

import org.testng.annotations.Test;

public class TestCase3 {
	@Test
	public void testCase3() {
		System.out.print("Test Case 3 is run - using Thread ID - ");
		System.out.println(Thread.currentThread().getId());
	}
}
