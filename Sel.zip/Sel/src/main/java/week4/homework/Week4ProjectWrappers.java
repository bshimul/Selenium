package week4.homework;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;


public class Week4ProjectWrappers extends GenericWrappers{
	
	@Parameters({ "url", "uName", "pwd", "browser" })
	@BeforeMethod
	public void loginToLeafTaps(String url, String uName, String pwd, String browser) throws InterruptedException{
		invokeApp(browser, url); //launching URL
		enterById("username", uName); //entering user id
		enterById("password", pwd); //entering password
		clickByClassName("decorativeSubmit"); // clicking Login
		clickByLinkNoSnap("CRM/SFA"); // click CRM/SFA link
		System.out.println("beforeeeeeeeeeeeeeee");
		
	}
	
	@AfterMethod
	public void closeBrw(){
		//closeBrowser();
	}
	
}
