package wrappers;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.UnexpectedTagNameException;

import utils.Reporter;
public class GenericWrappers extends Reporter implements Wrappers{

	
	public RemoteWebDriver driver;
	int i =1;
	
	protected static Properties prop;
	public String sUrl,primaryWindowHandle,sHubUrl,sHubPort;
	public static String parWinhandle;
	
	public void invokeApp(String browser, String url) {
		try {
			if(browser.equalsIgnoreCase("chrome")){
				System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
				driver = new ChromeDriver(); // launch browser	
			}else if(browser.equalsIgnoreCase("firefox")){
				System.setProperty("webdriver.gecko.driver", "./drivers/geckodriver.exe");
				driver = new FirefoxDriver(); // launch browser	
			}		

			driver.get(url); // enter url 
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(15,TimeUnit.SECONDS);
			System.out.println("PASS:::::The Browser "+browser+" launched successfully");
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::The Browser "+browser+" did not launch.");
			//throw new RuntimeException();
			e.printStackTrace();
		} catch (Exception e) {
			System.err.println("FAIL:::::The Browser "+browser+" did not launch. There was a Exception.");
			//throw new RuntimeException();
			e.printStackTrace();
		}
	}

	public void enterById(String idValue, String data) {
		try {
			driver.findElementById(idValue).clear();
			driver.findElementById(idValue).sendKeys(data);
			System.out.println("PASS:::::The Text field "+idValue+ " is entered with text "+data);
		} catch (NoSuchElementException e) {
			System.err.println("FAIL:::::The Text field "+idValue+ " was not found");
			//throw new RuntimeException();
			e.printStackTrace();
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred-->The Text field "+idValue+ " is not entered with text "+data);
			//throw new RuntimeException();
			e.printStackTrace();
		} finally {
			takeSnap();
		}
	}

	public void enterByName(String nameValue, String data) {
		try {
			driver.findElementByName(nameValue).clear();
			driver.findElementByName(nameValue).sendKeys(data);
			System.out.println("PASS:::::The Text field with name "+nameValue+ " is entered with text "+data);
		} catch (NoSuchElementException e) {
			System.err.println("FAIL:::::The Text field with name "+nameValue+ " was not found");
			//throw new RuntimeException();
			e.printStackTrace();
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred-->The Text field with name "+nameValue+ " is not entered with text "+data);
			//throw new RuntimeException();
			e.printStackTrace();
		} finally {
			takeSnap();
		}
	}

	public void enterByXpath(String xpathValue, String data) {
		try {
			driver.findElementByXPath(xpathValue).clear();
			driver.findElementByXPath(xpathValue).sendKeys(data);
			System.out.println("PASS:::::The Text field with XPath "+xpathValue+ " is entered with text "+data);
		} catch (NoSuchElementException e) {
			System.err.println("FAIL:::::The Text field with XPath "+xpathValue+ " was not found");
			////throw new RuntimeException();
			e.printStackTrace();
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred-->The Text field with XPath "+xpathValue+ " is not entered with text "+data);
			////throw new RuntimeException();
			e.printStackTrace();
		} finally {
			takeSnap();
		}
	}

	public void enterByXpath1(String xpathValue, int data) {
		// TODO Auto-generated method stub
		driver.findElementByXPath("//label[contains(text(),'Lead ID:')]/following::input").sendKeys("14531");
		driver.findElementByXPath("//label[contains(text(),'Lead ID:')]/following::input").sendKeys("14530");
		driver.findElementByXPath("//label[contains(text(),'Lead ID:')]/following::input").sendKeys("14531");
		System.out.println("The Text field "+xpathValue+ " is entered with "+data);
		takeSnap();
	}
	public void verifyTitle(String title) {
		try {
			String pageTitle = driver.getTitle();
			if(title.equals(pageTitle)){
				System.out.println("PASS:::::"+title +" matches with the title of the web page "+pageTitle);
			} else {
				System.out.println("FAIL:::::"+title +" does not match with the title of the web page "+pageTitle);
			}
		} catch (WebDriverException e) {
			System.err.println("FAIL::::: Unknown Exception has occurred");
			//throw new RuntimeException();
			e.printStackTrace();
		} finally {
			takeSnap();
		}
	}

	public void verifyTextById(String id, String text) {
		try {
			String webElementText = driver.findElementById(id).getText();
			if(text.equals(webElementText)){
				System.out.println("PASS:::::"+text +" matches with the text of the webelement ("+webElementText+") with id "+id);
			} else {
				System.out.println("FAIL:::::"+text +" does not match with the text of the webelement ("+webElementText+") with id "+id);
			}
		} catch (NoSuchElementException e) {
			System.err.println("FAIL:::::The WebElement with id "+id+ " was not found");
			//throw new RuntimeException();
			e.printStackTrace();
		} catch (WebDriverException e) {
			System.err.println("FAIL::::: Unknown Exception has occurred");
			//throw new RuntimeException();
			e.printStackTrace();
		} finally {
			takeSnap();
		}
	}

	public void verifyTextContainsById(String id, String text) {
		try {
			String webElementText = driver.findElementById(id).getText();
			if(webElementText.contains(text)){
				System.out.println("PASS:::::"+text +" is present in the text of the webelement ("+webElementText+") with id "+id);
			} else {
				System.out.println("FAIL:::::"+text +" is not present in the text of the webelement ("+webElementText+") with id "+id);
			}
		} catch (NoSuchElementException e) {
			System.err.println("FAIL:::::The WebElement with id "+id+ " was not found");
			//throw new RuntimeException();
			e.printStackTrace();
		} catch (WebDriverException e) {
			System.err.println("FAIL::::: Unknown Exception has occurred");
			//throw new RuntimeException();
			e.printStackTrace();
		} finally {
			takeSnap();
		}
	}

	public void verifyTextByXpath(String xpath, String text) {
		try {
			String webElementText = driver.findElementByXPath(xpath).getText();
			if(text.equals(webElementText)){
				System.out.println("PASS:::::"+text +" matches with the text of the webelement ("+webElementText+") with xpath "+xpath);
			} else {
				System.out.println("FAIL:::::"+text +" does not match with the text of the webelement ("+webElementText+") with xpath "+xpath);
			}
		} catch (NoSuchElementException e) {
			System.err.println("FAIL:::::The WebElement with xpath "+xpath+ " was not found");
			//throw new RuntimeException();
			e.printStackTrace();
		} catch (WebDriverException e) {
			System.err.println("FAIL::::: Unknown Exception has occurred");
			//throw new RuntimeException();
			e.printStackTrace();
		} finally {
			takeSnap();
		}
	}

	public void verifyTextContainsByXpath(String xpath, String text) {
		try {
			String webElementText = driver.findElementByXPath(xpath).getText();
			if(webElementText.contains(text)){
				System.out.println("PASS:::::"+text +" is present in the text of the webelement("+webElementText+") with xpath "+xpath);
			} else {
				System.out.println("FAIL:::::"+text +" is not present in the text of the webelement("+webElementText+") with xpath "+xpath);
			}
		} catch (NoSuchElementException e) {
			System.err.println("FAIL:::::The WebElement with xpath "+xpath+ " was not found");
			//throw new RuntimeException();
			e.printStackTrace();
		} catch (WebDriverException e) {
			System.err.println("FAIL::::: Unknown Exception has occurred");
			//throw new RuntimeException();
			e.printStackTrace();
		} finally {
			takeSnap();
		}
	}

	public void clickById(String id) {
		try {
			driver.findElementById(id).click();
			System.out.println("PASS:::::The Webelement with id "+id+ " is clicked");
		} catch (NoSuchElementException e) {
			System.err.println("FAIL:::::The Webelement with id "+id+ " is not found");
			//throw new RuntimeException();
			e.printStackTrace();
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred");
			//throw new RuntimeException();
			e.printStackTrace();
		} finally {
			takeSnap();
		}
	}

	public void clickByClassName(String classVal) {
		try {
			driver.findElementByClassName(classVal).click();
			System.out.println("PASS:::::The Webelement with Class Name "+classVal+ " is clicked");
		} catch (NoSuchElementException e) {
			System.err.println("FAIL:::::The Webelement with Class Name "+classVal+ " is not found");
			////throw new RuntimeException();
			e.printStackTrace();
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred");
			////throw new RuntimeException();
			e.printStackTrace();
		} finally {
			takeSnap();
		}
	}

	public void clickByName(String name) {
		try {
			driver.findElementByName(name).click();
			System.out.println("PASS:::::The Webelement with Name "+name+" is clicked");
		} catch (NoSuchElementException e) {
			System.err.println("FAIL:::::The Webelement with Name "+name+ " is not found");
			//throw new RuntimeException();
			e.printStackTrace();
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred");
			//throw new RuntimeException();
			e.printStackTrace();
		} finally {
			takeSnap();
		}
	}

	public void clickByLink(String name) {
		try {
			driver.findElementByLinkText(name).click();
			System.out.println("PASS:::::The Webelement with Link Text "+name+" is clicked");
		} catch (NoSuchElementException e) {
			System.err.println("FAIL:::::The Webelement with Link Text "+name+" is not found");
			////throw new RuntimeException();
			e.printStackTrace();
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred");
			////throw new RuntimeException();
			e.printStackTrace();
		} finally {
			takeSnap();
		}
	}

	public void clickByLinkNoSnap(String name) {
		try {
			driver.findElementByLinkText(name).click();
			System.out.println("PASS:::::The Webelement with Link Text " +name+ " is clicked");
		} catch (NoSuchElementException e) {
			System.err.println("FAIL:::::The Webelement with Link Text "+name+" is not found");
			//throw new RuntimeException();
			e.printStackTrace();
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred");
			//throw new RuntimeException();
			e.printStackTrace();
		}
	}

	public void clickByXpath(String xpathVal) {
		// {
			driver.findElementByXPath(xpathVal).click();
			System.out.println("PASS:::::The Webelement with xpath "+xpathVal+" is clicked");
		//} catch (NoSuchElementException e) {
		//	System.err.println("FAIL:::::The Webelement with xpath "+xpathVal+" is not found");
			////throw new RuntimeException();
		//	e.printStackTrace();
		//} catch (WebDriverException e) {
		//	System.err.println("FAIL:::::Unknown Exception has occurred");
			////throw new RuntimeException();
		//	e.printStackTrace();
		//} finally {
			takeSnap();
		//}
	}

	public void clickByXpathNoSnap(String xpathVal) {
		try {
			driver.findElementByXPath(xpathVal).click();
			System.out.println("PASS:::::The Webelement with xpath "+xpathVal+" is clicked");
		} catch (NoSuchElementException e) {
			System.err.println("FAIL:::::The Webelement with xpath "+xpathVal+" is not found");
			//throw new RuntimeException();
			e.printStackTrace();
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred");
			////throw new RuntimeException();
			e.printStackTrace();
		}
	}

	public String getTextById(String idVal) {
		String idText = "";
		try {
			idText = driver.findElementById(idVal).getText();
			System.out.println("PASS:::::The Webelement with id "+idVal+" has text as "+idText);
		} catch (NoSuchElementException e) {
			System.err.println("FAIL:::::The Webelement with id "+idVal+" is not found");
			//throw new RuntimeException();
			e.printStackTrace();
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred");
			//throw new RuntimeException();
			e.printStackTrace();
		} finally {
			takeSnap();
		}
		return idText;
	}

	public String getTextByXpath(String xpathVal) {
		String xpathText = "";
		try {
			xpathText = driver.findElementByXPath(xpathVal).getText();
			System.out.println("PASS:::::The Webelement with xpath "+xpathVal+" has text as "+xpathText);
		} catch (NoSuchElementException e) {
			System.err.println("FAIL:::::The Webelement with xpath "+xpathVal+" is not found");
			//throw new RuntimeException();
			e.printStackTrace();
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred");
			//throw new RuntimeException();
			e.printStackTrace();
		} finally {
			takeSnap();
		}
		return xpathText;
	}

	public void selectVisibileTextById(String id, String value) {
		try {
			WebElement element = driver.findElementById(id);
			Select src = new Select(element);
			src.selectByVisibleText(value);
			System.out.println("PASS:::::"+value +" is select from dropdown webelement with id "+id);
		} catch (NoSuchElementException e) {
			System.err.println("FAIL:::::The Webelement with id "+id+" is not found/The Webelement with visible text "+value+" is not found");
			//throw new RuntimeException();
			e.printStackTrace();
		} catch (UnexpectedTagNameException e) {
			System.err.println("FAIL:::::The Webelement with id "+id+" is not a dropdown field to select a item");
			//throw new RuntimeException();
			e.printStackTrace();
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred");
			//throw new RuntimeException();
			e.printStackTrace();
		} finally {
			takeSnap();
		}
	}

	public void selectIndexById(String id, int value) {
		try {
			WebElement element = driver.findElementById(id);
			Select src = new Select(element);
			src.selectByIndex(value);
			System.out.println("PASS:::::Item no "+value+" is selected from dropdown webelement with id "+id);
		} catch (NoSuchElementException e) {
			System.err.println("FAIL:::::The Webelement with id "+id+" is not found/The Webelement with index "+value+" is not found");
			//throw new RuntimeException();
			e.printStackTrace();
		} catch (UnexpectedTagNameException e) {
			System.err.println("FAIL:::::The Webelement with id "+id+" is not a dropdown field to select a item");
			//throw new RuntimeException();
			e.printStackTrace();
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred");
			//throw new RuntimeException();
			e.printStackTrace();
		} finally {
			takeSnap();
		}
	}

	public void selectValueById(String id, String value) {
		try {
			WebElement element = driver.findElementById(id);
			Select src = new Select(element);
			src.selectByValue(value);
			System.out.println("PASS:::::Item with value "+value+" is selected from dropdown webelement with id "+id);
		} catch (NoSuchElementException e) {
			System.err.println("FAIL:::::The Webelement with id "+id+" is not found/The Webelement with index "+value+" is not found");
			//throw new RuntimeException();
			e.printStackTrace();
		} catch (UnexpectedTagNameException e) {
			System.err.println("FAIL:::::The Webelement with id "+id+" is not a dropdown field to select a item");
			//throw new RuntimeException();
			e.printStackTrace();
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred");
			//throw new RuntimeException();
			e.printStackTrace();
		} finally {
			takeSnap();
		}
	}
	
	public void switchToParentWindow() {
		try {
			Set<String> allWindowHandles = driver.getWindowHandles();
			List<String> allWinHandlesList = new ArrayList<>(allWindowHandles);
			System.out.println(allWindowHandles.size());
			
			for (int i = 0; i < allWinHandlesList.size(); i++) {
				driver.switchTo().window(allWinHandlesList.get(i));
			}
			for (String eachHandle : allWindowHandles) {
				driver.switchTo().window(eachHandle);
				System.out.println("title of current window is "+driver.getTitle());
				break;
			}
			System.out.println("PASS:::::The control is switched to the parent window");
		} catch (NoSuchWindowException e) {
			System.err.println("FAIL:::::The window cannot be switced to ParentWindow");
			//throw new RuntimeException();
			e.printStackTrace();
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred");
			//throw new RuntimeException();
			e.printStackTrace();
		}
	}

	public void switchToLastWindow() {
		try {
			parWinhandle = driver.getWindowHandle();
			Set<String> allWindowHandles = driver.getWindowHandles();
			//int windowCount = allWindowHandles.size();
			//int i = 0;
			System.out.println(allWindowHandles.size());
			for (String eachHandle : allWindowHandles) {
				driver.switchTo().window(eachHandle);
				//i++;
				//if (i==windowCount) break;
				System.out.println("title of current window is "+driver.getTitle());
				
				driver.switchTo().window(eachHandle);
				//i++;
				//if (i==windowCount) break;
				System.out.println("title of current window is "+driver.getTitle());
				
				driver.switchTo().window(eachHandle);
				//i++;
				//if (i==windowCount) break;
				System.out.println("title of current window is "+driver.getTitle());
				
				driver.switchTo().window(eachHandle);
				//i++;
				//if (i==windowCount) break;
				System.out.println("title of current window is "+driver.getTitle());
				
				driver.switchTo().window(eachHandle);
				//i++;
				//if (i==windowCount) break;
				System.out.println("title of current window is "+driver.getTitle());
			}
			System.out.println("PASS:::::The control is switched to the last window");
		} catch (NoSuchWindowException e) {
			System.err.println("FAIL:::::The window cannot be switced to one of the Window Handle");
			//throw new RuntimeException();
			e.printStackTrace();
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred");
			//throw new RuntimeException();
			e.printStackTrace();
		}
	}

	public void switchToFrame(String frameIdorName) {
		try {
			driver.switchTo().frame(frameIdorName);
			System.out.println("PASS:::::The Frame has been switced to "+frameIdorName);
		} catch (NoSuchFrameException e) {
			System.err.println("FAIL:::::The Frame cannot be switced to "+frameIdorName);
			//throw new RuntimeException();
			e.printStackTrace();
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred");
			//throw new RuntimeException();
			e.printStackTrace();
		}
	}
	
	public void acceptAlert() {
		try {
			driver.switchTo().alert().accept();
			System.out.println("PASS:::::The Alert has been accepted with OK button");
		} catch (NoAlertPresentException e) {
			System.err.println("FAIL:::::There is no Alert present to accept");
			//throw new RuntimeException();
			e.printStackTrace();
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred");
			//throw new RuntimeException();
			e.printStackTrace();
		}
	}

	public void dismissAlert() {
		try {
			driver.switchTo().alert().dismiss();
			System.out.println("PASS:::::The Alert has been dismissed with cancel button");
		} catch (NoAlertPresentException e) {
			System.err.println("FAIL:::::There is no Alert present to dismiss");
			//throw new RuntimeException();
			e.printStackTrace();
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred");
			//throw new RuntimeException();
			e.printStackTrace();
		}
	}

	public String getAlertText() {
		String alertText = "";
		try {
			alertText = driver.switchTo().alert().getText();
			System.out.println("PASS:::::The Alert has the text "+alertText);
		} catch (NoAlertPresentException e) {
			System.err.println("FAIL:::::There is no Alert present to get the Text");
			//throw new RuntimeException();
			e.printStackTrace();
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred");
			//throw new RuntimeException();
			e.printStackTrace();
		}
		return alertText;
	}

	/*public void takeSnap() {
		try {
			File src = driver.getScreenshotAs(OutputType.FILE);
			File dest = new File("./snaps/snap"+i+".jpg");
			i++;
			FileUtils.copyFile(src, dest);
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred while taking snap shot");
			////throw new RuntimeException();
			e.printStackTrace();
		} catch (IOException e) {
			System.err.println("Unable to take snap shot");
			e.printStackTrace();
		}
	}*/
	
	/**
	 * This method will take snapshot of the browser
	 * @author Babu - TestLeaf
	 */
	public long takeSnap(){
		long number = (long) Math.floor(Math.random() * 900000000L) + 10000000L; 
		//try {
			try {
				FileUtils.copyFile(driver.getScreenshotAs(OutputType.FILE) , new File("./reports/images/"+number+".jpg"));
			} catch (WebDriverException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		//} catch (WebDriverException e) {
		///	reportStep("The browser has been closed.", "FAIL");
		//} catch (IOException e) {
		//	reportStep("The snapshot could not be taken", "WARN");
		//}
		return number;
	}
	
	public void loadObjects() {
		prop = new Properties();
		try {
			prop.load(new FileInputStream(new File("./src/main/resources/object.properties")));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public void unloadObjects() {
		prop = null;
	}
	
	public void closeBrowser() {
		try {
			driver.close();
			System.out.println("PASS:::::The current active browser has been closed");
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred - Browser cannot be closed");
			//throw new RuntimeException();
			e.printStackTrace();
		}
	}

	public void closeAllBrowsers() {
		try {
		driver.quit();
		System.out.println("PASS:::::All the current active browsers have been closed");
		} catch (WebDriverException e) {
			System.err.println("FAIL:::::Unknown Exception has occurred - Browser cannot be quitted");
			//throw new RuntimeException();
			e.printStackTrace();
		}
	}

}
