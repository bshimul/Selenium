package wrappers;

import java.io.File;
import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

public class ProjectWrappers extends GenericWrappers{
	
	@BeforeMethod
	public void loginToLeafTaps(){
		invokeApp("chrome", "http://www.leaftaps.com/control/main"); //launching URL
		enterById("username", "DemoSalesManager"); //entering user id
		enterById("password", "crmsfa"); //entering password
		clickByClassName("decorativeSubmit"); // clicking Login
		clickByLinkNoSnap("CRM/SFA"); // click CRM/SFA link
	}
	
	@AfterMethod
	public void closeBrw(){
		closeBrowser();
	}
	
	@DataProvider(parallel=true)
	//method return type is Object array
	public static Object[][] getData() throws InvalidFormatException, IOException{
		//File location with file name
		File fis = new File("./data/CreateLead.xlsx");
		//Create WorkBook for file
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		//get first sheet using index
		XSSFSheet sheet = wb.getSheetAt(0);
		//get Row and column count
		int rowCount = sheet.getLastRowNum();
		XSSFRow titleRow = sheet.getRow(0);
		int colCount = titleRow.getLastCellNum();
		//Create object Array
		//rowCount and columnCount is the dimension
		Object[][] data = new Object[rowCount][colCount];
		for (int i = 1; i <= rowCount; i++) {
			XSSFRow row = sheet.getRow(i);
			for (int j = 0; j < colCount; j++) {
				XSSFCell cell = row.getCell(j); 
				data[i-1][j] = cell.getStringCellValue(); 
				//above is merging excel cell value with the data provider
				//i-1 is used as index of data provider is 
			}
		}
		wb.close();
		return data;
	}
	
}
