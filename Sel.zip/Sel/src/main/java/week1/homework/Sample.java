package week1.homework;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Sample {

	public static void main(String[] args) throws InterruptedException {
		// Set the system property of webdriver.chrome.driver to the location of
		// chromedrive exe
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		// Creating the ChromeDriver instance
		ChromeDriver driver = new ChromeDriver();

		// Launching the browser with the IRCTC signup URL
		driver.get("http://testleaf.herokuapp.com/pages/Dropdown.html");
		// Maximizing the window
		driver.manage().window().maximize();
		// Set 20 seconds as an implicit wait time to find an element
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

		Select country = new Select(driver.findElementById("dropdown3"));
		List<WebElement> alloptions1 = country.getOptions();
		int count1 = alloptions1.size();
		for (int i = 1; i <= count1; i++) {
			System.out.println(alloptions1.get(i).getText());

		}

	}
}
