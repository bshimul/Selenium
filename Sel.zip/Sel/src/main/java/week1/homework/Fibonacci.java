package week1.homework;

public class Fibonacci {

	public static void main(String[] args) {
		long num1 = 1;
		long num2 = 1;
		long sum = num1 + num2;
		System.out.print(num1 + " " +  num2 + " " + sum);
		//since first 3 numbers are already printed start from 4
		for (int count = 4; count <= 100; count++) {
			num1 = num2;
			num2 = sum;
			sum = num1 + num2;
			System.out.print(" " + sum);
		}
	}

}
