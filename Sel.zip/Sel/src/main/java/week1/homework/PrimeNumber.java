package week1.homework;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class PrimeNumber {

	public static void main(String[] args) {
		//int number = 9;
		boolean isPrime = true;
		int number = 0;
		//Get the number as User Input
		System.out.println("Enter an Integer");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		//Parse the entered String to Integer. If it throws as NFE terminate the program
		try {
			number = Integer.parseInt(br.readLine());
		} catch (NumberFormatException e) {
			System.out.println("Enter a valid integer");
			System.exit(0);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		//Check if the number is a negative number
		if (number < 0)
			System.out.println("Enter a positive number");
		
		//Loop from 2 to number/2 + 1 and divide the number by count 
		//if the reminder is zero for any division set the isPrime to false to break the loop
		for (int count = 2; count < number/2 + 1; count++) {
			if (number%count == 0) {
				isPrime = false;
				break;
			}
		}
		if (isPrime)
			System.out.println("The number "+ number +" is a Prime Number");
		else
			System.out.println("The number "+ number +" is not a Prime Number");
	}

}
