package week1.homework;

public class PrintEven {

	public static void main(String[] args) {
		for (int number = 100; number <= 200; number++) {
			if (number % 2 == 0)
				System.out.println(number);
		}
	}

}
