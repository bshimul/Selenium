package week1.homework;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class SwitchFrames {
	static ChromeDriver driver;
	public static void main(String[] args) throws InterruptedException {
		//Set the system property of webdriver.chrome.driver to the location of chromedrive exe
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		//Creating the ChromeDriver instance
		driver = new ChromeDriver();
		// Launching the browser with the IRCTC signup URL
		driver.get("http://layout.jquery-dev.com/demos/iframes_many.html");
		//Maximizing the window
		driver.manage().window().maximize();
		//Set 20 seconds as an implicit wait time to find an element
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		Thread.sleep(10000);
		List<WebElement> frames = driver.findElementsByTagName("iframe");
		int noOfFrames = 0;
		for (WebElement frame : frames) {
			noOfFrames ++;
			noOfFrames = noOfFrames + countFrames(frame);
		}
		
		System.out.println(noOfFrames);
	}

	private static int countFrames(WebElement frame) {
		driver.switchTo().frame(frame);
		List<WebElement> framesNested = driver.findElementsByTagName("iframe");
		if (framesNested.size()== 0){
			driver.switchTo().parentFrame();
			return 0;
		} else {
			int count = 0;
			for (WebElement frameNested : framesNested) {
				count ++;
				count = count + countFrames(frameNested);
			}
			driver.switchTo().parentFrame();
			return count;
		}
		
	}
}
