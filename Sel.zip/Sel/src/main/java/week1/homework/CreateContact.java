package week1.homework;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;

public class CreateContact {
	public static void main(String[] args) {
		//Set the system property of webdriver.chrome.driver to the location of chromedrive exe
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		//Creating the ChromeDriver instance
		ChromeDriver driver = new ChromeDriver();
		
		// Launching the browser with the leaf taps URL
		driver.get("http://leaftaps.com/control/main");
		//Maximizing the window
		driver.manage().window().maximize();
		//Set 20 seconds as an implicit wait time to find an element
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		//Find the username WebElement by its id and enter the user name
		driver.findElementById("username").sendKeys("DemoSalesManager");
		//Find the password WebElement by its id and enter the password
		driver.findElementById("password").sendKeys("crmsfa");
		
		//Find the Login button WebElement by its classname and click the login button
		driver.findElementByClassName("decorativeSubmit").click();
		//Find the CRM/SFA link WebElement and click the link by its linkText
		driver.findElementByLinkText("CRM/SFA").click();
		//FInd the CreateLead link WebElement and click it by its linktext
		driver.findElementByLinkText("Create Contact").click();
		
		//Enter the First Name field by finding it using id
		driver.findElementById("firstNameField").sendKeys("Balachander");
		//Enter the Last Name field by finding it using its id
		driver.findElementById("lastNameField").sendKeys("Subramanian");

		//Click the Create Lead button by finding its name
		driver.findElementByName("submitButton").click();
		
	}
}
