package week1.homework;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class IrctcSignUp {

	public static void main(String[] args) throws InterruptedException {
		//Set the system property of webdriver.chrome.driver to the location of chromedrive exe
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		//Creating the ChromeDriver instance
		ChromeDriver driver = new ChromeDriver();
		
		// Launching the browser with the IRCTC signup URL
		driver.get("https://www.irctc.co.in/eticketing/userSignUp.jsf");
		//Maximizing the window
		driver.manage().window().maximize();
		//Set 20 seconds as an implicit wait time to find an element
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		
		WebElement countryElement1 = driver.findElementById("userRegistrationForm:countries");
		Select country1 = new Select(countryElement1);
		country1.selectByValue("94");
		driver.findElementById("userRegistrationForm:pincode").sendKeys("641020", Keys.TAB);
		Thread.sleep(5000);
		
		
		String state =driver.findElementById("userRegistrationForm:statesName").getAttribute("value");
		System.out.println(state);
		driver.findElementByLinkText("Check Availability").click();
		Thread.sleep(115000);
		driver.switchTo().alert().sendKeys("");
		//Enter user name, pass and confirm pass by find the WebElement by its ID
		driver.findElementById("userRegistrationForm:userName").sendKeys("bala123456");
		driver.findElementById("userRegistrationForm:password").sendKeys("bal1234567");
		driver.findElementById("userRegistrationForm:confpasword").sendKeys("bal1234567");
		
		//Select the first item (after select secret question) from secret ques drop down
		WebElement secQues = driver.findElementById("userRegistrationForm:securityQ");
		
		Select secret = new Select(secQues);
		secret.selectByIndex(1);
		
		
		//Enter Secret Answer
		driver.findElementById("userRegistrationForm:securityAnswer").sendKeys("Puppy");
		
		//Enter the first and last name by finding the element by its id
		driver.findElementById("userRegistrationForm:firstName").sendKeys("Balachander");
		driver.findElementById("userRegistrationForm:lastName").sendKeys("Subrmanian");
		
		//select gender and marital status
		driver.findElementById("userRegistrationForm:gender:0").click();
		driver.findElementById("userRegistrationForm:maritalStatus:1").click();
		
		//select Date of Birth by select by value, index and visible text
		WebElement dateElement = driver.findElementById("userRegistrationForm:dobDay");
		Select dates = new Select(dateElement);
		dates.selectByValue("05");
		
		WebElement monthElement = driver.findElementById("userRegistrationForm:dobMonth");
		Select month = new Select(monthElement);
		month.selectByIndex(3);;
		
		WebElement yearElement = driver.findElementById("userRegistrationForm:dateOfBirth");
		Select year = new Select(yearElement);
		year.selectByVisibleText("1985");
		
		//Select the occupation by visible text 
		WebElement occupationElement = driver.findElementById("userRegistrationForm:occupation");
		Select occupation = new Select(occupationElement);
		occupation.selectByVisibleText("Professional");
		
		//Enter email and mobile number
		driver.findElementById("userRegistrationForm:email").sendKeys("balachander.cbe@gmail.com");
		driver.findElementById("userRegistrationForm:mobile").sendKeys("9843294796");
		
		//Select the nationality by visible text 
		WebElement nationalityElement = driver.findElementById("userRegistrationForm:nationalityId");
		Select nationality = new Select(nationalityElement);
		
		List<WebElement> alloptions = nationality.getOptions();
		//Option#1 selectByIndex
		for (int i = 0; i < alloptions.size(); i++) {
			if (alloptions.get(i).getText().startsWith("E")){
				nationality.selectByIndex(i+1);
				//alloptions.get(i+1).click(); Even this can be used
				break;
			}
		}
		//option#2 selectByVisibleText
		int count = 0;
		for (WebElement option : alloptions) {
			if(option.getText().startsWith("E")){
				count ++;
				if (count == 4)
					nationality.selectByVisibleText(option.getText());
				break;
			}
		}
		
		
		
		nationality.selectByVisibleText("India");
		System.out.println(nationalityElement.isSelected());
		//Enter residential Address fields
		driver.findElementById("userRegistrationForm:address").sendKeys("8H/18, Union Tank Road,");
		WebElement countryElement = driver.findElementById("userRegistrationForm:countries");
		Select country = new Select(countryElement);
		country.selectByValue("94");
		driver.findElementById("userRegistrationForm:pincode").sendKeys("641020", Keys.TAB);
		Thread.sleep(5000);
		WebElement cityElement = driver.findElementById("userRegistrationForm:cityName");
		Select city = new Select(cityElement);
		city.selectByIndex(1);
		Thread.sleep(5000);
		WebElement postalElement = driver.findElementById("userRegistrationForm:postofficeName");
		Select postal = new Select(postalElement);
		postal.selectByVisibleText("Sri Ramakrishna Vidyalaya S.O");
		driver.findElementById("userRegistrationForm:landline").sendKeys("04222692039");
	}

}
