package week1.homework;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class SelectSecondECountry {

	public static void main(String[] args) throws InterruptedException {
		//Set the system property of webdriver.chrome.driver to the location of chromedrive exe
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		//Creating the ChromeDriver instance
		ChromeDriver driver = new ChromeDriver();
		
		// Launching the browser with the IRCTC signup URL
		driver.get("https://www.irctc.co.in/eticketing/userSignUp.jsf");
		//Maximizing the window
		driver.manage().window().maximize();
		//Set 20 seconds as an implicit wait time to find an element
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		WebElement nationalityElement = driver.findElementById("userRegistrationForm:nationalityId");
		Select nationality = new Select(nationalityElement);
		
		List<WebElement> alloptions = nationality.getOptions();
		//Option#1 selectByIndex
		for (int i = 0; i < alloptions.size(); i++) {
			if (alloptions.get(i).getText().startsWith("E")){
				nationality.selectByIndex(i+1);
				//alloptions.get(i+1).click(); Even this can be used
				break;
			}
		}
		//option#2 selectByVisibleText
		int count = 0;
		for (WebElement option : alloptions) {
			if(option.getText().startsWith("E")){
				count ++;
				if (count == 2) {
					nationality.selectByVisibleText(option.getText());
					break;
				}
			}
		}
		//nationalityElement.sendKeys("E","E"); //Even this can be tried if the dropdown textbox accepts alphabets
	}
}
