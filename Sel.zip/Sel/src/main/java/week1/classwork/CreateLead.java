package week1.classwork;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class CreateLead {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
				//Driver initialization
				System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
				//Creating Chromedriver instance
				ChromeDriver driver=new ChromeDriver();
				//Launch the browser
				driver.get("http://www.leaftaps.com/opentaps");
				//Maximizing the browser
				driver.manage().window().maximize();		
				//Entering the Username
				driver.findElementById("username").sendKeys("DemoSalesManager");
				//Entering the Password
				driver.findElementById("password").sendKeys("crmsfa");
				//Clicking the Login button
				driver.findElementByClassName("decorativeSubmit").click();
				//Clicking on CRM/SFA link
				driver.findElementByLinkText("CRM/SFA").click();
				//Clicking CreateLead
				driver.findElementByLinkText("Create Lead").click();
				//fill the 3 mandatory fields
				
				 Select dd = new Select  (driver.findElementById("createLeadForm_dataSourceId"));
			       List<WebElement> dd1 = dd.getAllSelectedOptions();
			       dd1.lastIndexOf(dd);
				//Selecting the source by visible text
				//finding the dropdown webelement source
				WebElement source = driver.findElementById("createLeadForm_dataSourceId");
				
				//creating object src for select class
				Select src= new Select(source);
				
				//using the object src to select by visible text
				src.selectByVisibleText("Employee");
				
				//selecting the Industry by index
				//finding the webelement industry
				//WebElement industry= driver.findElementById("createLeadForm_industryEnumId");
				//creating object ind for select class
				//Select ind = new Select(industry);
				//selecting the industry by index
				//ind.selectByIndex(3);
				
				//selecting the Industry by Last index
				//finding the webelement industry
				WebElement industry= driver.findElementById("createLeadForm_industryEnumId");
				//creating object ind for select class
				Select ind = new Select(industry);
				//reading all the values in the dropdown
				List<WebElement> allOptions = ind.getOptions();
				//finding the size of the list
				int count=allOptions.size();
				//selecting the item which is at the last index
				ind.selectByIndex(count-1);
				
				//selecting the industry by index
				//ind.selectByIndex(3);
				
				
				//selecting Ownership by value
				//finding the element ownership
				WebElement ownership = driver.findElementById("createLeadForm_ownershipEnumId");
				//creating object own for select class
				Select own = new Select(ownership);
				//selecting the ownership by value
				own.selectByValue("OWN_SCORP");
				
	}
}
