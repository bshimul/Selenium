package week1.classwork;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class PrintAllDropDownValues {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Driver initialization
				System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
				//Creating Chromedriver instance
				ChromeDriver driver=new ChromeDriver();
				//Launch the browser
				driver.get("https://www.irctc.co.in/eticketing/userSignUp.jsf");
				//Maximizing the browser
				driver.manage().window().maximize();
				
				//choosing the element country by its locator id
				WebElement country=  driver.findElementById("userRegistrationForm:countries");
				
				//Initializing the Select class using new object cntry
				Select cntry = new Select(country);
				
				//Reading list of all country options in the webelement country
				List<WebElement> cntryoptions = cntry.getOptions();
				
				System.out.println("The list of countries are:\n");
				
				for(WebElement option : cntryoptions)
				{
					System.out.println(option.getText().trim());
				}
	}
}