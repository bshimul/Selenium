package week1.classwork;

public class EvenNumbers {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		
		System.out.println("Even Numbers between 100 and 200 are below:");
        for(int i=100;i<=200;i++)
        {
            if(i%2==0)
            {
                System.out.println(i);
            }
    	}
        
	}
}
