package week1.classwork;

import java.util.Scanner;

public class Swap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a,b;
		
		System.out.println("Enter the first number:");
		Scanner num1 = new Scanner(System.in);
		a=num1.nextInt();
		num1.close();
		
		System.out.println("Enter the second number:");
		Scanner num2 = new Scanner(System.in);
		b=num2.nextInt();
		num2.close();
		
		System.out.println("Numbers before swapping are: "+a+ ", " +b);
		
		a = a + b;
		b = a - b;
		a = a - b;
		
		System.out.println("Numbers after swapping are: "+a+ ", " +b);
		
	}

}