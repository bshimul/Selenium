package week1.classwork;

import org.openqa.selenium.chrome.ChromeDriver;

public class CreateContact {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
						//Driver initialization
						System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
						//Creating Chromedriver instance
						ChromeDriver driver=new ChromeDriver();
						//Launch the browser
						driver.get("http://www.leaftaps.com/control/main");
						//Maximizing the browser
						driver.manage().window().maximize();		
						//Entering the Username
						driver.findElementById("username").sendKeys("DemoSalesManager");
						//Entering the Password
						driver.findElementById("password").sendKeys("crmsfa");
						//Clicking the Login button
						driver.findElementByClassName("decorativeSubmit").click();
						//Clicking on CRM/SFA link
						driver.findElementByLinkText("CRM/SFA").click();
						//Clicking Create Contact
						driver.findElementByLinkText("Create Contact").click();
						//Entering the First name mandatory field
						driver.findElementById("firstNameField").sendKeys("Devaki");
						//Entering the Last name mandatory field
						driver.findElementById("lastNameField").sendKeys("Godhandaraman");
						//Clicking the Submit button
						driver.findElementByName("submitButton").click();
			}
		}