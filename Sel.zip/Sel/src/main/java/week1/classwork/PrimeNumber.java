package week1.classwork;

import java.util.Scanner;

public class PrimeNumber {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		//declaration of the result of Prime number logic
		int temp,num;
		//storing that if result is true, print the answer isprime
		boolean isPrime=true;
		//reading the input number
		Scanner scan= new Scanner(System.in);
		//asking the user to enter the number 
		System.out.println("Enter a number to check if it is Prime or not:");
		
		//catch exception
		if(!scan.hasNextInt()){
			try{
				num=scan.nextInt();
			}catch(Exception e){
				System.out.println("Invalid Input. Please enter a NUMBER!");
				System.exit(-1);
			}
		}
		
		//capture the input in an integer
		num=scan.nextInt();
		scan.close();
		
		//checking for 1 and 0
		if (num==1||num==0){
			System.out.println(num+ " is not a prime");
		}
		
		else{
		//opening for loop for the input numbers
		for(int i=2;i<=num/2;i++)
		{
	           temp=num%i;
		   if(temp==0)
		   {
		      isPrime=false;
		      break;
		   }
		}
		//If isPrime is true then the number is prime else not
		if(isPrime)
		   System.out.println(num + " is a Prime Number");
		else
		   System.out.println(num + " is not a Prime Number");
		}
	}

}
