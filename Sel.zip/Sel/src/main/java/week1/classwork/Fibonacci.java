package week1.classwork;

import java.math.BigInteger;

public class Fibonacci {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//declarations
		BigInteger series = new BigInteger("0");
		BigInteger n = new BigInteger("0");
		BigInteger f1 = new BigInteger("1");
			
		
		//Printing the first number 1
		System.out.println("Fibonacci series is\n" +f1+ " ");
		
		//printing the Fibonacci series from 1 to 100
		for(int i=0;i<=100;i++){
			//adding the 2 precedent numbers
			series = n.add(f1);
			
			System.out.println(series+ " ");
			
			//reassigning
			n=f1;
			f1=series;
			}
	}
}
