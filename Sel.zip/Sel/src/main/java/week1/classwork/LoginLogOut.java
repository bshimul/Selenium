package week1.classwork;

import org.openqa.selenium.chrome.ChromeDriver;

public class LoginLogOut {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Driver initialization
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		//Creating Chromedriver instance
		ChromeDriver driver=new ChromeDriver();
		//Launch the browser
		driver.get("http://www.leaftaps.com/control/main");
		//Maximizing the browser
		driver.manage().window().maximize();		
		//Entering the Username
		driver.findElementById("username").sendKeys("DemoSalesManager");
		//Entering the Password
		driver.findElementById("password").sendKeys("crmsfa");
		//Clicking the Login button
		driver.findElementByClassName("decorativeSubmit").click();
		//Clicking the Logout button
		driver.findElementByClassName("decorativeSubmit").click();
		
	}

}
