package week1.classwork;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class IrctcSignUp {

	@SuppressWarnings("static-access")
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub		
												
								//Driver initialization
								System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
								//Creating Chromedriver instance
								ChromeDriver driver=new ChromeDriver();
								//Launch the browser
								driver.get("https://www.irctc.co.in/eticketing/userSignUp.jsf");
								//Maximizing the browser
								driver.manage().window().maximize();
								
								//Entering User ID
								driver.findElementById("userRegistrationForm:userName").sendKeys("Test");
								
								//Entering the Password
								driver.findElementById("userRegistrationForm:password").sendKeys("Welcome@01");
								
								//Re-enter the password
								driver.findElementById("userRegistrationForm:confpasword").sendKeys("Welcome@01");
								
								//Choose a Security question
								//finding the security question dropdown
								WebElement secquestion = driver.findElementById("userRegistrationForm:securityQ");
								//initializing the Select class
								Select question = new Select(secquestion);
								//selecting the security question dropdown by index
								question.selectByIndex(1);
								
								//Enter the Security Answer
								driver.findElementById("userRegistrationForm:securityAnswer").sendKeys("Julie");
								
								//Choose the preferred language
								//finding the preferred language dropdown
								WebElement language = driver.findElementById("userRegistrationForm:prelan");
								//initializing the Select class
								Select lang = new Select(language);
								//choosing the language by value
								lang.selectByValue("hi");
								
								//Enter First name
								driver.findElementById("userRegistrationForm:firstName").sendKeys("Devaki");
								
								//Enter Last name
								driver.findElementById("userRegistrationForm:lastName").sendKeys("Godhandaraman");
								
								//Choose Gender
								driver.findElementById("userRegistrationForm:gender:1").click();
								
								//Choose Marital Status
								driver.findElementById("userRegistrationForm:maritalStatus:0").click();
								
								//Choose the date of birth
								//finding the date dropdown
								WebElement dob = driver.findElementById("userRegistrationForm:dobDay");
								//initializing the select class
								Select date = new Select(dob);
								//choosing the date by visible text
								date.selectByVisibleText("22");
								
								//finding the month dropdown
								WebElement dom = driver.findElementById("userRegistrationForm:dobMonth");
								//initializing the select class
								Select month = new Select(dom);
								//choosing the month by visible text
								month.selectByVisibleText("AUG");
								
								//finding the year drop down
								WebElement doy = driver.findElementById("userRegistrationForm:dateOfBirth");
								//initializing the select class
								Select year = new Select(doy);
								//choosing the date by visible text
								year.selectByVisibleText("1988");
								
								//Choose Occupation
								//finding the occupation dropdown
								WebElement occupation = driver.findElementById("userRegistrationForm:occupation");
								//initializing the Select class to choose any option
								Select occu = new Select(occupation);
								//select by index
								occu.selectByIndex(3);
								
								//Enter E-mail id
								driver.findElementById("userRegistrationForm:email").sendKeys("devakijayavelan@gmail.com");
																
								//Enter mobile number
								driver.findElementById("userRegistrationForm:mobile").sendKeys("9551146464");
								
								//Choose Nationality
								//finding the nationality dropdown
								WebElement nationality = driver.findElementById("userRegistrationForm:nationalityId");
								//making use of Select class to choose the dropdown option
								Select nation = new Select(nationality);
								//Select by visible text
								nation.selectByVisibleText("India");
								
								//Enter Flat/Door/Block No
								driver.findElementById("userRegistrationForm:address").sendKeys("Olympia/19b2,Amber");
								
								//Choose country
								WebElement country = driver.findElementById("userRegistrationForm:countries");
								Select cntry = new Select(country);
								cntry.selectByValue("94");
								
								//Enter pin code and click tab
								WebElement pincode = driver.findElementById("userRegistrationForm:pincode");
								pincode.sendKeys("603103");
								pincode.sendKeys(Keys.TAB);
																							
								//State name auto populated while we wait for 5000 ms																							
								Thread thread = new Thread();
								 thread.sleep(5000);
								
								//Choose City/town and click tab
								WebElement city = driver.findElementById("userRegistrationForm:cityName");
								Select citytown = new Select(city);
								citytown.selectByIndex(1);
								city.sendKeys(Keys.TAB);
								
								//Finding the web element post office
								thread.sleep(5000);
								WebElement postoffice = driver.findElementById("userRegistrationForm:postofficeName");
								postoffice.click();
								
								//Selecting the Post office by index
								Select po = new Select(postoffice);
								po.selectByIndex(1);
								
								//Enter phone number
								driver.findElementById("userRegistrationForm:landline").sendKeys("9551146464");
								
	}
		
}