package week1.classwork;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Country {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Driver initialization
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		//Creating Chromedriver instance
		ChromeDriver driver=new ChromeDriver();
		//Launch the browser
		driver.get("https://www.irctc.co.in/eticketing/userSignUp.jsf");
		//Maximizing the browser
		driver.manage().window().maximize();
		
		//choosing the element country by its locator id
		WebElement country=  driver.findElementById("userRegistrationForm:countries");
		
		//Initializing the Select class using new object cntry
		Select cntry = new Select(country);
		
		//selecting the country Egypt by visible Text
		//cntry.selectByVisibleText("Egypt");
		
		//Reading list of all country options in the webelement country
		List<WebElement> cntryoptions = cntry.getOptions();
		
		//declaring a new list to store only country names starting with E
		List<String> opt = new ArrayList<String>();
		
		//for each item in the existing list,checking if the first character is E, then add in the new list
		for(WebElement option : cntryoptions)
		{
			if(option.getText().charAt(0) == 'E')
			{
				opt.add(option.getText());
			}
		}
		
		cntry.selectByVisibleText(opt.get(0));;	
	}
}