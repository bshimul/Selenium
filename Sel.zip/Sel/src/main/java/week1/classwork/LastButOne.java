package week1.classwork;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class LastButOne {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
						
						//Driver initialization
						System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
						//Creating Chromedriver instance
						ChromeDriver driver=new ChromeDriver();
						//Launch the browser
						driver.get("http://leafground.com/");
						//Maximizing the browser
						driver.manage().window().maximize();
						//clicking on the link text Drop down
						driver.findElementByLinkText("Drop down").click();
						
						//fining the dropdown to choose the course by index
						WebElement training =  driver.findElementById("dropdown1");
						
						//creating object course for select class
						Select course = new Select(training);
						
						//reading all the values in the dropdown
						List <WebElement> allOptions = course.getOptions();
						
						//finding the size of the list
						int count=allOptions.size();
						
						//selecting the item which is at the last index
						course.selectByIndex(count-2);
					
			}
}