package week1.classwork;

public class Armstrong {

	public static void main(String[] args) {
		int number = 0;
		int armsNumber = 0;
		for (int i = 100; i <=1000; i++) {
			number = i;
			while (number>0){
				int r = number % 10;
				armsNumber = armsNumber + (r*r*r);
				number = number/10;
			}
			if (armsNumber==i)
				System.out.println(i+" is an armstron number");
			armsNumber= 0;
		}
	}

}
