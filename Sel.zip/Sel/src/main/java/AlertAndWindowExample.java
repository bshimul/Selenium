
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class AlertAndWindowExample {

	public static void main(String[] args) throws InterruptedException, IOException {
		System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");

		//chrome driver object
		ChromeDriver driver = new ChromeDriver();
		
		 driver.get("http://jqueryui.com/sortable/");
		 driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);		
		 driver.manage().window().maximize();
		 
		 driver.switchTo().frame(driver.findElementByClassName("demo-frame"));
		 
		 WebElement item1 = driver.findElementByXPath("//li[@class = 'ui-state-default ui-sortable-handle']");
		 WebElement item4 = driver.findElementByXPath("(//li[@class = 'ui-state-default ui-sortable-handle'])[4]");
		 int xoffset = item4.getLocation().getX();
		 int yoffset = item4.getLocation().getY();
		 
		 Actions builder = new Actions (driver);
		 builder.clickAndHold(item1).moveByOffset(xoffset, yoffset).release(item1).build().perform();
		 
		 
		/* 
		System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");

		//chrome driver object
		ChromeDriver driver = new ChromeDriver();

		//tolaunch the url
		driver.get("http://leaftaps.com/opentaps/control/main");
		//to maximize the window
		driver.manage().window().maximize();
		//to enter the user name
		driver.findElementById("username").sendKeys("demoSalesManager");
		//to enter the password
		driver.findElementById("password").sendKeys("crmsfa");
		//click on the login button
		driver.findElementByClassName("decorativeSubmit").click();
		//to click on crm/sfa web element
		driver.findElementByLinkText("CRM/SFA").click();
		//to click on Leads tab web element
		driver.findElementByLinkText("Leads").click();
		//to click on merge leads web element
		driver.findElementByLinkText("Merge Leads").click();
		//to click on the icon near the from lead text box
		driver.findElementByXPath("(//img[@alt='Lookup'])[1]").click();

		// we need to store the value of the first window to do further actions in the future
		String parentWindow = driver.getWindowHandle();
		//we need to store the values of the window handle
		Set<String> windowOpenCount = driver.getWindowHandles();
		// to print the no of windows open
		System.out.println(windowOpenCount.size());
		//to move the control to the last window(icon next to to lead check box window)
		for (String lastWindow : windowOpenCount) {
			driver.switchTo().window(lastWindow);
		}
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		// to check whether the control is in the opened window
		System.out.println(driver.getTitle());
		//to enter the Lead ID in the new opened window
		driver.findElementByXPath("//label[contains(text(),'Lead ID:')]/following::input").sendKeys("17582");
		//Thread.sleep(5000);
		//to click on the find Lead button
		driver.findElementByXPath("//button[contains(text(),'Find Leads')]").click();
		Thread.sleep(5000);
		//to click on the first resulting lead name in the result
		driver.findElementByXPath("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a").click();
		//Thread.sleep(3000);
		//to return the control to the parent window
		driver.switchTo().window(parentWindow);
		//to click on the icon next to the to lead text box
		driver.findElementByXPath("(//img[@alt='Lookup'])[2]").click();
		//to move the control to the last window(icon next to lead check box window)
		Set<String> windowOpenCount2 = driver.getWindowHandles();
		//to print the no of windows open
		System.out.println(windowOpenCount2.size());
		for (String lastWindow : windowOpenCount2) {
			driver.switchTo().window(lastWindow);
		}
		//to check whether the control is in the opened window
		System.out.println(driver.getTitle());
		// to enter the lead ID in the new opened window
		driver.findElementByXPath("//label[contains(text(),'Lead ID:')]/following::input").sendKeys("17583");
		//to click on the find lead button
		driver.findElementByXPath("//button[contains(text(),'Find Leads')]").click();
		//to click on the first resulting lead name in the result
		Thread.sleep(3000);
		driver.findElementByXPath("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a").click();
		//to move control to the parent window
		driver.switchTo().window(parentWindow);
		//to click on the merge button in the parent window
		driver.findElementByLinkText("Merge").click();
		//to handle the confirmation alert box
		driver.switchTo().alert().accept();
		// to click on the find Lead 
		driver.findElementByLinkText("Find Leads").click();
		// to enter the value in the lead window
		driver.findElementByXPath("//label[contains(text(),'Lead ID:')]/following::input").sendKeys("17582");;
		//to click on the find lead button
		driver.findElementByXPath("//button[contains(text(),'Find Leads')]").click();
		//to verify the error message
		driver.findElementByXPath("//div[contains(text(),'No records to display')]");
		//to close the browser window
		driver.close();*/



	}

}

